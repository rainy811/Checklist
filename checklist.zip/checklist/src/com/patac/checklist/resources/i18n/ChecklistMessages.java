// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.resources.i18n;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;

/**
 * Messages for Checklist.
 */
public interface ChecklistMessages
    extends Messages
{
    /** Messages instance */
    ChecklistMessages INSTANCE = GWT.create( ChecklistMessages.class );

    /**
     * @return String for CheckListMainTitle
     */
    String CheckListMainTitle();

    /**
     * @return String for C7tDefineLocTitle
     */
    String C7tDefineLocTitle();

    /**
     * @return String for C7tViewLocPrimaryWorkAreaText
     */
     String C7tViewLocPrimaryWorkAreaText();

    /**
     * @return String for C7tViewLocTitle
     */
    String C7tViewLocTitle();
    String C7tProjLocTitle();
    /**
     * @return display string for C7tDefineFilter
     */
    String C7tDefineFilterTitle();
    
    String ShowLatestItmeTitle();

    /**
     * @return display string for Header
     */
    String txtPublishState();

    /**
     * @return display string for Body
     */
    String txtProps();

    /**
     * @return display string for C7tDefineFilterCheckboxLabel.
     */
    String txtPublished();

    /**
     * @return display string for Footer
     */
    String footer();

    /**
     * @return display string for ObjectString
     */
    String objectString();

    /**
     * @return display string for okButton
     */
    String okButton();

    /**
     * @return display string for no selection.
     */
    String noSelection();

    /**
     * @return display string for C7tDefineFilterComplete message.
     */
    String C7tDefineFilterComplete();

    /**
     * @return display string for C7tViewFilter
     */
    String C7tViewFilterTitle();

    /**
     * @return display string for C7tViewFilterCheckboxLabel.
     */
    String C7tViewFilterCheckboxLabel();

    /**
     * @return display string for C7tViewFilterComplete message.
     */
    String C7tViewFilterComplete();

    /**
     * @return display string for CreCheckDef
     */
    String CreCheckDefTitle();

    /**
     * @return display string for CreCheckDefCheckboxLabel.
     */
    String CreCheckDefCheckboxLabel();

    /**
     * @return display string for CreCheckDefComplete message.
     */
    String CreCheckDefComplete();
    
    String createObjectOperationFailed();
    
    String objCreated(String objectDisplayName);
    String create();
    String save();
    String submit();
    
    String myObjs();
    
    String txtSearchCriteriaErr();
    
    String state();
    
    String SelectProject();
    
    String RoleNotOk(String msg);

    String CreProject(String msg);
    
    String txtAvailableProjs();
    
    String txtProjType();

	String ReleaseItmeTitle();

	String UnReleaseItmeTitle();
	
	String TaskList();
	
	String Red();
	
	String Yellow();
	
	String Green();
	
	String DListLocPrimaryWorkAreaText();
	
	String DListLocTitle();
	
	String FListLocPrimaryWorkAreaText();
	
	String FListLocTitle();
	
	String txtAllStat();
	
	String publish();
	String myItem();

}
