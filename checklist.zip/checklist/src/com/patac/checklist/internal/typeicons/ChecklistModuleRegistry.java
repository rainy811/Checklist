// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.typeicons;

import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeUri;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.published.ITypeName;
import com.siemens.splm.clientfx.tcui.typeicons.published.ITypeIconModuleRegistry;
import com.patac.checklist.internal.Resources;

/**
 * Assign type icons to a type
 */
public class ChecklistModuleRegistry
    implements ITypeIconModuleRegistry
{
    @Override
    public ImageResource getTypeIcon( String typeName ) 
    {
        // Assign the C7t_CheckItemImageIcon.png to the data type C7t_CheckItem
        if( typeName.equals( "C7t_CheckDef" ) ) //$NON-NLS-1$
        {
            return Resources.INSTANCE.get_checkTemplateIcon();
        }
        if( typeName.equals( "C7t_CheckItem" ) ) //$NON-NLS-1$
        {
            return Resources.INSTANCE.getC7t_CheckItemIconItem();
        }
        return null;
    }

    @Override
    public SafeHtml getCustomIcon( IModelObject object )
    {
        return null;
    }

    @Override
    public SafeUri getThumbnailURL( IModelObject object )
    {
        return null;
    }

    @Override
    public SafeHtml getMiniOverlayIconSafeHtml( IModelObject object )
    {
        return null;
    }

    @Override
    public SafeUri getThumbnailOverlayURI( IModelObject object )
    {
        return null;
    }
}
