// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.uihandlers;

import com.gwtplatform.mvp.client.UiHandlers;

/**
 * The UI handler for com.patac.checklist.
 */
public interface C7tPrjFilterUiHandlers
    extends UiHandlers
{
    /**
     * Viewer slot
     */
    Object VIEWER_SLOT = new Object();
    
    /**
     * This method processed the panel data, and closes the Panel.
     */
    void completed();
}
