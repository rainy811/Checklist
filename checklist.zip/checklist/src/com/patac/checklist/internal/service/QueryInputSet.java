package com.patac.checklist.internal.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.comm.svr.OpValue;
import com.cus.comm.svr.SavedQueryService;
import com.patac.checklist.internal.types.CTypes;

public class QueryInputSet {
	private Map<String, String> m_input_map = new HashMap<String, String>();
	
	public void clear(){
		m_input_map.clear();
	}
	
	public void push(String key, String value){
		m_input_map.put(key, value);
	}
	
	public Map<String, OpValue> getInputs(){
		Map<String, OpValue> input_map = new HashMap<String, OpValue>();
		if(m_input_map.size()==0)
			return input_map;
		Set<Entry<String, String>> kvs_set = m_input_map.entrySet();
		Iterator<Entry<String, String>> itr = kvs_set.iterator();
		while(itr.hasNext()){
			Entry<String, String> kvs = itr.next();			
			String key = kvs.getKey();
			String val = kvs.getValue();			
			if(CTypes.my_obj.equals(key)){
				if(CTypes.TRUE.equalsIgnoreCase(val)==true){
					String usrString = CommUtils.getUserString();
					input_map.put(CTypes.c7t_user_id, new OpValue(usrString, SavedQueryService.ClausesIn.MATH_OP_EQUAL));
				}else if(CTypes.FALSE.equalsIgnoreCase(val)==true){
					String usrString = CommUtils.getUserString();
					input_map.put(CTypes.c7t_user_id, new OpValue(usrString, SavedQueryService.ClausesIn.MATH_OP_NOT_EQUAL));
				}else{
					
				}
			}else{
				input_map.put(key, new OpValue(val, SavedQueryService.ClausesIn.MATH_OP_EQUAL));
			}
		}

		return input_map;
	}
}
