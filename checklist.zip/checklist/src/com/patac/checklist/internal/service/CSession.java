package com.patac.checklist.internal.service;

import java.util.Date;
import java.util.Vector;

import com.google.gwt.user.client.Cookies;

public class CSession{
	public final static String VIEW_MODE = "c7t_view_mode"; 
	public final static String SESSION_ITEMS = "C7T_SESSION_ITEMS"; 
	public final static String SP_C = "^||^";
	public final static String SP_S = "\\^\\|\\|\\^";
	
	
	public static String[] string2Array(String str){
		if(str==null || "".endsWith(str.trim()))
			return null;
		return str.split(SP_S);
	}
	
	public static String array2String(String[] ary){
		StringBuilder sb = new StringBuilder();
		if(ary!=null)
		{
			for(String str : ary){
				if(str!=null){
					sb.append(SP_C).append(str);
				}
			}
		}
		String val = sb.toString();
		if(val.startsWith(SP_C))
			val = val.substring(SP_C.length(), val.length());
		return val;
	}

	private static void setSessionItemUids(String[] uids){
		Date nowd = new Date();
		nowd.setTime(nowd.getTime()+8*60*60*1000);
		Cookies.setCookie(SESSION_ITEMS, array2String(uids), nowd);
	}

	public static String[] getSessionItemUids(){
		return string2Array(Cookies.getCookie(SESSION_ITEMS));
	}
	
	public static void addSessionItemUid(String uid){
		if(uid==null || "".equals(uid))
			return;
		String[] uids = getSessionItemUids();
		if(uids==null || uids.length<=0){
			setSessionItemUids(new String[]{uid});
			return;
		}else{
			Vector<String> id_v = new Vector<String>();
			for(String id : uids){
				if(id!=null && id.equals(uid))
					return;
				id_v.add(id);
			}
			id_v.add(0, uid);
			setSessionItemUids(id_v.toArray(new String[id_v.size()]));
		}
	}
	
	public static void setVIEW_MODE(String mode){
		Cookies.setCookie(VIEW_MODE, mode);
	}

	
	public static String getVIEW_MODE(){
		return Cookies.getCookie(VIEW_MODE);
	}
	
}
