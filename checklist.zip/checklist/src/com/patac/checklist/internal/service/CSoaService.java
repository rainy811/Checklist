package com.patac.checklist.internal.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.comm.svr.OpValue;
import com.cus.comm.svr.SavedQueryService;
import com.cus.comm.svr.SavedQueryService.ClausesIn;
import com.cus.comm.svr.SavedQueryService.QryInput;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.patac.checklist.internal.types.CTypes;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IJSO;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IJsArray;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IServiceData;
import com.siemens.splm.clientfx.kernel.clientmodel.published.JSOFactory;
import com.siemens.splm.clientfx.kernel.published.ISession;
import com.siemens.splm.clientfx.kernel.soa.published.ISOAResponse;
import com.siemens.splm.clientfx.kernel.soa.published.SOA;
import com.siemens.splm.clientfx.tcui.utils.published.ModelUtils;

public final class CSoaService {
    /** event bus */
    @Inject
    private EventBus m_eventBus;
    
   /** session */
    @Inject
    private ISession m_session;
    
    /** JavaScript module name. */
    private final static String MODULE_NAME = "soa/dataManagementService"; //$NON-NLS-1$
    private CSoaService(){};

    public static void findC7tDefine(String[] properties, final AsyncCallback<List<IModelObject>> rsObj){
    	Map<String, OpValue> attrmap = new HashMap<String, OpValue>();
    	findObjsAnd(attrmap, CTypes.C7t_CheckDef, properties, rsObj);
    }
    
    public static void findC7tDefine(QueryInputSet inputs, String[] properties, final AsyncCallback<List<IModelObject>> rsObj){
    	Map<String, OpValue> attrmap;
    	if(null==inputs){
    		attrmap = new HashMap<String, OpValue>();
    	}else{
    		attrmap = inputs.getInputs();
    	}
    	findObjsAnd(attrmap, CTypes.C7t_CheckDef, properties, rsObj);
    }

    public static void findC7tItems(QueryInputSet inputs, String[] properties, final AsyncCallback<List<IModelObject>> rsObj){
    	Map<String, OpValue> attrmap;
    	if(null==inputs){
    		attrmap = new HashMap<String, OpValue>();
    	}else{
    		attrmap = inputs.getInputs();
    	}
    	findObjsAnd(attrmap, CTypes.C7t_CheckItem, properties, rsObj);
    }
    
    public static void findObjsAnd(final Map<String, OpValue> attrmap, final String type, final String[] properties, final AsyncCallback<List<IModelObject>> rsObj ){
    	Vector<ClausesIn> clauses_v = new Vector<ClausesIn>();
    	Set<Entry<String, OpValue>> props = attrmap.entrySet();
    	for(Entry<String, OpValue> prop : props){
    		String key = prop.getKey();
    		OpValue val = prop.getValue();    		
    		clauses_v.add(new ClausesIn(key, val.value, val.op, SavedQueryService.ClausesIn.LOGIC_AND));
    	}
    	
    	if(clauses_v.isEmpty())
    		clauses_v.add(new ClausesIn(CTypes.item_id, "*"));
    	QryInput qry = new QryInput(type, clauses_v);
    	QryInput inputs[] = {qry};
    	IJSO query = SavedQueryService.createSavedQuery(inputs);
    	CommMsg.log_info("#executeBusinessObjectQueries", "#clause size="+props.size());
    	SavedQueryService.executeBusinessObjectQueries(query, new AsyncCallback<ISOAResponse>(){
			@Override
			public void onFailure(Throwable caught) {				
				rsObj.onFailure(caught);
			}

			@Override
			public void onSuccess(ISOAResponse response) {
                
                IJsArray outputList = response.getArray( "arrayOfResults" ); //$NON-NLS-1$
                if(outputList==null || outputList.length()==0){
                	rsObj.onSuccess(null);
                	return;
                }

                final String [] uids = outputList.get(0).getStringArray( "objectUIDS" );
                if(uids==null || uids.length==0){
                	rsObj.onSuccess(null);
                	return;
                }
                
                CommUtils.loadObjects(uids, new AsyncCallback<Map<String, IModelObject>> (){
        			@Override
        			public void onFailure(Throwable caught) {
        				CommMsg.log_warn("#######", caught.getMessage()); //$NON-NLS-1$
        			}
        			@Override
        			public void onSuccess(Map<String, IModelObject> sd) {
        				final List<IModelObject> objList =  new ArrayList<IModelObject>();
        				final IModelObject objaryt[] = new IModelObject[uids.length];
        				int i=0;
        				for(String uid : uids){        					
        					objList.add(sd.get(uid));
        					objaryt[i] = sd.get(uid);
        					i++;
        				}
                    	ModelUtils.ensurePropertiesLoaded(objaryt, properties, new AsyncCallback<Void>(){
        					@Override
        					public void onFailure(Throwable caught) {
        						rsObj.onFailure(caught);
        					}

        					@Override
        					public void onSuccess(Void result) {
        						rsObj.onSuccess(objList);       						
        					}            		 
                    	});
        			}});    
               
			}
    		
    	});
    }    	

    
    
    
    public static native IJSO createAddChildrenInput( IModelObject parentObj, IModelObject[] children,String propertyName )
    /*-{
        return {
            clientId: "Va6AddCh1",
            parentObj: parentObj,
            childrenObj: children,
            propertyName: propertyName
        };
    }-*/;    
    public static void addChildren( IJsArray inputData, AsyncCallback<IServiceData> callback )
    {
        IJSO input = JSOFactory.createObject();
        input.setArray( "inputData", inputData ); //$NON-NLS-1$
        SOA.executeOperationUnchecked( "Core-2014-10-DataManagement", "addChildren", input, callback ); //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    public static native IJSO createRemoveChildrenInput( IModelObject parentObj, IModelObject [] children,String propertyName )
    /*-{
        return {
            clientId: "Va6Remove1",
            parentObj: parentObj,
            childrenObj: children,
            propertyName: propertyName
        };
    }-*/;
}
