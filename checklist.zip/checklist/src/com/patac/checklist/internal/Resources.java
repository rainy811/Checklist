// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.resources.client.TextResource;

/**
 * Module resources for Checklist
 */
public interface Resources
    extends ClientBundle
{
    /** Resources instance */
    Resources INSTANCE = GWT.create( Resources.class );
    
    @Source( "com/patac/checklist/resources/policy/C7tPropertyPolicy.txt" )
    TextResource getC7tPropertyPolicy();    
    
    /**
     * Get C7tDefineFilter command image
     * @return C7tDefineFilter command image
     */
    @Source( "com/patac/checklist/resources/images/C7tDefineFilter.png" )
    ImageResource getC7tDefineFilterImage();

    /**
     * Get C7tViewFilter command image
     * @return C7tViewFilter command image
     */
    @Source( "com/patac/checklist/resources/images/C7tViewFilter.png" )
    ImageResource getC7tViewFilterImage();

    @Source( "com/patac/checklist/resources/images/C7tProjFilter.png" )
    ImageResource getC7tProjFilterImage();

    /** Returns the sample type icon image.
     * @return ImageResource The sample type icon image.
     */
    @Source( "com/patac/checklist/resources/images/C7t_CheckDefIconImage.png" )
    ImageResource getC7t_CheckDefIconItem();
    
    @Source( "com/patac/checklist/resources/images/C7t_CheckTemplate.png")
    ImageResource get_checkTemplateIcon();


    /** Returns the sample type icon image.
     * @return ImageResource The sample type icon image.
     */
	@Source( "com/patac/checklist/resources/images/C7t_CheckItemIconImage.png" )
	ImageResource getC7t_CheckItemIconItem();

    /**
     * Get CreCheckDef command image
     * @return CreCheckDef command image
     */
    @Source( "com/patac/checklist/resources/images/CreCheckDef.png" )
    ImageResource getCreCheckDefImage();

	@Source( "com/patac/checklist/resources/images/latestwork.png" )
	ImageResource getLatestWrokImg();

	@Source( "com/patac/checklist/resources/images/C7t_YES.png" )
	ImageResource getReleaseImg();

	@Source( "com/patac/checklist/resources/images/C7t_NO.png" )
	ImageResource getUnReleaseImg();
	
	@Source( "com/patac/checklist/resources/images/PersonnelTask.png")
	ImageResource getTaskList();
	
	@Source( "com/patac/checklist/resources/images/tasklist_red.png")
	ImageResource getRed();
	
	@Source( "com/patac/checklist/resources/images/tasklist_yellow.png")
	ImageResource getYellow();

	@Source( "com/patac/checklist/resources/images/tasklist_green.png")
	ImageResource getGreen();

	@Source( "com/patac/checklist/resources/images/submit.png")
	ImageResource submit();
	
	@Source( "com/patac/checklist/resources/images/save.png")
	ImageResource save();
	
	@Source( "com/patac/checklist/resources/images/check.png")
	ImageResource check();

	@Source( "com/patac/checklist/resources/images/myitem.png")
	ImageResource my();
}
