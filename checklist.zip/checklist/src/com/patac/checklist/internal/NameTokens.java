// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal;

/**
 * Name tokens used in Checklist module
 */
public interface NameTokens
{
	String UID = "uid"; //$NON-NLS-1$
	String PAGE = "page"; //$NON-NLS-1$
	String EDIT = "edit"; //$NON-NLS-1$
	
	String CreCheckDefOp = "com.patac.checklist.createCheckDef";//$NON-NLS-1$
	
    /** CheckListMain location token. */
    String CheckListMain_LOCATION = "com.patac.checklist.CheckListMain"; //$NON-NLS-1$

    /** C7tDefineLoc token. */
    String C7tDefineLoc_SUB_LOCATION = "com.patac.checklist.C7tDefineLocSubLocation"; //$NON-NLS-1$

    String C7tShowOBJ_TOKEN = "C7tShowObj"; //$NON-NLS-1$
    String C7tShowOBJ_SUB_TOKEN = "C7tShowObjSub"; //$NON-NLS-1$
    String CheckList_showobj_LOCATION = "com.patac.checklist.CheckListShowobj"; //$NON-NLS-1$
    String C7t_showobjLoc_SUB_LOCATION = "com.patac.checklist.C7tShowobjLocSubLocation"; //$NON-NLS-1$
    
    /** C7tDefineLoc history token. */
    String C7tDefineLoc_TOKEN = "C7tDefineLoc"; //$NON-NLS-1$

    /** C7tViewLoc token. */
    String C7tViewLoc_SUB_LOCATION = "com.patac.checklist.C7tViewLocSubLocation"; //$NON-NLS-1$
    String C7tProjLoc_SUB_LOCATION = "com.patac.checklist.C7tProjLocSubLocation"; //$NON-NLS-1$

    /** C7tViewLoc history token. */
    String C7tViewLoc_TOKEN = "C7tViewLoc"; //$NON-NLS-1$
    String C7tProjLoc_TOKEN = "C7tProjLoc"; //$NON-NLS-1$

    String CMD_LatestC7tDefine = "com.patac.checklist.Checklist.LatestC7tDefine"; //$NON-NLS-1$
    String CMD_MyC7tDefine = "com.patac.checklist.Checklist.MyC7tDefine"; //$NON-NLS-1$

    String CMD_VIEW_MODET = "com.patac.checklist.Checklist.ViewModeT";//$NON-NLS-1$
    String CMD_VIEW_MODELS = "com.patac.checklist.Checklist.ViewModeLS";//$NON-NLS-1$
    
    /** Command constant. */
    String CMD_C7tDefineFilter = "com.patac.checklist.Checklist.C7tDefineFilter"; //$NON-NLS-1$
    String CMD_C7tDefineRelease  = "com.patac.checklist.Checklist.C7tDefineRelease"; //$NON-NLS-1$
    String CMD_C7tDefineUnRelease  = "com.patac.checklist.Checklist.C7tDefineUnRelease"; //$NON-NLS-1$
    
    //提交和保存按钮
    String CMD_SubmitButton = "com.patac.checklist.Checklist.SubmitButton";//$NON-NLS-1$
    String CMD_SaveButton = "com.patac.checklist.Checklist.SaveButton";//$NON-NLS-1$
    
    //publish button
    String CMD_publishButton = "com.patac.checklist.Checklist.CMD_publishButton";//$NON-NLS-1$
    
    /** Left D Buttons*/
    String CMD_C7tDTaskList = "com.patac.checklist.Checklist.C7tDTaskList";//$NON-NLS-1$
    String CMD_C7tDRedCheck = "com.patac.checklist.Checklist.C7tDRedCheck";//$NON-NLS-1$
    String CMD_C7tDYellowCheck = "com.patac.checklist.Checklist.C7tDYellowCheck";//$NON-NLS-1$
    String CMD_C7tDGreenCheck = "com.patac.checklist.Checklist.C7tDGreenCheck";//$NON-NLS-1$

    
    /** Left F Buttons*/
    String CMD_C7tFTaskList = "com.patac.checklist.Checklist.C7tFTaskList";//$NON-NLS-1$
    String CMD_C7tFRedCheck = "com.patac.checklist.Checklist.C7tFRedCheck";//$NON-NLS-1$
    String CMD_C7tFYellowCheck = "com.patac.checklist.Checklist.C7tFYellowCheck";//$NON-NLS-1$
    String CMD_C7tFGreenCheck = "com.patac.checklist.Checklist.C7tFGreenCheck";//$NON-NLS-1$
    /** Command constant. */
    String CMD_C7tViewFilter = "com.patac.checklist.Checklist.C7tViewFilter"; //$NON-NLS-1$
    String CMD_C7tProjFilter = "com.patac.checklist.Checklist.C7tProjFilter"; //$NON-NLS-1$

    /** Command constant. */
    String CMD_CreCheckDef = "com.patac.checklist.Checklist.CreCheckDef"; //$NON-NLS-1$

	String XRT_C7t_LOV_PANEL = "com.patac.checklist.c7tdef.lovpanel";//$NON-NLS-1$
	
	String XRT_C7t_TERRI_PANEL = "com.patac.checklist.c7tdef.terripanel";//$NON-NLS-1$

	String XRT_C7t_DEVLVL_PANEL = "com.patac.checklist.c7tdef.devlvlpanel";//$NON-NLS-1$
	
	String XRT_C7t_VEHICLE_PANEL = "com.patac.checklist.c7tdef.vehiclepanel";//$NON-NLS-1$

	String XRT_C7t_IMPORTANCE_PANEL = "com.patac.checklist.c7tdef.importancepanel";//$NON-NLS-1$
	
	String XRT_C7t_STATEPICK_PANEL = "com.patac.checklist.c7tdef.statepickpanel";//$NON-NLS-1$

	String XRT_C7t_PROJECTROLE_PANEL = "com.patac.checklist.c7tdef.projectrolepanel";//$NON-NLS-1$
	
	String XRT_C7t_PIC_PANEL = "com.patac.checklist.c7tdef.picpanel";//$NON-NLS-1$
	

	
    /** DListLoc token. */
    String DListLoc_SUB_LOCATION = "com.patac.checklist.DListLocSubLocation"; //$NON-NLS-1$

    /** DListLoc history token. */
    String DListLoc_TOKEN = "DListLoc"; //$NON-NLS-1$

    /** FListLoc token. */
    String FListLoc_SUB_LOCATION = "com.patac.checklist.FListLocSubLocation"; //$NON-NLS-1$

    /** FListLoc history token. */
    String FListLoc_TOKEN = "FListLoc"; //$NON-NLS-1$
}
