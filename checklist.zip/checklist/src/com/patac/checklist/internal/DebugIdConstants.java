// @<COPYRIGHT>@
// ==================================================
// Copyright 2014.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal;

/**
 * Constants to be used as the debugId when using ensureDebugId (UI tests).
 */
public interface DebugIdConstants
{
    /**
     * Sub location command.
     */
   String SUB_LOCATION_COMMAND = "subLocationCommand"; //$NON-NLS-1$

    /**
     * Do work command.
     */
    String DO_WORK_COMMAND = "doWorkCommand"; //$NON-NLS-1$

}
