package com.patac.checklist.internal.ui.common.widgets.cuspanel.picview;

import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.comm.published.utils.ICommService;
import com.cus.commrpc.published.DownFileAsStringService;
import com.cus.commrpc.published.DownFileAsStringServiceAsync;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.safehtml.shared.SafeUri;
import com.google.gwt.safehtml.shared.UriUtils;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.patac.checklist.internal.types.CTypes;
import com.siemens.splm.clientfx.base.published.MessageUtil;
import com.siemens.splm.clientfx.bootstrap.hosted.published.services._2014_02.InteropObjectRef;
import com.siemens.splm.clientfx.fms.published.FMSUtils;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelType;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.kernel.published.IPropertyName;
import com.siemens.splm.clientfx.kernel.published.ITypeName;
import com.siemens.splm.clientfx.kernel.soa.published.ISOAResponse;
import com.siemens.splm.clientfx.tcui.session.published.FileManagementService;
import com.siemens.splm.clientfx.tcui.utils.published.ModelUtils;
import com.siemens.splm.clientfx.ui.published.IModelObjectDataProvider;

/**
 * View for SearchPanel.
 */
public class PropPicView
	implements PropPicviewPresenterW.MyView
{
	private final DownFileAsStringServiceAsync fsSvr = GWT.create(DownFileAsStringService.class);
	
	@Inject
	ICommService commSvr;
	
	@Inject	
	IModelObjectDataProvider mDp;
	
//    @Inject
//    private GetTicketResponseProxy m_responseProxy;
	
    private final Widget m_widget;    
    private IModelObject m_sel_obj;
    
    private Vector<SafeUri> m_pix_files = new Vector<SafeUri>();
    private Vector<Image> m_pix_imgs = new Vector<Image>();

	@UiField
	HorizontalPanel cpn01;
	@UiField
	FlowPanel cpn02;
	
	
     /**
     * Ui binder
     */
    public interface Binder
        extends UiBinder<Widget, PropPicView>
    {
        //
    }

    /**
     * Constructor
     * 
     * @param binder Ui binder
     */
    @Inject
    public PropPicView( final Binder binder )
    {
        m_widget = binder.createAndBindUi( this );
    }
    
    private void getReadTicket( final IModelObject dataset, final IModelObject imanFileObj, final AsyncCallback<String> callback)
    {
        final IModelObject[] files = new IModelObject[] { imanFileObj };
        FileManagementService.getFileReadTickets( files, new AsyncCallback<ISOAResponse>()
        {
            @Override
            public void onSuccess( ISOAResponse result )
            {
				Map<IModelObject,String> ticketMap=result.getMapModelObject2String("tickets");
				if(ticketMap.size()>0){
					String ticket=ticketMap.get(imanFileObj);
	                if(ticket==null) {
	                	callback.onFailure(new Throwable("ticket empty"));
	                	return;
	                }
	                //get the original filename from the ImanfileObject
	                String filename = null;
	                IProperty<String> origfilenameProperty = (IProperty<String>) files[0].getPropertyObject( "original_file_name" ); //$NON-NLS-1$
	                if( origfilenameProperty != null && origfilenameProperty.getValue() != null
	                        && origfilenameProperty.getValue().length() > 0 )
	                {
	                    filename = origfilenameProperty.getValue();
	                }

	                //build the uri
	                String uri = FMSUtils.getFileUri( ticket, filename ).asString();
	                InteropObjectRef obj = InteropObjectRef.MakeInteropObjectRef( "", dataset.getUid(), dataset.getType() ); //$NON-NLS-1$
	                //m_responseProxy.sendResponse( obj, "Download", uri, ticket, filename );
	                callback.onSuccess(uri);	                
				}
            }

            @Override
            public void onFailure( Throwable caught )
            {
                MessageUtil.reportException( caught, "Download file failed." ); //$NON-NLS-1$
                callback.onFailure(caught);
            }
        } );
    }
	
	@Override
	public void loadPropValues(final IModelObject item, final IModelType type){
		m_sel_obj = item;
	
		CommUtils.getRelatedObjects(item, CTypes.getCheckDefRels(), new  AsyncCallback<List<IModelObject>> () {
			@Override
			public void onFailure(Throwable caught) {
			}

			@Override
			public void onSuccess(List<IModelObject> rtds) {
				for(final IModelObject obj : rtds) {
			        if( obj.getTypeObject().isInstanceOf( ITypeName.Dataset ) )
			        {
			            String[] properties = new String[] { IPropertyName.REF_LIST };
			            IModelObject[] objs = new IModelObject[1];
			            objs[0] = obj;
			            ModelUtils.ensurePropertiesLoaded( objs, properties, new AsyncCallback<Void>()
			            {
			                @Override
			                public void onSuccess( Void result )
			                {
			                    IProperty<List<IModelObject>> props = (IProperty<List<IModelObject>>) obj.getPropertyObject( IPropertyName.REF_LIST );
			                    if( props != null && props.getValue() != null && props.getValue().size() > 0 )
			                    {
			                        if( props.getValue().size() > 0 )
			                        {
			                            getReadTicket( obj, props.getValue().get( 0 ) , new  AsyncCallback<String>() {

											@Override
											public void onFailure(Throwable caught) {												
											}

											@Override
											public void onSuccess(String uri) {
												if(uri!=null) {
													SafeUri su = UriUtils.fromString(uri);
													m_pix_files.add(su);
													updateUI();
												}
											}});
			                        }
			                    }
			                }

			                @Override
			                public void onFailure( Throwable caught )
			                {
			                    MessageUtil.reportException( caught );
			                }
			            } );
			        }
				}
			}});
	}	
	
	public void updateUI() {
		cpn01.clear();
		cpn02.clear();
		m_pix_imgs.clear();
		for(int i=0; i<m_pix_files.size(); i++) {
			final SafeUri sur = m_pix_files.get(i);
			final Image img = new Image(sur);img.setWidth(48+"px");img.addStyleName("aw-cus-pic");
			m_pix_imgs.add(img);
			final Image img2 = new Image(sur);img2.setWidth("80%");
			cpn02.add(img);
			if(i==0) cpn01.add(img2);
			img.addClickHandler(new ClickHandler() {
				@Override
				public void onClick(ClickEvent event) {
					cpn01.clear();
					cpn01.add(img2);					
					//Window.open(sur.asString(), "blank", "");
				}});
		}
		
//   	int w = cpn01.getParent().getParent().getParent().getOffsetWidth();   		
//		int w2 = w==0 ? 0 : w/3; 
//		if(m_pix_files.size()==1) {
//			m_pix_imgs.get(0).setWidth( (w-1) + "px");
//		}else if(m_pix_files.size()>1 && m_pix_files.size()<=3) {
//			m_pix_imgs.get(0).setWidth( (w2) + "px");
//			m_pix_imgs.get(1).setWidth( (w2) + "px");
//			m_pix_imgs.get(2).setWidth( (w-1) + "px");
//		}else if(m_pix_files.size()==4) {
//			m_pix_imgs.get(0).setWidth( (w2) + "px");
//			m_pix_imgs.get(1).setWidth( (w2) + "px");
//			m_pix_imgs.get(2).setWidth( (w2) + "px");
//			m_pix_imgs.get(3).setWidth( (w2) + "px");
//		}
//		final Timer timer = new Timer() {
//            public void run()
//            {
// 
//            }
//		};	
//		timer.schedule(500);
	
	}
	
	@Override
	public Widget asWidget() {
		return m_widget;
	}

	@Override
	public void addToSlot(Object slot, Widget content) {
	
	}

	@Override
	public void removeFromSlot(Object slot, Widget content) {
		
	}

	@Override
	public void setInSlot(Object slot, Widget content) {
		
	}
	
}
