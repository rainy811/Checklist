package com.patac.checklist.internal.ui.common.widgets.prjtree;

import java.util.ArrayList;
import java.util.List;

import com.cus.comm.published.utils.CommMsg;
import com.google.gwt.cell.client.Cell;
import com.google.gwt.cell.client.CompositeCell;
import com.google.gwt.cell.client.FieldUpdater;
import com.google.gwt.cell.client.HasCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.view.client.SelectionModel;
import com.google.gwt.view.client.TreeViewModel;
import com.patac.checklist.internal.ui.common.widgets.prjtree.ProjService.PrjNode;
import com.patac.checklist.internal.ui.common.widgets.prjtree.ProjCellTree.ProjNodeCell;
import com.patac.checklist.internal.ui.common.widgets.prjtree.ProjCellTree.ProjNodeTextCell;

public class ProjTreeViewModel implements TreeViewModel {
	public static Images images = GWT.create(Images.class);
	public final Cell<PrjNode> m_Cell;
	
	static interface Images extends ClientBundle {
		    ImageResource imgDesg16();
		    ImageResource imgDeco16();
		    ImageResource imgDesg32();
		    ImageResource imgDeco32();
		    ImageResource display32();
		    ImageResource new32();
	}
	
	
	public ProjTreeViewModel(final SelectionModel<PrjNode> selectionModel) {

	    List<HasCell<PrjNode, ?>> hasCells = new ArrayList<HasCell<PrjNode, ?>>();	   
	    
	    hasCells.add(new HasCell<PrjNode, PrjNode>() {
	        private Cell<PrjNode> cell = new ProjNodeCell(images.new32(), images.display32());
	        @Override
			public Cell<PrjNode> getCell() {
	        	return cell;
	        }

	        @Override
			public FieldUpdater<PrjNode, PrjNode> getFieldUpdater() {
	          return null;
	        }

	        @Override
			public PrjNode getValue(PrjNode object) {
	          return object;
	        }
	      });
	    
	    hasCells.add(new HasCell<PrjNode, PrjNode>() {
	        private Cell<PrjNode> cell = new ProjNodeTextCell();
	        @Override
			public Cell<PrjNode> getCell() {
	        	return cell;
	        }

	        @Override
			public FieldUpdater<PrjNode, PrjNode> getFieldUpdater() {
	          return null;
	        }

	        @Override
			public PrjNode getValue(PrjNode object) {
	          return object;
	        }
	      });
	    
	    m_Cell = new CompositeCell<PrjNode>(hasCells) {
	        @Override
	        public void render(Context context, PrjNode value, SafeHtmlBuilder sb) {
	          //sb.appendHtmlConstant("<table><tbody><tr>");
	          super.render(context, value, sb);
	          //sb.appendHtmlConstant("</tr></tbody></table>");
	        }

	        @Override
	        protected Element getContainerElement(Element parent) {
	          return parent.getFirstChildElement();
	        }

	        @Override
	        protected <X> void render(Context context, PrjNode value,
	            SafeHtmlBuilder sb, HasCell<PrjNode, X> hasCell) {
	          Cell<X> cell = hasCell.getCell();
	          //sb.appendHtmlConstant("<td>");
	          cell.render(context, hasCell.getValue(value), sb);
	          //sb.appendHtmlConstant("</td>");
	        }
	      };
	      
	      ProjService.PrjNode.setPrjCell(m_Cell);
	}
	
	
	@Override
	public <T> NodeInfo<?> getNodeInfo(T nd) {
		if (nd == null) {
			NodeInfo<?> root = ProjService.perpareRootNode();
			return root;
		}else if(nd instanceof PrjNode){
			PrjNode node = (PrjNode) nd;
			return node.getNodeInfo();
		}
		CommMsg.log_info("#PrjTreeViewModel", "getNodeInfo():null node");//$NON-NLS-1$//$NON-NLS-2$
		return null;
	}

	@Override
	public boolean isLeaf(Object value) {
		if( value instanceof PrjNode){
			return ((PrjNode)value).isLeaf();
		}
	    return false;
	}

}
