package com.patac.checklist.internal.ui.common.widgets.cuspanel.territory;

import java.util.List;

import com.cus.comm.published.utils.CommUtils;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.gwtplatform.mvp.client.View;
import com.patac.checklist.internal.types.CTypes;
import com.siemens.splm.clientfx.base.published.IPropertyChangeListener;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelType;
import com.siemens.splm.clientfx.kernel.published.ITypeName;
import com.siemens.splm.clientfx.tcui.utils.published.IPropertyPolicyDelegateFactory;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.AbstractTcXRTPresenterW;
import com.siemens.splm.clientfx.ui.commands.published.ICommandContext;
import com.siemens.splm.clientfx.ui.published.ISubLocationService;
import com.siemens.splm.clientfx.ui.published.presenters.IPresenterDelegate;
import com.siemens.splm.clientfx.ui.selection.published.CommandContextSelection;
import com.siemens.splm.clientfx.ui.selection.published.CommandContextSelectionElement;
import com.siemens.splm.clientfx.ui.selection.published.ICommandContextSelection;
import com.siemens.splm.clientfx.ui.selection.published.ICommandContextSelectionElement;
import com.siemens.splm.clientfx.ui.selection.published.ISelectionService;
import com.siemens.splm.clientfx.xrt.published.databind.viewmodel.IXRTViewModel;
import com.siemens.splm.clientfx.xrt.published.model.IXRTRenderingElement;

public class PropTerriPresenterW 
extends AbstractTcXRTPresenterW<PropTerriPresenterW.MyView>
implements ICommandContext
{
	public final static String OBJVIEW_LOC = "com.siemens.splm.clientfx.tcui.xrt.showObject";
    /**
     * The selected object
     */
    private IModelObject m_sel_obj;
    
    /**
     * The context object
     */
    private IModelObject m_contextObject;
    
    /**
     * The Rendering element being rendered by this presenter
     */
    private IXRTRenderingElement m_renderingElement;
    
    /**
     * The selection service
     */
    @Inject
    private ISelectionService m_selectionSvc;
    
    @Inject
    private ISubLocationService m_subLocationSvc;
	
    public interface MyView
    extends View
	{
		void loadPropValues(IModelObject obj, IModelType type);
	}
    
    @Inject
	public PropTerriPresenterW(EventBus eventBus, MyView view, IPropertyPolicyDelegateFactory propPolicyFactory) {
		super(eventBus, view);
        IPresenterDelegate delegate = propPolicyFactory.create(com.patac.checklist.internal.Resources.INSTANCE.getC7tPropertyPolicy() );
        addDelegate( delegate );
	}

    @Override
    public ICommandContextSelection getSelection()
    {
        ICommandContextSelectionElement commandContextSelectionElement = new CommandContextSelectionElement(m_contextObject, this );
        return new CommandContextSelection( commandContextSelectionElement );
    }
    
    @Override
	protected void onReveal()
    {
        super.onReveal();
        CommUtils.loadType(CTypes.C7t_CheckDef, new AsyncCallback<IModelType> (){
			@Override
			public void onFailure(Throwable caught) {		
			}

			@Override
			public void onSuccess(IModelType type) {		
				getView().loadPropValues(m_sel_obj, type);
			}});        	
    }
    
	@Override
	public void init(IXRTViewModel viewModel, IXRTRenderingElement element, IPropertyChangeListener lsnr) {
        init( viewModel, lsnr );
        m_renderingElement = element;
        m_contextObject = viewModel.getObject();
        List<IModelObject> selectedObjs = m_selectionSvc.getSelectedModelObjects( getSelection(),  ITypeName.WorkspaceObject );
        if( selectedObjs.size() > 0 )
        {
        	m_sel_obj = selectedObjs.get( 0 );
        }
	}

	@Override
	public IXRTRenderingElement getRenderingElement() {
		return m_renderingElement;
	}

}
