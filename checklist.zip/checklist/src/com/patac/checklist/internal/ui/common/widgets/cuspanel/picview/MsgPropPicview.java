package com.patac.checklist.internal.ui.common.widgets.cuspanel.picview;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;

public interface MsgPropPicview 
extends Messages{
	MsgPropPicview INSTANCE = GWT.create(MsgPropPicview.class);
	
    String selectedVal();
    String textOK();
    String textClose();
}
