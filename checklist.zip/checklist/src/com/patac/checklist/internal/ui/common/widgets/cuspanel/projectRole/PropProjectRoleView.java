package com.patac.checklist.internal.ui.common.widgets.cuspanel.projectRole;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.cus.comm.published.utils.CommConfig;
import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.comm.published.utils.ICommService;
import com.cus.comm.widgets.dlg.cuspanel.TitledLovProperty;
import com.cus.comm.widgets.numpic.NumberPickProperty;
import com.cus.commrpc.published.DownFileAsStringService;
import com.cus.commrpc.published.DownFileAsStringServiceAsync;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.safehtml.shared.SafeUri;
import com.google.gwt.safehtml.shared.UriUtils;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.patac.checklist.internal.types.CTypes;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelType;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IPropertyDescription;

/**
 * View for SearchPanel.
 */
public class PropProjectRoleView
	implements PropProjectRolePresenterW.MyView
{
	private final DownFileAsStringServiceAsync fsSvr = GWT.create(DownFileAsStringService.class);
	private final static String C7T_PROJROLE_FILE = "/lovfile/project/";
	private final static String TERRITORY_FILE_SUF = ".json";
	
	private final static String KEY_STATE = "states";
	private final static String KEY_PROJROLE = "projectrole";
	
	@Inject
	ICommService commSvr;
	
    /**
     * Widget
     */
    private final Widget m_widget;
    
    private IModelObject m_sel_obj;
    
    private String 	m_prop_projRole_id	= CTypes.c7t_Project_role_id;
    private String  m_prop_projRole_name = CTypes.c7t_Project_role_name;
    
    private String  m_prop_stat_name = CTypes.c7t_app_states;
    private TitledLovProperty m_prop = null;
    private Vector<String> m_prop_v = new Vector<String>();
    private List<ProjectRole> projRoleList = new ArrayList<ProjectRole>();
    private NumberPickProperty m_mumpic = null;

	private int m_x;
	private int m_y;
	

    
    @UiField
    Label lovPanLabel;
	@UiField
	VerticalPanel lovPanel;
	
     /**
     * Ui binder
     */
    public interface Binder
        extends UiBinder<Widget, PropProjectRoleView>
    {
        //
    }

    /**
     * Constructor
     * 
     * @param binder Ui binder
     */
    @Inject
    public PropProjectRoleView( final Binder binder )
    {
        m_widget = binder.createAndBindUi( this );
        lovPanLabel.setVisible(false);
    }
	
	private void initTerritory(String terriStr){
		if(terriStr==null)
			return;
		JSONValue root = null;
		try{
			root = JSONParser.parseStrict(terriStr);
		}catch(IllegalArgumentException e){
			CommMsg.showMsg(e.getLocalizedMessage());
		}
		JSONObject rootObj = root.isObject();
		if(null==rootObj)
			return;
		
		JSONValue rootTree = rootObj.get(KEY_PROJROLE);
		if(null==rootTree)
			return;
		JSONArray rootContent = rootTree.isArray();
		if(rootContent==null)
			return;
		for(int i=0; i<rootContent.size(); i++){
			JSONValue one = rootContent.get(i);
			if(one==null)
				continue;
			JSONObject Obj = one.isObject();
			
			JSONValue id = Obj.get("function_id");
			JSONString idstr = id.isString();
			if(idstr == null)
				continue;
			String valid = idstr.stringValue();
			
			JSONValue name = Obj.get("function_name");
			JSONString namestr = name.isString();
			if(namestr == null)
				continue;
			String valname = namestr.stringValue();

			ProjectRole terr = new ProjectRole();
			
			terr.setId(valid);
			terr.setName(valname);
			
			projRoleList.add(terr);
			
			if(m_prop_v.contains(terr.getName())==false)
				m_prop_v.add(terr.getName());
		}	
	}
	
	private void saveLovProp(String val){
		m_prop.SetPropertyValue(val);
		if(m_sel_obj==null)
			return;
		for(int i = 0; i < projRoleList.size(); i++) {
			if(projRoleList.get(i).getName()==val) {
				CommUtils.saveStringProp(m_sel_obj, m_prop_projRole_id, projRoleList.get(i).getId());
				CommUtils.saveStringProp(m_sel_obj, m_prop_projRole_name, projRoleList.get(i).getName());
			}
			
		}
		
	}
	
	private void savePickProp(Vector<String> states){
		if(m_sel_obj==null)
			return;
		if(states==null || states.size()==0){
			CommUtils.saveStringAarrayProp(m_sel_obj, m_prop_stat_name, new String[]{});
		}else{			
			CommUtils.saveStringAarrayProp(m_sel_obj, m_prop_stat_name, states.toArray(new String[states.size()]));
		}
	}
	
	private void showFilterDlg(){
		ArrayList<String> lovs = new ArrayList<String>();			
		for(String key : m_prop_v){
			lovs.add(key);
		}
		final PropProjectRoleDlg dlg = PropProjectRoleDlg.showDialog(lovs, m_x-400, m_y);
		dlg.setOkHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				saveLovProp(dlg.getSelectValue());
				dlg.hide();
			}}, MsgPropTerri.INSTANCE.textOK());
	}    
    
	private void initTerriPropUI(IModelType type){
		if(m_prop==null && m_prop_projRole_name!=null){
			IPropertyDescription pd = CommUtils.getPropertyDescription(type, m_prop_projRole_name);
			if(pd==null)
				return;
			m_prop= new TitledLovProperty(pd.getDisplayName(), "");
			if(m_sel_obj!=null){
				IProperty<String> pp = (IProperty<String>) m_sel_obj.getPropertyObject(m_prop_projRole_name);
				if(pp!=null){
					String val = pp.getValue();
					m_prop.SetPropertyValue(val);
				}					
			}			
			lovPanel.add(m_prop);
			if(m_sel_obj!=null && CommUtils.isObjModifiableForMe(m_sel_obj))
				m_prop.setEditable(true);
			else
				m_prop.setEditable(false);
			m_prop.setSearchHandler(new ClickHandler(){
				@Override
				public void onClick(ClickEvent event) {
					m_x = event.getClientX();m_y = event.getClientY();
					showFilterDlg();
				}});
		}
	}
	
	
	private String[] initStatue(String result){		
		if(result==null)
			return null;
		JSONValue root = null;
		try{
			root = JSONParser.parseStrict(result);
		}catch(IllegalArgumentException e){
			CommMsg.showMsg(e.getLocalizedMessage());
		}
		JSONObject rootObj = root.isObject();
		if(rootObj==null)
			return null;
		
		JSONValue rootTree = rootObj.get(KEY_STATE);
		if(rootTree==null)
			return null;
		JSONArray rootContent = rootTree.isArray();
		if(rootContent==null)
			return null;
		Vector<String> values = new Vector<String>();
		for(int i=0; i<rootContent.size(); i++){
			JSONValue one = rootContent.get(i);
			if(one==null)
				continue;
			JSONString onestr = one.isString();
			if(onestr==null)
				continue;
			String val = onestr.stringValue();
			if(values.contains(val)==false)
				values.add(val);
		}
		return values.toArray(new String[values.size()]);
	}
	
	private void getTerritoryJson(final IModelType type){
		CommConfig.getConfigFile(new AsyncCallback<String> (){
			@Override
			public void onFailure(Throwable caught) {
				CommMsg.showMsg(caught.getLocalizedMessage());
			}

			@Override
			public void onSuccess(String url) {//CommUtils.getUserGroupFull()
				final String url2 = url + C7T_PROJROLE_FILE + CommUtils.getUserGroupFull() + TERRITORY_FILE_SUF;
				final SafeUri suri = UriUtils.fromString(url2);
				fsSvr.downFileAsString(suri.asString(), new AsyncCallback<String> (){
					@Override
					public void onFailure(Throwable caught) {
						CommMsg.showMsg(suri.asString());
					}

					@Override
					public void onSuccess(String result) {
						if(result==null)
							CommMsg.showMsg(url2);
						initTerritory(result);
						initTerriPropUI(type);
					}});
			}});		
	}
	
	@Override
	public void loadPropValues(IModelObject obj, final IModelType type){
		m_sel_obj = obj;
		lovPanel.clear();
		getTerritoryJson(type);
	}	
	
	@Override
	public Widget asWidget() {
		return m_widget;
	}

	@Override
	public void addToSlot(Object slot, Widget content) {
	
	}

	@Override
	public void removeFromSlot(Object slot, Widget content) {
		
	}

	@Override
	public void setInSlot(Object slot, Widget content) {
		
	}
	
}
