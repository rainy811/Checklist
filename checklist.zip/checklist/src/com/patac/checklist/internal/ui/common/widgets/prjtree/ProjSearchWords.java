package com.patac.checklist.internal.ui.common.widgets.prjtree;

import java.util.HashMap;
import java.util.Map;

public class ProjSearchWords {
	private Map<String, String> m_map = new HashMap<String, String>(); 
	
	public void clean(){
		m_map.clear();
	}
	
	public void add(String name, String val){
		if(m_map.containsKey(m_map)){
			m_map.remove(name);
		}
		m_map.put(name, val);
	}
	
	public Map<String, String> getMap(){
		return m_map;
	}
}
