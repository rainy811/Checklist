package com.patac.checklist.internal.ui.common.widgets.cuspanel.importance;

import java.util.ArrayList;
import java.util.Vector;

import com.cus.comm.published.utils.CommConfig;
import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.comm.published.utils.ICommService;
import com.cus.comm.widgets.dlg.cuspanel.TitledLovProperty;
import com.cus.comm.widgets.numpic.NumberPickProperty;
import com.cus.commrpc.published.DownFileAsStringService;
import com.cus.commrpc.published.DownFileAsStringServiceAsync;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.safehtml.shared.SafeUri;
import com.google.gwt.safehtml.shared.UriUtils;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.patac.checklist.internal.types.CTypes;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelType;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IPropertyDescription;

/**
 * View for SearchPanel.
 */
public class PropImportanceView
	implements PropImportancePresenterW.MyView
{
	private final DownFileAsStringServiceAsync fsSvr = GWT.create(DownFileAsStringService.class);
	private final static String C7T_IMPORTANCE_FILE = "/lovfile/importance/";
	private final static String IMPORTANCE_FILE_SUF = ".json";
	
	private final static String KEY_STATE = "states";
	private final static String KEY_IMPORTANCE = "importance";
	
	@Inject
	ICommService commSvr;
	
    /**
     * Widget
     */
    private final Widget m_widget;
    
    private IModelObject m_sel_obj;
    
    private String  m_prop_importance_name = CTypes.c7t_Importance;
    private String  m_prop_stat_name = CTypes.c7t_app_states;
    private TitledLovProperty m_prop = null;
    private Vector<String> m_prop_v = new Vector<String>();
    private NumberPickProperty m_mumpic = null;

	private int m_x;
	private int m_y;
    
    @UiField
    Label lovPanLabel;
	@UiField
	VerticalPanel lovPanel;
	
     /**
     * Ui binder
     */
    public interface Binder
        extends UiBinder<Widget, PropImportanceView>
    {
        //
    }

    /**
     * Constructor
     * 
     * @param binder Ui binder
     */
    @Inject
    public PropImportanceView( final Binder binder )
    {
        m_widget = binder.createAndBindUi( this );
        lovPanLabel.setVisible(false);
    }
	
	private void initDevLvl(String devLvlStr){
		if(devLvlStr==null)
			return;
		JSONValue root = null;
		try{
			root = JSONParser.parseStrict(devLvlStr);
		}catch(IllegalArgumentException e){
			CommMsg.showMsg(e.getLocalizedMessage());
		}
		JSONObject rootObj = root.isObject();
		if(null==rootObj)
			return;
		
		JSONValue rootTree = rootObj.get(KEY_IMPORTANCE);
		if(null==rootTree)
			return;
		JSONArray rootContent = rootTree.isArray();
		if(rootContent==null)
			return;
		for(int i=0; i<rootContent.size(); i++){
			JSONValue one = rootContent.get(i);
			if(one==null)
				continue;
			JSONString onestr = one.isString();
			if(onestr==null)
				continue;
			String val = onestr.stringValue();
			if(m_prop_v.contains(val)==false)
				m_prop_v.add(val);
		}	
	}
	
	private void saveLovProp(String val){
		m_prop.SetPropertyValue(val);
		if(m_sel_obj==null)
			return;
		CommUtils.saveStringProp(m_sel_obj, m_prop_importance_name, val);
	}
	
	private void savePickProp(Vector<String> states){
		if(m_sel_obj==null)
			return;
		if(states==null || states.size()==0){
			CommUtils.saveStringAarrayProp(m_sel_obj, m_prop_stat_name, new String[]{});
		}else{			
			CommUtils.saveStringAarrayProp(m_sel_obj, m_prop_stat_name, states.toArray(new String[states.size()]));
		}
	}
	
	private void showFilterDlg(){
		ArrayList<String> lovs = new ArrayList<String>();			
		for(String key : m_prop_v){
			lovs.add(key);
		}
		final PropImportanceDlg dlg = PropImportanceDlg.showDialog(lovs, m_x-400, m_y);
		dlg.setOkHandler(new ClickHandler(){
			@Override
			public void onClick(ClickEvent event) {
				saveLovProp(dlg.getSelectValue());
				dlg.hide();
			}}, MsgPropImportance.INSTANCE.textOK());
	}    
    
	private void initDevlvlPropUI(IModelType type){
		if(m_prop==null && m_prop_importance_name!=null){
			IPropertyDescription pd = CommUtils.getPropertyDescription(type, m_prop_importance_name);
			if(pd==null)
				return;
			m_prop= new TitledLovProperty(pd.getDisplayName(), "");
			if(m_sel_obj!=null){
				IProperty<String> pp = (IProperty<String>) m_sel_obj.getPropertyObject(m_prop_importance_name);
				if(pp!=null){
					String val = pp.getValue();
					m_prop.SetPropertyValue(val);
				}					
			}			
			lovPanel.add(m_prop);
			if(m_sel_obj!=null && CommUtils.isObjModifiableForMe(m_sel_obj))
				m_prop.setEditable(true);
			else
				m_prop.setEditable(false);
			m_prop.setSearchHandler(new ClickHandler(){
				@Override
				public void onClick(ClickEvent event) {
					m_x = event.getClientX();m_y = event.getClientY();
					showFilterDlg();
				}});
		}
	}
	
	
	private String[] initStatue(String result){		
		if(result==null)
			return null;
		JSONValue root = null;
		try{
			root = JSONParser.parseStrict(result);
		}catch(IllegalArgumentException e){
			CommMsg.showMsg(e.getLocalizedMessage());
		}
		JSONObject rootObj = root.isObject();
		if(null==rootObj)
			return null;
		
		JSONValue rootTree = rootObj.get(KEY_STATE);
		if(null==rootTree)
			return null;
		JSONArray rootContent = rootTree.isArray();
		if(rootContent==null)
			return null;
		Vector<String> values = new Vector<String>();
		for(int i=0; i<rootContent.size(); i++){
			JSONValue one = rootContent.get(i);
			if(one==null)
				continue;
			JSONString onestr = one.isString();
			if(onestr==null)
				continue;
			String val = onestr.stringValue();
			if(values.contains(val)==false)
				values.add(val);
		}
		return values.toArray(new String[values.size()]);
	}
	
	private void getDevLvlJson(final IModelType type){
		CommConfig.getConfigFile(new AsyncCallback<String> (){
			@Override
			public void onFailure(Throwable caught) {
				CommMsg.showMsg(caught.getLocalizedMessage());
			}

			@Override
			public void onSuccess(String url) {//CommUtils.getUserGroupFull()
				final String url2 = url + C7T_IMPORTANCE_FILE + "importance" + IMPORTANCE_FILE_SUF;
				final SafeUri suri = UriUtils.fromString(url2);
				fsSvr.downFileAsString(suri.asString(), new AsyncCallback<String> (){
					@Override
					public void onFailure(Throwable caught) {
						CommMsg.showMsg(suri.asString());
					}

					@Override
					public void onSuccess(String result) {
						if(result==null)
							CommMsg.showMsg(url2);
						initDevLvl(result);
						initDevlvlPropUI(type);
					}});
			}});		
	}
	
	@Override
	public void loadPropValues(IModelObject obj, final IModelType type){
		m_sel_obj = obj;
		lovPanel.clear();
		getDevLvlJson(type);
	}	
	
	@Override
	public Widget asWidget() {
		return m_widget;
	}

	@Override
	public void addToSlot(Object slot, Widget content) {
	
	}

	@Override
	public void removeFromSlot(Object slot, Widget content) {
		
	}

	@Override
	public void setInSlot(Object slot, Widget content) {
		
	}
	
}
