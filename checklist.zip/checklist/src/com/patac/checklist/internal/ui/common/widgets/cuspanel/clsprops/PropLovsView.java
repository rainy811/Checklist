package com.patac.checklist.internal.ui.common.widgets.cuspanel.clsprops;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.cus.comm.published.utils.CommConfig;
import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.comm.published.utils.ICommService;
import com.cus.comm.widgets.dlg.cuspanel.TitledLovProperty;
import com.cus.commrpc.published.DownFileAsStringService;
import com.cus.commrpc.published.DownFileAsStringServiceAsync;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelType;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IPropertyDescription;
import com.siemens.splm.clientfx.tcui.utils.published.ModelUtils;

/**
 * View for SearchPanel.
 */
public class PropLovsView
	implements PropLovsPresenterW.MyView
{
	private final DownFileAsStringServiceAsync fsSvr = GWT.create(DownFileAsStringService.class);
	private final static String C7TLOV_FILE = "/lovfile/c7tlov.json";
	private final static String NULL_STRING = "null";
	
	@Inject
	ICommService commSvr;
	
    /**
     * Widget
     */
    private final Widget m_widget;
    
    private IModelObject m_sel_obj;
    private String [] m_lov_names = {null, null, null};
    private TitledLovProperty[] m_lov_ary = {null, null, null}; 

	private Map<String, Object> m_tree = new HashMap<String, Object>();
	private int m_x;
	private int m_y;
    
    @UiField
    Label lovPanLabel;
	@UiField
	VerticalPanel lovPanel;
	
     /**
     * Ui binder
     */
    public interface Binder
        extends UiBinder<Widget, PropLovsView>
    {
        //
    }

    /**
     * Constructor
     * 
     * @param binder Ui binder
     */
    @Inject
    public PropLovsView( final Binder binder )
    {
        m_widget = binder.createAndBindUi( this );
    }
	
	private void createLOV(String result){
		if(result==null)
			return;
		JSONValue root = null;
		try{
			root = JSONParser.parseStrict(result);
		}catch(IllegalArgumentException e){
			CommMsg.showMsg(e.getLocalizedMessage());
		}
		JSONObject rootObj = root.isObject();
		if(null==rootObj)
			return;
		
		JSONValue nameG = rootObj.get("gradeName");
		if(nameG!=null && nameG.isObject()!=null ){
			JSONObject nmg = nameG.isObject();
			JSONValue name1 = nmg.get("firName");
			JSONValue name2 = nmg.get("secName");
			JSONValue name3 = nmg.get("thirName");
			if(name1!=null && name1.isString()!=null){
				m_lov_names[0] = name1.isString().stringValue();
			}
			if(name2!=null && name2.isString()!=null){
				m_lov_names[1] = name2.isString().stringValue();
			}
			if(name3!=null && name3.isString()!=null){
				m_lov_names[2] = name3.isString().stringValue();
			}
			for(int i=0; i<m_lov_names.length; i++){
				String name = m_lov_names[i];
				if(NULL_STRING.equalsIgnoreCase(name.trim())){
					m_lov_names[i] = null;
				}
			}
		}
		
		JSONValue rootTree = rootObj.get("jsonTree");
		if(null==rootTree)
			return;
		JSONArray rootContent = rootTree.isArray();		
		if(rootContent==null)
			return;
		for(int i=0; i<rootContent.size(); i++){
			JSONValue obv1 = rootContent.get(i);
			if(obv1==null)
				continue;
			JSONObject obj1 = obv1.isObject();
			if(obj1==null)
				continue;
			JSONValue namev = obj1.get("name");
			if(namev==null)
				continue;
			JSONString names = namev.isString();
			if(names==null)
				continue;
			String name = names.stringValue();
			m_tree.put(name, new HashMap<String, Object>());
			JSONValue subv = obj1.get("sub");			
			if(subv==null)
				continue;
			JSONArray suba = subv.isArray();
			if(suba==null)
				continue;
			createLovInt(name, suba, m_tree);
		}
	}
	
	private void createLovInt(String curKey, JSONArray objs, Map<String, Object> map){
		for(int i=0; i<objs.size(); i++){
			Map<String, Object> curMap = (Map<String, Object>) map.get(curKey);
			if(null==curMap)
				continue;
			JSONValue obv = objs.get(i);
			if(obv==null)
				continue;
			JSONObject obj = obv.isObject();
			if(obj==null)
				continue;
			JSONValue namev = obj.get("name");
			if(namev==null)
				continue;
			JSONString names = namev.isString();
			if(names==null)
				continue;
			String name = names.stringValue();
			curMap.put(name, new HashMap<String, Object>());
			JSONValue subv = obj.get("sub");
			if(subv==null)
				continue;
			JSONArray suba = subv.isArray();
			if(suba==null)
				continue;
			createLovInt(name, suba, curMap);
		}
	}
	
	private void saveLovProp(int lvl, String val){
		if(lvl <0 || lvl>=m_lov_ary.length){
			return;
		}
		TitledLovProperty pp = m_lov_ary[lvl];
		if(pp==null)
			return;
		pp.SetPropertyValue(val);
		if(m_sel_obj==null)
			return;
		CommUtils.saveStringProp(m_sel_obj, m_lov_names[lvl], val);
	}
	
	private void showFilterDlg(int level){
		Map<String, Object> tmap = m_tree;
		if(tmap==null)
			return;
		Set<String> keyset = tmap.keySet();
		if(tmap.size()<=0)
			return;
		for(int i=0; i<=level; i++){
			if(i==level){
				if(keyset==null)
					return;
				ArrayList<String> lovs = new ArrayList<String>();			
				for(String key : keyset){
					lovs.add(key);
				}
				final PropLovDlg dlg = PropLovDlg.showDialog(lovs, m_x, m_y);
				final int ilvl = i;
				dlg.setOkHandler(new ClickHandler(){
					@Override
					public void onClick(ClickEvent event) {
						saveLovProp(ilvl, dlg.getSelectValue());
						dlg.hide();
					}}, MsgPropLov.INSTANCE.textOK());
			}
			else{
				TitledLovProperty lov = m_lov_ary[i] ;
				String val = lov.getPropertyValue();
				Object map = tmap.get(val);
				if(map==null)
					return;//empty map
				Map<String, Object> mmap = (Map<String, Object>)map;
				keyset = mmap.keySet();
				tmap = mmap;
			}
		}
	}    
    
    private void initLovs(final IModelType type){
		for(int i=0; i<m_lov_names.length; i++){
			String name = m_lov_names[i];
			if(null==name)
				continue;
			if(m_lov_ary[i]==null){
				IPropertyDescription pd = CommUtils.getPropertyDescription(type, name);
				if(pd==null)
					continue;
				m_lov_ary[i] = new TitledLovProperty(pd.getDisplayName(), "");
				lovPanel.add(m_lov_ary[i]);
				final int level = i;
				if(m_sel_obj!=null && CommUtils.isObjModifiableForMe(m_sel_obj))
					m_lov_ary[i].setEditable(true);
				else
					m_lov_ary[i].setEditable(false);
				m_lov_ary[i].setSearchHandler(new ClickHandler(){
					@Override
					public void onClick(ClickEvent event) {
						m_x = event.getClientX();m_y = event.getClientY();						
						showFilterDlg(level);
					}});
			}
			if(m_sel_obj==null)
				continue;
			IProperty<?> pp = m_sel_obj.getPropertyObject(name);
			if(pp==null)
				continue;
			String aval = pp.getDisplayValue();	
			if(m_lov_ary[i]!=null)
				m_lov_ary[i].SetPropertyValue(aval);
		}
    }
	
	@Override
	public void loadLovValues(IModelObject obj, final IModelType type){
		m_sel_obj = obj;
		lovPanel.clear();
		if(m_sel_obj!=null){
			CommConfig.getConfigFile(new AsyncCallback<String> (){
				@Override
				public void onFailure(Throwable caught) {
					CommMsg.showMsg(caught.getLocalizedMessage());
				}

				@Override
				public void onSuccess(String url) {
					url = url + C7TLOV_FILE;
					fsSvr.downFileAsString(url, new AsyncCallback<String>() {
						public void onFailure(Throwable caught) {
							CommMsg.log_err("#", "#can not load file "+ C7TLOV_FILE);
						}

						public void onSuccess(final String strlov) {
							if(strlov==null)
								CommMsg.log_info("#loadLovValues:onSuccess()", "#lov file "+C7TLOV_FILE+" not exist!");
							ModelUtils.ensurePropertiesLoaded(m_sel_obj, m_lov_names, new AsyncCallback<Void>(){
								@Override
								public void onFailure(Throwable caught) {										
								}

								@Override
								public void onSuccess(Void result) {
									createLOV(strlov);
									initLovs(type);
								}
							});
						}}
					);		
				}
			});

		}else{
			initLovs(type);
		}
	}	
	
	@Override
	public Widget asWidget() {
		return m_widget;
	}

	@Override
	public void addToSlot(Object slot, Widget content) {
	
	}

	@Override
	public void removeFromSlot(Object slot, Widget content) {
		
	}

	@Override
	public void setInSlot(Object slot, Widget content) {
		
	}
	
}
