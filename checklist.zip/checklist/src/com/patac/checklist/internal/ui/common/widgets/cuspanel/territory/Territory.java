package com.patac.checklist.internal.ui.common.widgets.cuspanel.territory;

public class Territory {
	
	private String function_id = null;
	
	private String function_name = null;
	
	private String function_fo = null ; 

	private String function_fo_id = null;

	public String getId() {
		return function_id;
	}

	public void setId(String function_id) {
		this.function_id = function_id;
	}

	public String getName() {
		return function_name;
	}

	public void setName(String function_name) {
		this.function_name = function_name;
	}

	public String getFo() {
		return function_fo;
	}

	public void setFo(String function_fo) {
		this.function_fo = function_fo;
	}

	public String getFoId() {
		return function_fo_id;
	}

	public void setFoId(String function_fo_id) {
		this.function_fo_id = function_fo_id;
	}
	
	
	
	
}
