package com.patac.checklist.internal.ui.common.widgets.cuspanel.vehicle;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;

public interface MsgPropVehicle 
extends Messages{
	MsgPropVehicle INSTANCE = GWT.create(MsgPropVehicle.class);
	
    String selectedVal();
    String textOK();
    String textClose();
}
