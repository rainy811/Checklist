package com.patac.checklist.internal.ui.common.widgets.prjtree;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cus.comm.published.utils.CommConfig;
import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.comm.svr.OpValue;
import com.cus.commrpc.published.DownFileAsStringService;
import com.cus.commrpc.published.DownFileAsStringServiceAsync;
import com.google.gwt.cell.client.Cell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.view.client.DefaultSelectionEventManager;
import com.google.gwt.view.client.ListDataProvider;
import com.google.gwt.view.client.MultiSelectionModel;
import com.google.gwt.view.client.TreeViewModel.DefaultNodeInfo;
import com.google.gwt.view.client.TreeViewModel.NodeInfo;
import com.google.web.bindery.event.shared.EventBus;
import com.patac.checklist.internal.event.handlers.RenderTreeEvent;
import com.patac.checklist.internal.service.CSoaService;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.tcui.utils.published.DataManagementService;
import com.siemens.splm.clientfx.tcui.utils.published.DataManagementService.CreateIn;
import com.siemens.splm.clientfx.tcui.utils.published.DataManagementService.CreateInput;
import com.siemens.splm.clientfx.tcui.utils.published.DataManagementService.CreateResponse;


public class ProjService {
	private final static String C7T_PRJ_FILE_PATH = "/projects/";
	private final static String JSON_SUF = ".json";
	
	//m_root_node
	//              |-- m_tree_root
	private static PrjNode m_tree_root = new PrjNode();
	private static PrjNode m_root_node = new PrjNode();//real root
	private static ArrayList<PrjNode> m_nodeList = new ArrayList<PrjNode>();
	private static int m_nodeList_processed = 0;
	private static Map<Integer, NodeInfo<?>> mCellMap = new HashMap<Integer, NodeInfo<?>>();
	private static EventBus m_eventbus = null;
	
	public static void process_plus(){
		m_nodeList_processed++;
		if(m_nodeList_processed>=m_nodeList.size()){
			CommMsg.log_info("#ProjService", "Finish process trigger render.");
			if(null!=m_eventbus){
				m_eventbus.fireEvent(new RenderTreeEvent());
			}
		}
	}
	
	public static void findProj(String name, String dept, AsyncCallback<List<IModelObject>> callback){
    	Map<String, OpValue> attrmap = new HashMap<String, OpValue>();
    	attrmap.put(CTypes.object_name, new OpValue(name, OpValue.MATH_OP_EQUAL));
    	attrmap.put(CTypes.c7t_dept, new OpValue(dept, OpValue.MATH_OP_EQUAL));
    	CSoaService.findObjsAnd(attrmap, CTypes.C7t_Prj_Item, CTypes.getProjItemProps(), callback);
	}
	
	public static void createProj(String name, String dept, final AsyncCallback<CreateResponse> callback){
    	CreateIn[] createInArray = new CreateIn[1];
        CreateIn createIn = new CreateIn();
        createIn.clientId = "constructCreateInput" ; //$NON-NLS-1$
        CreateInput rootCreateInput = new CreateInput();
        rootCreateInput.boName = CTypes.C7t_Prj_Item;
        createIn.data = rootCreateInput;
        Map<String, CreateInput> createInputMap = new HashMap<>();
        createInputMap.put( "", rootCreateInput ); //$NON-NLS-1$
        rootCreateInput.stringProps.put(CTypes.c7t_dept, dept);
        rootCreateInput.stringProps.put(CTypes.object_name, name);
        createInArray[0] = createIn;
    	DataManagementService.createObjects( createInArray, new AsyncCallback<CreateResponse>(){
			@Override
			public void onFailure(Throwable caught) {
				callback.onFailure( caught );
			}

			@Override
			public void onSuccess(CreateResponse result) {
				callback.onSuccess(result);
			}    	
    	});
	}
	
	public static void saveEventBus(EventBus eventbus){
		m_eventbus  = eventbus;
	}
	
	public static int findWithCode(String c){
		for(int i=0; i<m_nodeList.size(); i++){
			PrjNode node = m_nodeList.get(i);
			if(c.equals(node.getCode()))
				return i;
		}
		return -1;
	}
	
	public static int findWithName(String str){
		for(int i=0; i<m_nodeList.size(); i++){
			PrjNode node = m_nodeList.get(i);
			String name = node.getDisplayName();
			if(name !=null && name.contains(str))
				return i;
		}
		return -1;
	}
	
	public static PrjNode getVsNodeByIndex(int index){
		return m_nodeList.get(index);
	}
	
	public static void refreshRoot(){
		perpareRootNode();
		m_root_node.refresh();
	}
	
	public static PrjNode getRootNode(){
		return m_root_node;
	}
	
	private static void getAvailablePrjJson(final ProjCellTreeView tv){
		CommConfig.getConfigFile(new AsyncCallback<String> (){
			@Override
			public void onFailure(Throwable caught) {
				CommMsg.showMsg(caught.getLocalizedMessage());
			}

			@Override
			public void onSuccess(String url) {
				DownFileAsStringServiceAsync fsSvr = GWT.create(DownFileAsStringService.class);
				final String url2 = url + C7T_PRJ_FILE_PATH + CommUtils.getUserGroupFull() + JSON_SUF;
				fsSvr.downFileAsString(url2, new AsyncCallback<String> (){
					@Override
					public void onFailure(Throwable caught) {
						CommMsg.showMsg(caught.getLocalizedMessage());
					}

					@Override
					public void onSuccess(String result) {
						if(result==null)
							CommMsg.showMsg(url2);
						ProjService.initProjects(result, tv);
					}});
			}});		
	}
	
	private static void initProjects(String json, final ProjCellTreeView tv){
		if(null==json)
			return;		
		JSONValue root = JSONParser.parseStrict(json);
		if(root==null)
			return;
		JSONArray  objs = root.isArray();
		ConstructTree(objs);
		CommMsg.log_info("#initProjects", "#size="+m_tree_root.getChildrenProvider().getList().size());
		tv.refreshTree();
	}
	
	public static void initData(final ProjCellTreeView tv){
		//define root node
		m_tree_root.clear();
		m_tree_root.setCode(ChecklistMessages.INSTANCE.txtProjType());
		m_tree_root.setName("");
		m_tree_root.setLevel(0);
		m_tree_root.setAbsoluteIndex(-1, m_nodeList.size());	
		
		m_nodeList.clear();
		getAvailablePrjJson(tv);	
	}
	
	private static void ConstructTree(JSONArray  jsonRoot) {
		for(int i=0; i<jsonRoot.size(); i++){
			JSONValue node = jsonRoot.get(i);
			JSONObject obj;
			if((obj = node.isObject())!=null){
				JSONValue codev = obj.get("code");
				String code = null;
				if(codev!=null && codev.isString()!=null){
					code = codev.isString().stringValue();
				}
				
				JSONValue namev = obj.get("name");
				String name = null;
				if(namev!=null && namev.isString()!=null){
					name = namev.isString().stringValue();
				}
				
				JSONValue statev = obj.get("states");
				JSONObject state = null;
				if(namev!=null && statev.isObject()!=null){
					state = statev.isObject();
					Set<String> times = state.keySet();
					Map<String, Date> mtimes = new HashMap<String, Date>();
					for(String tm : times){
						JSONValue tick = state.get(tm);
						if(tick!=null && tick.isNumber()!=null){
							double tk = tick.isNumber().doubleValue();
							long tl = (long) tk;
							Date atime = new Date(tl);
							mtimes.put(tm,  atime);
						}
					}
				}
				PrjNode sn = new PrjNode();
				sn.setCode(code);
				sn.setName(name);
				sn.setLevel(1);
				sn.setAbsoluteIndex(m_tree_root.getAbsoluteIndex(), m_nodeList.size());
				sn.searchExist();
				m_tree_root.addChild(sn);
				m_nodeList.add(sn);				
			}
		}		
	}
	
	public static NodeInfo<?>perpareRootNode(){
		if(null==m_root_node){
			CommMsg.log_info("#treeService", "perpareRooNode():this can not be reached!");//$NON-NLS-1$//$NON-NLS-2$
			m_root_node = new PrjNode();
			m_root_node.setCode("root");m_root_node.setName("r");
		}
		if(null != m_tree_root){
			m_root_node.clear();
			m_root_node.addChild(m_tree_root);
			CommMsg.log_info("#treeService", "perpareRooNode():root");//$NON-NLS-1$//$NON-NLS-2$
		}else{
			CommMsg.log_info("#treeService", "perpareRooNode():loading");//$NON-NLS-1$//$NON-NLS-2$
			PrjNode empty = new PrjNode();
			empty.setCode("loading...");
			empty.setName("loading...");
			m_root_node.clear();
			m_root_node.addChild(empty);
		}		
		return m_root_node.getNodeInfo();
	}
	
	public static class PrjNode implements Comparable<PrjNode>{
		private final static int CONTENT_LVL = 1;
		private final static int ID_START = 1000000;
		private String m_name;
		private String m_code;
		private boolean m_exist = false;
		private Map<String, Date> m_times = new HashMap<String, Date>();
		private int m_level=0;
		private int mAbsPaIndex = -1;
		private int mAbsIndex = -1;
		private final ListDataProvider<PrjNode> m_children_dataprovider = new ListDataProvider<PrjNode>();		
		private static MultiSelectionModel<PrjNode> mSelectionModel = new MultiSelectionModel<PrjNode>();
		private static Cell<PrjNode> m_Cell;		
		private static final DefaultSelectionEventManager<NodeInfo<?>> mSelectionManager = DefaultSelectionEventManager.createDefaultManager();
		
		public boolean isExist(){
			return m_exist;
		}
		
		public void searchExist(){
			ProjService.findProj(m_name, CommUtils.getUserGroupFull(), new AsyncCallback<List<IModelObject>>() {
				@Override
				public void onFailure(Throwable caught) {		
					ProjService.process_plus();
				}

				@Override
				public void onSuccess(List<IModelObject> result) {
					ProjService.process_plus();
					if(result!=null && result.size()>0){
						PrjNode.this.m_exist = true;
					}					
				}});
		}
		
		public boolean isContent(){
			if(m_level>=CONTENT_LVL)
				return true;
			else
				return false;
		}
		
		public static MultiSelectionModel<PrjNode> getSelectionModel(){			
			return mSelectionModel;
		}
		
		public static void setPrjCell(Cell<PrjNode> c){
			m_Cell = c;
		}
		
		public static int getID(int id){
			return id+ID_START;
		}
		
		public void setAbsoluteIndex(int pa, int me){
			mAbsPaIndex = pa;
			mAbsIndex = me;
		}
		
		public Map<String, Date> getTimes(){return m_times;}
		
		public void setTimes(Map<String, Date> times){
			m_times.clear();
			m_times.putAll(times);
		}
		
		public int getID(){
			return ID_START + mAbsIndex;
		}
		
		public int getAbsoluteIndex(){
			return mAbsIndex;
		}
		
		public int getAbsPaIndex(){
			return mAbsPaIndex;
		}
		
		@Override
		public int compareTo(PrjNode o) {
			return mAbsIndex - o.getAbsoluteIndex();
		}
		
		public void setCode(String c){
			m_code = c;
		}
		
		public String getCode(){return m_code;}
		public String getName(){return m_name;}
		
		public int getLevel(){return m_level;}
		
		public void setLevel(int lvl){
			m_level = lvl;
		}
		
		public void setName(String str){
			m_name= str;
		}
		
		public String getDisplayName(){			
			return m_name;
		}
		
		public boolean isLeaf(){
			if(m_children_dataprovider.getList().size()<=0)
				return true;
			return false;
		}
		
		public void addChild(PrjNode node){
			m_children_dataprovider.getList().add(node);
		}
		
		public  ListDataProvider<PrjNode> getChildrenProvider(){
			return m_children_dataprovider;
		}

		public NodeInfo<?> getNewCell() {
			if(m_children_dataprovider.getList().size()<=0)
				return null;
			return new DefaultNodeInfo<PrjNode>(m_children_dataprovider, m_Cell, mSelectionModel, null);
		}
		
		public NodeInfo<?> getNodeInfo() {
			if(mAbsIndex>=0){
				NodeInfo<?> node = mCellMap.get(mAbsIndex);
				if(null != node)
					return node;
			}
			
			NodeInfo<?> node = getNewCell();
			if(mAbsIndex>=0)
				mCellMap.put(mAbsIndex, node);
			return node;
		}
		
		public void refresh(){
			m_children_dataprovider.refresh();
		}
		
		public void clear(){
			m_children_dataprovider.getList().clear();
		}

	}
}
