package com.patac.checklist.internal.ui.common.widgets.cuspanel.importance;

import java.util.ArrayList;
import java.util.List;

import com.cus.comm.published.utils.CommMsg;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlexTable.FlexCellFormatter;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.LayoutPanel;
import com.google.gwt.user.client.ui.PushButton;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.ListDataProvider;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SingleSelectionModel;

public class PropImportanceDlg extends DialogBox {
	private Button closeButton;
	private Button okButton;
	private VerticalPanel m_dlgContents;

	private List nameList = new ArrayList<>();
	
	private CellTable<Cantact> firTable = new CellTable<Cantact>();
	private FlexTable selectedFlexTable = new FlexTable();
	public  String m_select_val = "";
	private ListDataProvider<Cantact> firdataProvider = new ListDataProvider<Cantact>();
	private TextBox searchTextBox = new TextBox();
	
	public static class Cantact {
		public String name;

		public Cantact(String name) {
			this.name = name;
		}

		public String getName() {
			return name;
		}
	}
	
	public List getData(){
		return nameList;
	}

	public String getSelectValue(){
		return m_select_val;
	}

	private PushButton searchButton = new PushButton(new Image(Resources.INSTANCE.filterImg()), new ClickHandler() {
		@Override
		public void onClick(ClickEvent event) {
			String value = searchTextBox.getText();
			firdataProvider.getList().clear();
			List arry = PropImportanceDlg.this.getData();
			for(int i =0; i < PropImportanceDlg.this.nameList.size(); i++){
				String nameValue = PropImportanceDlg.this.nameList.get(i).toString();
				if(nameValue.contains(value)){
					firdataProvider.getList().add(new Cantact(nameValue));
				}
				if(firdataProvider.getList().size() >= 10){
					break;
				}
			}
		}
	});

	public PropImportanceDlg() {
		super(true);
		closeButton = new Button("close");
		okButton = new Button("ok");
	}

	public VerticalPanel getContentPanel() {
		return m_dlgContents;
	}

	public void hideOkButton() {
		okButton.setVisible(false);
	}

	public void setOkEnable(boolean t) {
		okButton.setEnabled(t);
	}

	public static PropImportanceDlg createDialog(HTML details) {
		final PropImportanceDlg dlg = new PropImportanceDlg();
		VerticalPanel dlgContents = new VerticalPanel();
		dlgContents.setSpacing(2);
		dlg.setWidget(dlgContents);

		if (details != null) {
			dlgContents.add(details);
			dlgContents.setCellHorizontalAlignment(details,
					HasHorizontalAlignment.ALIGN_CENTER);
		}

		HorizontalPanel cmdPanel = new HorizontalPanel();
		dlgContents.add(cmdPanel);
		dlgContents.setCellHorizontalAlignment(cmdPanel,
				HasHorizontalAlignment.ALIGN_CENTER);
		cmdPanel.add(dlg.closeButton);
		cmdPanel.add(dlg.okButton);
		dlg.okButton.setStyleName("aw-cus-black-color", true);
		dlg.closeButton.setStyleName("aw-cus-black-color", true);
		cmdPanel.setHeight("60px");
		cmdPanel.setCellVerticalAlignment(dlg.closeButton,
				HasVerticalAlignment.ALIGN_BOTTOM);
		cmdPanel.setCellVerticalAlignment(dlg.okButton,
				HasVerticalAlignment.ALIGN_BOTTOM);
		cmdPanel.setCellHorizontalAlignment(dlg.closeButton,
				HasHorizontalAlignment.ALIGN_CENTER);
		cmdPanel.setCellHorizontalAlignment(dlg.okButton,
				HasHorizontalAlignment.ALIGN_CENTER);
		dlg.closeButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				dlg.hide();
			}

		});

		return dlg;
	}

	private static void setLayout(PropImportanceDlg dlg, FlexTable layout) {
		TextColumn<Cantact> firName = new TextColumn<Cantact>() {
			@Override
			public String getValue(Cantact object) {
				return object.name;
			}
		};
		dlg.firTable.addColumn(firName);
		dlg.firdataProvider.addDataDisplay(dlg.firTable);
		layout.setWidget(0, 0, dlg.searchTextBox);
		layout.setWidget(0, 1, dlg.searchButton);
		layout.setWidget(1, 0, dlg.firTable);
		FlexCellFormatter cellFormatter = layout.getFlexCellFormatter();
		cellFormatter.setColSpan(1, 0, 2);
		cellFormatter.setHorizontalAlignment(1, 0,
				HasHorizontalAlignment.ALIGN_CENTER);
	}
	
	public static PropImportanceDlg showDialog(List names, int x, int y){
		PropImportanceDlg dlg = PropImportanceDlg.createDialog(names);
		dlg.setCloseHandler(null, MsgPropImportance.INSTANCE.textClose());
		dlg.show();
        int left = x + 1;
        int top = y+ 1;
		dlg.setPopupPosition(left, top-dlg.getOffsetHeight());
		return dlg;
	}

	private static PropImportanceDlg createDialog(List names) {
		final PropImportanceDlg dlg = new PropImportanceDlg();
		VerticalPanel dlgContents = new VerticalPanel();
		dlgContents.setSpacing(2);
		dlg.setWidget(dlgContents);
		FlexTable flexTable = new FlexTable();
		dlg.selectedFlexTable.setHTML(0, 0, MsgPropImportance.INSTANCE.selectedVal());
		dlgContents.add(dlg.selectedFlexTable);
		setLayout(dlg, flexTable);
		dlgContents.add(flexTable);
		dlg.nameList = names;
		for (int i = 0; i < 10 && i < names.size(); i++) {
			dlg.firdataProvider.getList().add(
					new Cantact(names.get(i).toString()));
		}

		dlg.setSelectionModel();
		HorizontalPanel cmdPanel = new HorizontalPanel();
		dlgContents.add(cmdPanel);
		dlgContents.setCellHorizontalAlignment(cmdPanel,
				HasHorizontalAlignment.ALIGN_CENTER);
		cmdPanel.add(dlg.closeButton);
		cmdPanel.add(dlg.okButton);
		dlg.okButton.setStyleName("aw-cus-black-color", true);
		dlg.closeButton.setStyleName("aw-cus-black-color", true);
		cmdPanel.setHeight("60px");
		cmdPanel.setCellVerticalAlignment(dlg.closeButton,
				HasVerticalAlignment.ALIGN_BOTTOM);
		cmdPanel.setCellVerticalAlignment(dlg.okButton,
				HasVerticalAlignment.ALIGN_BOTTOM);
		cmdPanel.setCellHorizontalAlignment(dlg.closeButton,
				HasHorizontalAlignment.ALIGN_CENTER);
		cmdPanel.setCellHorizontalAlignment(dlg.okButton,
				HasHorizontalAlignment.ALIGN_CENTER);
		dlg.closeButton.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				dlg.hide();
			}

		});

		return dlg;
	}

	public void setSelectionModel() {
		final SingleSelectionModel<Cantact> secSelectionModel = new SingleSelectionModel<Cantact>();
		firTable.setSelectionModel(secSelectionModel);
		secSelectionModel
				.addSelectionChangeHandler(new SelectionChangeEvent.Handler() {
					@Override
					public void onSelectionChange(SelectionChangeEvent event) {
						String name = secSelectionModel.getSelectedObject()
								.getName();
						m_select_val = name;
						selectedFlexTable.setHTML(0, 1, name);
					}
				});
	}

	public void setCloseHandler(ClickHandler hd, String name) {
		if (hd != null) {
			closeButton.addClickHandler(hd);
		}
		if (null != name) {
			closeButton.setText(name);
		}
	}

	public void setOkHandler(ClickHandler hd, String name) {
		if (hd != null) {
			okButton.addClickHandler(hd);
		}
		if (null != name) {
			okButton.setText(name);
		}
	}
}
