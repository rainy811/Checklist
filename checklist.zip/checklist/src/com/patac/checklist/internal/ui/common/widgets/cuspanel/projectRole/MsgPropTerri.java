package com.patac.checklist.internal.ui.common.widgets.cuspanel.projectRole;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;

public interface MsgPropTerri 
extends Messages{
	MsgPropTerri INSTANCE = GWT.create(MsgPropTerri.class);
	
    String selectedVal();
    String textOK();
    String textClose();
}
