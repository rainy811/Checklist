package com.patac.checklist.internal.ui.common.widgets.cuspanel.importance;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;

public interface MsgPropImportance
extends Messages{
	MsgPropImportance INSTANCE = GWT.create(MsgPropImportance.class);
	
    String selectedVal();
    String textOK();
    String textClose();
}
