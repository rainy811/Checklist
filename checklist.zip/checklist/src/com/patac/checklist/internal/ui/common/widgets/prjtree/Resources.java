// @<COPYRIGHT>@
// ==================================================
// Copyright 2014.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.ui.common.widgets.prjtree;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

/**
 * gwt resources
 */
public interface Resources
    extends ClientBundle
{
    /**
     * Resources instance
     */
    Resources INSTANCE = GWT.create( Resources.class );

    /**
     * Returns the create print image
     *
     * @return ImageResource createprint.png
     */
    @Source( "com/patac/checklist/internal/ui/common/widgets/prjtree/find32.png" )
    ImageResource getSearchImg();

    @Source( "com/patac/checklist/internal/ui/common/widgets/prjtree/multiCreNA32.png" )
    ImageResource getMultiCreNAImg();
}
