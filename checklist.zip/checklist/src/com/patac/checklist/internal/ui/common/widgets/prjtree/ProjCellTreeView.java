package com.patac.checklist.internal.ui.common.widgets.prjtree;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.cus.comm.published.utils.CommMsg;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.NodeList;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiFactory;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.cellview.client.CellTree;
import com.google.gwt.user.cellview.client.TreeNode;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.ResizeComposite;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.view.client.MultiSelectionModel;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.patac.checklist.internal.config.IChecklistInjector;
import com.patac.checklist.internal.event.handlers.LoadC7tPrjRevEvent;
import com.patac.checklist.internal.event.handlers.RenderTreeEvent;
import com.patac.checklist.internal.presenters.C7tPrjLocSubLocationPresenter;
import com.patac.checklist.internal.ui.common.widgets.prjtree.ProjService.PrjNode;

public class ProjCellTreeView extends ResizeComposite {  
	  @UiField
	  TextBox treeFinder;
	  
	  @UiField
	  Image btSearchSimple;    
	
	  @UiField
	  ProjCellTree m_tree;
	  private ProjTreeViewModel mCellViewModel;
	  private TreeNode mRoot;
	  private NodeList<com.google.gwt.dom.client.Element> mTreeDivs;
	  
	  private CellTree.Resources mTreeRes = GWT.create(CellTree.BasicResources.class);
	  
	  public interface VsCellTreeViewUiBinder extends UiBinder<Widget, ProjCellTreeView> { }
	  private VsCellTreeViewUiBinder uiBinder = GWT.create(VsCellTreeViewUiBinder.class);
	  
	  private HandlerRegistration m_renderTreeHandler = null;
	  
	  public ProjCellTreeView(){
		  initWidget(uiBinder.createAndBindUi(this));
	  }
	  
	  private void getEventBus(final AsyncCallback<EventBus> callback){
		  AsyncProvider<C7tPrjLocSubLocationPresenter> sub = IChecklistInjector.INSTANCE.getC7tPrjLocSubLocationPresenter();
		  if(sub==null)
			  return;
		  sub.get(new AsyncCallback<C7tPrjLocSubLocationPresenter>(){
			@Override
			public void onFailure(Throwable caught) {		
				callback.onFailure(caught);
			}

			@Override
			public void onSuccess(C7tPrjLocSubLocationPresenter loc) {
				if(loc==null)
					callback.onFailure(new Throwable("loc null") );
				callback.onSuccess(loc.getEventBus2());
			}});
	  }
	  
	  @UiFactory
	  ProjCellTree makeCellTree(){
		  Logger.getLogger("#ProjCellTree").log(Level.INFO, "makeCellTree()");//$NON-NLS-1$//$NON-NLS-2$
		  final MultiSelectionModel<PrjNode> smd = ProjService.PrjNode.getSelectionModel();		  
		  
		  getEventBus(new AsyncCallback<EventBus>(){

			@Override
			public void onFailure(Throwable caught) {				
			}

			@Override
			public void onSuccess(final EventBus eventbus) {
				if(eventbus==null){
					CommMsg.showMsg("can not get eventbus");
					return;
				}
				ProjService.saveEventBus(eventbus);
				  smd.addSelectionChangeHandler(new SelectionChangeEvent.Handler() {
						@Override
						public void onSelectionChange(SelectionChangeEvent event) {
							List<PrjNode> selected = new ArrayList<PrjNode>(smd.getSelectedSet());
				            if(selected!=null && selected.size()==1){
				            	PrjNode node = selected.get(0);
				            	//CommMsg.showMsg(node.getDisplayName());
				            	eventbus.fireEvent(new LoadC7tPrjRevEvent(node.getCode()));
				            }
						}			  
					  });
			}});
		  
		  mCellViewModel = new ProjTreeViewModel(smd);
		  ProjCellTree tree = new ProjCellTree(mCellViewModel, null, mTreeRes);
		  tree.setAnimationEnabled(true);
		  return tree;
	  }
	  
	  @Override
	  public void onResize(){
		  Logger.getLogger("#CellTree").log(Level.INFO, "onResize()");//$NON-NLS-1$//$NON-NLS-2$
		  
		  super.onResize();
	  }
	  
	  public void refreshTree(){		  
		  ProjService.refreshRoot();
		  if(m_tree.getRootTreeNode().getChildCount()>0){
			  getEventBus(new AsyncCallback<EventBus>(){

				@Override
				public void onFailure(Throwable caught) {					
				}

				@Override
				public void onSuccess(EventBus eventbus) {
					if(eventbus==null){
						CommMsg.showMsg("can not get eventbus");
						return;
					}
					if(m_renderTreeHandler==null){
						m_renderTreeHandler = RenderTreeEvent.register(eventbus, new RenderTreeEvent.Handler() {
							
							@Override
							public void doAction(RenderTreeEvent event) {
								m_tree.getRootTreeNode().setChildOpen(0, false);
								mRoot = m_tree.getRootTreeNode().setChildOpen(0, true);
							}
						});			
					}
				}});			  
		  }
		  mTreeDivs = m_tree.getElement().getElementsByTagName("input");
	  }
	  
	  private void scrollToNode(int index){
		  m_tree.setAnimationEnabled(false);
		  for ( int i=0;i<mTreeDivs.getLength();i++ )
		  {
		     com.google.gwt.dom.client.Element e = mTreeDivs.getItem(i);
		     if (Integer.toString(ProjService.PrjNode.getID(index)).equals(e.getId()) ) {
		    	 e.scrollIntoView();
		     }
		  }
		  m_tree.setAnimationEnabled(true);
	  }
	  
	  private void getPaList(ArrayList<PrjNode> nodes, PrjNode me){
		  PrjNode root = (PrjNode)mRoot.getValue() ;
		  PrjNode pa = me;
		  while(root.compareTo(pa)!=0){
			  int index = pa.getAbsPaIndex();
			  pa = ProjService.getVsNodeByIndex(index);
			  nodes.add(pa);
		  }
	  }
	  
	  private void expandNodes(ArrayList<PrjNode> nodes, TreeNode root){
		  if(nodes.size()<=0)
			  return;
		  for(int j=0; j<root.getChildCount(); j++){
			  PrjNode node = (PrjNode)root.getChildValue(j);
			  for(int i=0; i<nodes.size(); i++){
				  PrjNode nd = nodes.get(i);
				  if(nd.compareTo(node)==0){
					  TreeNode sn = root.setChildOpen(j, true);
					  nodes.remove(i);
					  expandNodes(nodes, sn);
				  }  
			  }
		  }
	  }
	  
	  @UiHandler("treeFinder")
	  public void onKeyDown(KeyDownEvent event){
		  if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
			  searchWithWords();
		  }		  
	  }
	  
	  @UiHandler( "btSearchSimple" )
	  public void onSearchVpps( ClickEvent event )  {		  
		  searchWithWords();
	  }
	  
	  private void searchWithWords(){
		  String text = treeFinder.getText();
		  if(null == text || "".equals(text.trim()))
			  return;
		  int index = ProjService.findWithCode(text);
		  int indexN = ProjService.findWithName(text);
		  if(index<0)
			  index  = indexN;
		  if(index<0)
			  return;  
		  PrjNode sel = ProjService.getVsNodeByIndex(index);
		  ProjService.PrjNode.getSelectionModel().clear();
		  ProjService.PrjNode.getSelectionModel().setSelected(sel, true);
		  m_tree.getRootTreeNode().setChildOpen(0, true);
		  ArrayList<PrjNode> pa_list = new ArrayList<PrjNode>();
		  getPaList(pa_list, sel);
		  expandNodes(pa_list, mRoot);
		  scrollToNode(index);
	  }
	  
	  @Override
	  protected void onLoad() {
		  super.onLoad();
		  CommMsg.log_info("#CellTreeView", "#onLoad()");//$NON-NLS-1$//$NON-NLS-2$
		  setVisible(true);
		  ProjService.initData(ProjCellTreeView.this);
	  }
  
}
