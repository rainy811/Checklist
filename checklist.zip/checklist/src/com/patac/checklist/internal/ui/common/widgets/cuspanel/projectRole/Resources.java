// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.ui.common.widgets.cuspanel.projectRole;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

/**
 * Module resources for Checklist
 */
public interface Resources
    extends ClientBundle
{
    /** Resources instance */
    Resources INSTANCE = GWT.create( Resources.class );
    
    @Source( "com/patac/checklist/internal/ui/common/widgets/cuspanel/territory/filter20.png" )
    ImageResource filterImg();
    
}
