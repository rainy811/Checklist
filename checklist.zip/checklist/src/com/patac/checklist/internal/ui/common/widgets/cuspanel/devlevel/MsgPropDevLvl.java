package com.patac.checklist.internal.ui.common.widgets.cuspanel.devlevel;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;

public interface MsgPropDevLvl 
extends Messages{
	MsgPropDevLvl INSTANCE = GWT.create(MsgPropDevLvl.class);
	
    String selectedVal();
    String textOK();
    String textClose();
}
