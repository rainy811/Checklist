package com.patac.checklist.internal.ui.common.widgets.prjtree;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.cus.comm.published.dlg.CommDlg;
import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.comm.published.utils.ICommService;
import com.cus.comm.widgets.dlg.CommOkNoDlg;
import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.cell.client.ValueUpdater;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.cellview.client.CellTree;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SelectionChangeEvent.Handler;
import com.google.gwt.view.client.TreeViewModel;
import com.google.inject.Inject;
import com.patac.checklist.internal.event.handlers.LoadC7tPrjRevEvent;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.internal.ui.common.widgets.prjtree.ProjService.PrjNode;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.published.ISessionContextService;
import com.siemens.splm.clientfx.kernel.published.KernelGinjector;
import com.siemens.splm.clientfx.tcui.utils.published.DataManagementService.CreateResponse;

public class ProjCellTree extends CellTree 
	implements Handler{    
	
    public ProjCellTree(TreeViewModel viewModel, Object rootValue, Resources resources) {
		super(viewModel, rootValue, resources);
	}
	
	@Override
	public ProjTreeViewModel getTreeViewModel(){
		return (ProjTreeViewModel)super.getTreeViewModel();
	}
	

	@Override
	public void onSelectionChange(SelectionChangeEvent event) {
		
		
	}
	
	public static class ProjNodeTextCell extends AbstractCell<PrjNode> {
		@Override
		public void render(com.google.gwt.cell.client.Cell.Context context,
				PrjNode value, SafeHtmlBuilder sb) {
		}
	}
	
	public static class EmptyCellOpen extends AbstractCell<PrjNode> {
		public EmptyCellOpen (){
		}
		
		@Override
		public void render(com.google.gwt.cell.client.Cell.Context context,
				PrjNode value, SafeHtmlBuilder sb) {
		}
		
		@Override
		public void onBrowserEvent(Context context, Element pa, PrjNode nd, NativeEvent event, ValueUpdater<PrjNode> valueUpdater) {
			super.onBrowserEvent(context, pa, nd, event, valueUpdater);
		}
	}
	
	public static class ProjNodeCell extends AbstractCell<PrjNode> {
		@Inject
		private ICommService m_commsvr;
		
		private final SafeHtml imgNewHtml;
		private final SafeHtml imgDspHtml;
		
		interface Templates extends SafeHtmlTemplates {
			@SafeHtmlTemplates.Template("<div style=\"{0}\">{1}</div>")
			SafeHtml div(SafeStyles styles, String value);

			@SafeHtmlTemplates.Template("<div style=\"{0}\">{1}</div>")
			SafeHtml div(SafeStyles styles, SafeHtml value);
			
			@SafeHtmlTemplates.Template("<div id=\"{0}\">{1}</div>")
			SafeHtml div(int id, String value);
			
			@SafeHtmlTemplates.Template("<div>{0}</div>")
			SafeHtml div(String value);

			@SafeHtmlTemplates.Template("<div>{0}</div>")
			SafeHtml div(SafeHtml value);

//			@SafeHtmlTemplates.Template("<img src=\"{0}\"/>")
//			SafeHtml img(String value);
//
//			@SafeHtmlTemplates.Template("<img id=\"{0}\" src=\"{1}\"/>")
//			SafeHtml img(int id, String value);
			
	        @Template( "<input type='checkbox' style='width: inherit;' id='{0}' />" )
	        SafeHtml checkbox(int id);        
	        
		}
		private static Templates ui = GWT.create(Templates.class);
		
		public ProjNodeCell(ImageResource imgNew, ImageResource imgDisplay) {
			super("mousedown");
			imgNewHtml = AbstractImagePrototype.create(imgNew).getSafeHtml();			
			imgDspHtml = AbstractImagePrototype.create(imgDisplay).getSafeHtml();
		}
		
		@Override
		public void onBrowserEvent(Context context, Element parent, PrjNode nd, NativeEvent event, ValueUpdater<PrjNode> valueUpdater) {
			if (event.getButton() == NativeEvent.BUTTON_LEFT) {
				creProjLink2Node(event, nd);
			}
//			else if (event.getButton() == NativeEvent.BUTTON_RIGHT) {
//			}
			super.onBrowserEvent(context, parent, nd, event, valueUpdater);
		}

		@Override
		public void render(Context context, PrjNode nd, SafeHtmlBuilder sb) {			
			if (nd == null)
		        return;
			SafeStyles styRow = SafeStylesUtils.fromTrustedString("display:flex; flex-direction:row;");
			SafeStyles styCol = SafeStylesUtils.fromTrustedString("display:flex; flex-direction:column;");
			SafeStyles breakall = SafeStylesUtils.fromTrustedString("word-break:break-all;");
			
			if(nd.isExist() || nd.isContent()==false){
				sb.append(ui.div(styRow, 
						new SafeHtmlBuilder()
							.append(ui.div(imgDspHtml))
							//.append(imgOpenHtml)
							//.append(ui.checkbox(nd.getID() ))
							.append(ui.div(styCol,
									new SafeHtmlBuilder()	
										.append(ui.div(breakall, nd.getDisplayName()))
										.append(ui.div(nd.getCode())
									).toSafeHtml() )
						).toSafeHtml())) ;
			}else{
				sb.append(ui.div(styRow, 
					new SafeHtmlBuilder()
						.append(ui.div(imgNewHtml))
						//.append(imgOpenHtml)
						//.append(ui.checkbox(nd.getID() ))
						.append(ui.div(styCol,
								new SafeHtmlBuilder()	
									.append(ui.div(breakall, nd.getDisplayName()))
									.append(ui.div(nd.getCode())
								).toSafeHtml() )
					).toSafeHtml())) ;
			}
		}
		
		private void creProjLink2Node(final NativeEvent event, final PrjNode nd){
			//group role check
			ISessionContextService sessionSvc = KernelGinjector.INSTANCE.getSessionContextService();
			String role = sessionSvc.getUserRole();			
			if(CTypes.CHECK_LIST_ADMIN.equals(role)==false){
				String info = ChecklistMessages.INSTANCE.RoleNotOk(CTypes.CHECK_LIST_ADMIN);
				CommDlg.showOkDialog(info, event.getClientX(), event.getClientY());
				Logger.getLogger("#creVaObjLink2Node").log(Level.INFO, "Error Role="+role);//$NON-NLS-1$//$NON-NLS-2$
				return;
			}
			if(nd.isContent()==false)
				return;
			
			final String dept = CommUtils.getUserGroupFull();
			
			//createable
			ProjService.findProj(nd.getName(), dept, new AsyncCallback<List<IModelObject>>(){
				@Override
				public void onFailure(Throwable caught) {
					Logger.getLogger("find obj").log(Level.INFO, caught.getLocalizedMessage());
				}

				@Override
				public void onSuccess(List<IModelObject> result) {
					if(null != result){
						CommMsg.log_warn("#creProjLink2Node", "project obj exist");
					}else{
						//pop up dialog to double check if need to create
						final CommOkNoDlg dlg = CommDlg.showOkNoDialog(new HTML(ChecklistMessages.INSTANCE.CreProject(nd.getName())), event.getClientX(), event.getClientY());
						dlg.setOkHandler(new ClickHandler(){
							@Override
							public void onClick(final ClickEvent event) {
								dlg.setOkEnable(false);
								ProjService.createProj(nd.getName(), dept, new  AsyncCallback<CreateResponse>(){//$NON-NLS-1$
									@Override
									public void onFailure(Throwable caught) {													
									}

									@Override
									public void onSuccess(CreateResponse cr) {
										if(cr!=null && cr.output.length>0){		
											IModelObject[] objs = cr.output[0].objects;
											if(objs.length>0){
												IModelObject obj = objs[0];
												dlg.hide();
												String info = ChecklistMessages.INSTANCE.objCreated(obj.getUid());
												CommMsg.showMsg(info);
												m_commsvr.getEventBus().fireEvent(new LoadC7tPrjRevEvent());
											}
										}
									}
									
								});
							}				
						}, "OK");
					}
				}			
			});
			
			
		}		
		
	}


}
