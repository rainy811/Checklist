package com.patac.checklist.internal.views;

public interface IResizeView {
	public void doResize();
	public void refresh();
	public void selectRow(int i);
}
