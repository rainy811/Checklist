package com.patac.checklist.internal.views.table;

import java.util.Comparator;

import com.cus.comm.published.utils.CommMsg;
import com.google.gwt.cell.client.TextCell;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiFactory;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.ColumnSortEvent.ListHandler;
import com.google.gwt.user.cellview.client.HasKeyboardPagingPolicy.KeyboardPagingPolicy;
import com.google.gwt.user.cellview.client.HasKeyboardSelectionPolicy.KeyboardSelectionPolicy;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.SimplePager.TextLocation;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.view.client.MultiSelectionModel;
import com.google.gwt.view.client.SelectionModel;
import com.google.gwt.view.client.SingleSelectionModel;
import com.patac.checklist.internal.views.IResizeView;
import com.patac.checklist.internal.views.list.CItem;
import com.patac.checklist.internal.views.list.CheckListDB;
import com.patac.checklist.internal.views.list.TitleMessage;
import com.patac.checklist.resources.i18n.ChecklistMessages;

public class CTList extends Composite {
	interface Binder extends UiBinder<Widget, CTList> { }
	private static Binder uiBinder = GWT.create(Binder.class);
	private final Widget m_widget;
	private IResizeView m_pv;
	
	@UiField
	CellTable<CItem> ctable;
	@UiField
	SimplePager cpager;
	@UiField
	HTMLPanel tbpn;
	@UiField
	Label mstat;
	
	private SelectionModel<CItem> m_selectionModel=null;
	private ListHandler<CItem> m_sortHandler=null;
	
	
	@UiFactory CellTable<CItem> makeList(){
		ctable = new CellTable<CItem>(CItem.KEY_PROVIDER);
		ctable.setPageSize(10);
	    final SingleSelectionModel<CItem> selectionModel = new SingleSelectionModel<CItem>(CItem.KEY_PROVIDER);
	    ctable.setSelectionModel(selectionModel);
	    ctable.setKeyboardPagingPolicy(KeyboardPagingPolicy.INCREASE_RANGE);
	    ctable.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.BOUND_TO_SELECTION);
		return ctable;
	}
	
	@UiFactory SimplePager makePager(){
	    SimplePager.Resources pagerResources = GWT.create(SimplePager.Resources.class);
	    cpager = new SimplePager(TextLocation.CENTER, pagerResources, false, 0, true);
	    cpager.setDisplay(ctable);
	    return cpager;
	}
	
	public CTList(){
		m_widget = uiBinder.createAndBindUi(this);
		initWidget(m_widget);
		initUI();	
	}
	
	private void initUI(){
		mstat.setText(ChecklistMessages.INSTANCE.txtAllStat());
		
		m_sortHandler = new ListHandler<CItem>(CheckListDB.getInstance().getProvider().getList());
	    ctable.addColumnSortHandler(m_sortHandler);
	    
	    SimplePager.Resources pagerResources = GWT.create(SimplePager.Resources.class);
	    cpager = new SimplePager(TextLocation.CENTER, pagerResources, false, 0, true);
	    cpager.setDisplay(ctable);
	    
	    m_selectionModel = new MultiSelectionModel<CItem>(CItem.KEY_PROVIDER);
	    
	    //Project Name
	    Column<CItem, String> proName = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getC7tProjectName();
			      }
			    };
			    proName.setSortable(true);
		m_sortHandler.setComparator(proName, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getC7tProjectName();
				   String p2 = o2.getC7tProjectName();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(proName, "Project Name");
		ctable.setColumnWidth(proName, 15, Unit.PX);
	    
		//check id
	    Column<CItem, String> c_id = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getTemplateID();
			      }
			    };
		c_id.setSortable(true);
		m_sortHandler.setComparator(c_id, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getTemplateID();
				   String p2 = o2.getTemplateID();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(c_id, "ID");
		ctable.setColumnWidth(c_id, 15, Unit.PX);

	    //check name
	    Column<CItem, String> c_name = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getC7tChecker();
			      }
			    };
		c_name.setSortable(true);
		m_sortHandler.setComparator(c_name, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getC7tChecker();
				   String p2 = o2.getC7tChecker();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(c_name, "Name");
		ctable.setColumnWidth(c_name, 15, Unit.PX);

	    //res
	    Column<CItem, String> res = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getC7tResult();
			      }
			    };
	    res.setSortable(true);
		m_sortHandler.setComparator(res, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getC7tResult();
				   String p2 = o2.getC7tResult();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(res, "Result");
		ctable.setColumnWidth(res, 15, Unit.PX);
		
//		//desc
//	    Column<CItem, String> c_desc = new Column<CItem, String>(
//			    new TextCell()) {
//			      @Override
//			      public String getValue(CItem obj) {
//			    	  return obj.getPropValue("desc");
//			      }
//			    };
//		c_desc.setSortable(true);
//		m_sortHandler.setComparator(c_desc, new Comparator<CItem>() {
//			@Override
//			public int compare(CItem o1, CItem o2) {
//				   String p1 = o1.getPropValue("desc");
//				   String p2 = o2.getPropValue("desc");
//				   if(p1==null) return 1;
//				   if(p2==null) return -1;
//				   return p1.compareTo(p2);
//			}
//		}); 
//		ctable.addColumn(c_desc, "Desc");
//		ctable.setColumnWidth(c_desc, 15, Unit.PX);
//		
		//stat
	    Column<CItem, String> stat = new Column<CItem, String>(
		    new TextCell()) {
		      @Override
		      public String getValue(CItem obj) {
		    	  if (obj.getC7tStatus()==1) {
		    		  return TitleMessage.INSTANCE.red();
		    	  }
		    	  else if (obj.getC7tStatus()==2) {
		    		  return TitleMessage.INSTANCE.yellow();
		    	  }
		    	  else if (obj.getC7tStatus()==3) {
		    		  return TitleMessage.INSTANCE.green();
		    	  }
		    	  else
		    		  return null;
		      }
	    };
	    stat.setSortable(true);
//		m_sortHandler.setComparator(stat, new Comparator<CItem>() {
//			@Override
//			public int compare(CItem o1, CItem o2) {
//				   String p1 = o1.getC7tStatus();
//				   String p2 = o2.getC7tStatus();
//				   if(p1==null) return 1;
//				   if(p2==null) return -1;
//				   return p1.compareTo(p2);
//			}
//		});
		ctable.addColumn(stat, "Status");
		ctable.setColumnWidth(stat, 15, Unit.PX);
		
		//time
	    Column<CItem, String> time = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getLastModDate();
			      }
			    };
			    time.setSortable(true);
		m_sortHandler.setComparator(time, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getLastModDate();
				   String p2 = o2.getLastModDate();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(time, "Last Motify Time");
		ctable.setColumnWidth(time, 15, Unit.PX);
		
		//checker
	    Column<CItem, String> checker = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getC7tFunctionFo();
			      }
			    };
			    checker.setSortable(true);
		m_sortHandler.setComparator(checker, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getC7tFunctionFo();
				   String p2 = o2.getC7tFunctionFo();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(checker, "Checker");
		ctable.setColumnWidth(checker, 15, Unit.PX);
		
		//dept
	    Column<CItem, String> dept = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getOwningGroup();
			      }
			    };
			    dept.setSortable(true);
		m_sortHandler.setComparator(dept, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getOwningGroup();
				   String p2 = o2.getOwningGroup();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(dept, "Departement");
		ctable.setColumnWidth(dept, 15, Unit.PX);
		
		//red
	    Column<CItem, String> red = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getC7tStandardRed();
			      }
			    };
			    red.setSortable(true);
		m_sortHandler.setComparator(red, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getC7tStandardRed();
				   String p2 = o2.getC7tStandardRed();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(red, "Red CheckItem");
		ctable.setColumnWidth(red, 15, Unit.PX);
		
		//yellow
	    Column<CItem, String> yellow = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getC7tStandardYellow();
			      }
			    };
			    yellow.setSortable(true);
		m_sortHandler.setComparator(yellow, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getC7tStandardYellow();
				   String p2 = o2.getC7tStandardYellow();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(yellow, "Yellow CheckItem");
		ctable.setColumnWidth(yellow, 15, Unit.PX);
		
		//green
	    Column<CItem, String> green = new Column<CItem, String>(
			    new TextCell()) {
			      @Override
			      public String getValue(CItem obj) {
			    	  return obj.getC7tStandardGreen();
			      }
			    };
			    green.setSortable(true);
		m_sortHandler.setComparator(green, new Comparator<CItem>() {
			@Override
			public int compare(CItem o1, CItem o2) {
				   String p1 = o1.getC7tStandardGreen();
				   String p2 = o2.getC7tStandardGreen();
				   if(p1==null) return 1;
				   if(p2==null) return -1;
				   return p1.compareTo(p2);
			}
		});
		ctable.addColumn(green, "Green CheckItem");
		ctable.setColumnWidth(green, 15, Unit.PX);
		//CheckListDB.getInstance().query();
		CheckListDB.getInstance().getProvider().addDataDisplay(ctable);
	}
	
	public void refresh() {
		CommMsg.log_warn("#", "refresh");
		CheckListDB.getInstance().getProvider().refresh();
	}
	
	public void setParentView(IResizeView pv) {
		CheckListDB.addParentView(pv);
		m_pv = pv;
	}
	

	public void setSelectedRow(int row) {
		// TODO Auto-generated method stub
		ctable.setKeyboardSelectedRow(row);
		
	}
	public void resize(int height, int width) {
		tbpn.setHeight( (height - 50) + "px");
	}
}
