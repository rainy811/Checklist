// @<COPYRIGHT>@
// ==================================================
// Copyright 2018.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.views;

import java.util.Vector;

import com.cus.comm.published.utils.CommMsg;
import com.cus.commrpc.published.CommSessionService;
import com.cus.commrpc.published.CommSessionServiceAsync;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.gwtplatform.mvp.client.ViewImpl;
import com.patac.checklist.internal.event.dreEvent.DGreenFilterEvent;
import com.patac.checklist.internal.event.dreEvent.DRESaveEvent;
import com.patac.checklist.internal.event.dreEvent.DRESubmitEvent;
import com.patac.checklist.internal.event.dreEvent.DRedFilterEvent;
import com.patac.checklist.internal.event.dreEvent.DTaskFilterEvent;
import com.patac.checklist.internal.event.dreEvent.DYellowFilterEvent;
import com.patac.checklist.internal.event.handlers.C7tViewModeChangeEvent;
import com.patac.checklist.internal.presenters.DListLocPrimaryWorkAreaPresenter;
import com.patac.checklist.internal.service.CSession;
import com.patac.checklist.internal.views.list.CKList;
import com.patac.checklist.internal.views.table.CTList;
import com.siemens.splm.clientfx.ui.commands.published.CommandContextChangedEvent;

/**
 * Primary work area view in DListLoc SubLocation
 */
public class DListLocPrimaryWorkAreaView
    extends ViewImpl
    implements DListLocPrimaryWorkAreaPresenter.MyView, IResizeView
{
	private EventBus ebus;
    protected Vector<HandlerRegistration> m_Handlers = new  Vector<HandlerRegistration>();
    

	private static CommSessionServiceAsync commSessionService = GWT.create(CommSessionService.class);
	
    private final Widget m_widget;

    /**
     * Sample text shown in primary work area
     */
    @UiField
    CKList cklist;
    
    @UiField
    CTList ctlist;
    
    @UiField
    HTMLPanel wkpage;

    /**
     * Ui binder
     */
    public interface Binder
        extends UiBinder<Widget, DListLocPrimaryWorkAreaView>
    {
    	
    }

    /**
     * Constructor
     *
     * @param binder UI binder
     */
    @Inject
    public DListLocPrimaryWorkAreaView( final Binder binder )
    {
        m_widget = binder.createAndBindUi( this );
        ctlist.setVisible(false);
        //GuoU
        ctlist.setParentView(this);
        ctlist.setParentView(this);
        
        CSession.setVIEW_MODE("SummaryView");
        Window.addResizeHandler(new ResizeHandler() {
			@Override
			public void onResize(ResizeEvent event) {
				doResize();
			}});
        
		final Timer timer = new Timer() {
            public void run()
            {
            	DListLocPrimaryWorkAreaView.this.doResize();
            }
		};	
		timer.schedule(1000);
    }
    
    public void saveEventBus(EventBus eb, final DListLocPrimaryWorkAreaPresenter pst) {
    	ebus = eb;
        if(m_Handlers.size()==0)
        {
            m_Handlers.add(C7tViewModeChangeEvent.register( ebus, new C7tViewModeChangeEvent.Handler()
            {
    			@Override
    			public void doAction(C7tViewModeChangeEvent event) {    	
    				if("SummaryView".equals(event.getEventViewMode().name())) {
    					cklist.setVisible(true);
    					ctlist.setVisible(false);
    					cklist.setWidgetEditable(true);
    					final Timer timer = new Timer() {
    			            public void run()
    			            {
    	    					hideSecodary();
    			            }
    					};	
    					timer.schedule(500);

    				}else  if("TableView".equals(event.getEventViewMode().name())) {
    					cklist.setVisible(false);
    					ctlist.setVisible(true);
    				}
    				CSession.setVIEW_MODE(event.getEventViewMode().name());
    				CommandContextChangedEvent.fireEventFromSource(ebus, pst.getSubLocation());
    				DListLocPrimaryWorkAreaView.this.doResize();
    			}
            } ));   
            m_Handlers.add(DRESaveEvent.register(ebus, new DRESaveEvent.Handler() {
				@Override
				public void doAction(DRESaveEvent event) {
					String jsonStr = cklist.getCheckItemInfo();
					commSessionService.updateCheckItem(jsonStr, new AsyncCallback<Boolean>() {

						@Override
						public void onFailure(Throwable caught) {
							CommMsg.showMsg("updateCheckItem failed");
						}

						@Override
						public void onSuccess(Boolean bol) {
							if(bol)
								CommMsg.showMsg("updateCheckItem succed");
							else
								CommMsg.showMsg("updateCheckItem failed");
						}
						
					});
					CommMsg.showMsg("Save Action");
				}
			}));
            m_Handlers.add(DRESubmitEvent.register(ebus, new DRESubmitEvent.Handler() {
				
				@Override
				public void doAction(DRESubmitEvent event) {
					CommMsg.showMsg("Submit action");
					
				}
			}));
            m_Handlers.add(DGreenFilterEvent.register(ebus, new DGreenFilterEvent.Handler() {
				
				@Override
				public void doAction(DGreenFilterEvent event) {
					CommMsg.showMsg("Green");
				}
			}));
            m_Handlers.add(DRedFilterEvent.register(ebus, new DRedFilterEvent.Handler() {
				
				@Override
				public void doAction(DRedFilterEvent event) {
					CommMsg.showMsg("Red");
				}
			}));
            m_Handlers.add(DYellowFilterEvent.register(ebus, new DYellowFilterEvent.Handler() {
				
				@Override
				public void doAction(DYellowFilterEvent event) {
					CommMsg.showMsg("Yellow");
				}
			}));
            m_Handlers.add(DTaskFilterEvent.register(ebus, new DTaskFilterEvent.Handler() {
				
				@Override
				public void doAction(DTaskFilterEvent event) {
					CommMsg.showMsg("All Personnal Tasks");
				}
			}));
        }
    }
	public static native void hideSecodary()
    /*-{
      $wnd._app.$(".aw-layout-secondaryWorkarea").addClass("hidden");
      $wnd._app.$(".aw-layout-primaryWorkarea").removeClass("aw-layout-primaryWorkareaLeft");
      $wnd._app.$(".aw-layout-primaryWorkarea").removeClass("aw-layout-summaryList");
}-*/;
    @Override
    public Widget asWidget()
    {
        return m_widget;
    }

	@Override
	public void doResize() {
		int h =0, w=0 ;
		w = Window.getClientWidth() - - wkpage.getAbsoluteLeft();
		h = Window.getClientHeight() - wkpage.getAbsoluteTop();
		wkpage.setHeight(h+"px");
		cklist.resize(h, w);
		ctlist.resize(h, w);
	}

	@Override
	public void refresh() {
		cklist.refresh();
	}

	@Override
	public void selectRow(int row) {
		CommMsg.log_info("#", "doselect");
		cklist.setSelectedRow(row);		
	}
}
