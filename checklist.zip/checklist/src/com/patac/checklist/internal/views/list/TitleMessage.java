package com.patac.checklist.internal.views.list;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;

public interface TitleMessage extends Messages{

	TitleMessage INSTANCE = GWT.create(TitleMessage.class);
	
	String descriptionTitle();
	
	String resTitle();
	
	String redTitle();
	
	String yellowTitle();

	String greenTitle();
	
	String checkList();
	
	String imageTitle();
	
	String status();
	
	String fileTitle();
	
	String uploadButton();
	
	String choise();
	
	String red();
	
	String yellow();
	
	String green();
}
