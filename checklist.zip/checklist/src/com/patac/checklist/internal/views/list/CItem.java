package com.patac.checklist.internal.views.list;

import java.sql.Blob;
import java.util.Date;

import com.google.gwt.view.client.ProvidesKey;

public class CItem implements Comparable<CItem>{
	private String templateID;
	private String templateName;
	private String templateDesc;
	private String c7tFunctionId;
	private String c7tFunctionName;
	private String c7tFunctionFo;
	private String c7tFunctionFoId;
	private String c7tLevel;
	private String c7tVehicle;
	private String C7TCLS01;
	private String C7TCLS02;
	private String c7tDesc;
	private String c7tImportance;
	private String c7tStandardRed;
	private String c7tStandardYellow;
	private String c7tStandardGreen;
	private String C7tRefUrls;
	private String c7tAppStates;
	private String c7tProjectRoleName;
	private String c7tProjectRoleId;
	private String templateOwningUser;
	private String templateOwningGroup;
	private String itemId;
	private String objectName;
	private String objectDesc;
	private String c7tProjectId;
	private String c7tProjectName;
	private Date c7tProjectTime;
	private String c7tChecker;
	private String c7tResult;
	private String c7tResultDesc;
	private int c7tStatus;
	private String c7tMeasures;
	private String c7tPlan;
	private String c7tRemarks;
	private String owningUser;
	private String owningGroup;
	private Date creationDate;
	private String releaseStatusList;
	private String lastModUser;
	private String lastModDate;
	
	public static final ProvidesKey<CItem> KEY_PROVIDER = new ProvidesKey<CItem>() {
	      @Override
	      public Object getKey(CItem item) {
	        return item == null ? null : item.getTemplateID();
	      }
	};
	
	@Override
	public int compareTo(CItem o) {
		return 0;
	}

	public String getTemplateID() {
		return templateID;
	}

	public String getTemplateName() {
		return templateName;
	}

	public String getTemplateDesc() {
		return templateDesc;
	}

	public String getC7tFunctionId() {
		return c7tFunctionId;
	}

	public String getC7tFunctionName() {
		return c7tFunctionName;
	}

	public String getC7tFunctionFo() {
		return c7tFunctionFo;
	}

	public String getC7tFunctionFoId() {
		return c7tFunctionFoId;
	}

	public String getC7tLevel() {
		return c7tLevel;
	}

	public String getC7tVehicle() {
		return c7tVehicle;
	}

	public String getC7TCLS01() {
		return C7TCLS01;
	}

	public String getC7TCLS02() {
		return C7TCLS02;
	}

	public String getC7tDesc() {
		return c7tDesc;
	}

	public String getC7tImportance() {
		return c7tImportance;
	}

	public String getC7tStandardRed() {
		return c7tStandardRed;
	}

	public String getC7tStandardYellow() {
		return c7tStandardYellow;
	}

	public String getC7tStandardGreen() {
		return c7tStandardGreen;
	}

	public String getC7tRefUrls() {
		return C7tRefUrls;
	}

	public String getC7tAppStates() {
		return c7tAppStates;
	}

	public String getC7tProjectRoleName() {
		return c7tProjectRoleName;
	}

	public String getC7tProjectRoleId() {
		return c7tProjectRoleId;
	}

	public String getTemplateOwningUser() {
		return templateOwningUser;
	}

	public String getTemplateOwningGroup() {
		return templateOwningGroup;
	}

	public String getItemId() {
		return itemId;
	}

	public String getObjectName() {
		return objectName;
	}

	public String getObjectDesc() {
		return objectDesc;
	}

	public String getC7tProjectId() {
		return c7tProjectId;
	}

	public String getC7tProjectName() {
		return c7tProjectName;
	}

	public Date getC7tProjectTime() {
		return c7tProjectTime;
	}

	public String getC7tChecker() {
		return c7tChecker;
	}

	public String getC7tResult() {
		return c7tResult;
	}

	public String getC7tResultDesc() {
		return c7tResultDesc;
	}

	public int getC7tStatus() {
		return c7tStatus;
	}

	public String getC7tMeasures() {
		return c7tMeasures;
	}

	public String getC7tPlan() {
		return c7tPlan;
	}

	public String getC7tRemarks() {
		return c7tRemarks;
	}

	public String getOwningUser() {
		return owningUser;
	}

	public String getOwningGroup() {
		return owningGroup;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public String getReleaseStatusList() {
		return releaseStatusList;
	}

	public String getLastModUser() {
		return lastModUser;
	}

	public String getLastModDate() {
		return lastModDate;
	}

	public void setTemplateID(String templateID) {
		this.templateID = templateID;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public void setTemplateDesc(String templateDesc) {
		this.templateDesc = templateDesc;
	}

	public void setC7tFunctionId(String c7tFunctionId) {
		this.c7tFunctionId = c7tFunctionId;
	}

	public void setC7tFunctionName(String c7tFunctionName) {
		this.c7tFunctionName = c7tFunctionName;
	}

	public void setC7tFunctionFo(String c7tFunctionFo) {
		this.c7tFunctionFo = c7tFunctionFo;
	}

	public void setC7tFunctionFoId(String c7tFunctionFoId) {
		this.c7tFunctionFoId = c7tFunctionFoId;
	}

	public void setC7tLevel(String c7tLevel) {
		this.c7tLevel = c7tLevel;
	}

	public void setC7tVehicle(String c7tVehicle) {
		this.c7tVehicle = c7tVehicle;
	}

	public void setC7TCLS01(String c7tcls01) {
		C7TCLS01 = c7tcls01;
	}

	public void setC7TCLS02(String c7tcls02) {
		C7TCLS02 = c7tcls02;
	}

	public void setC7tDesc(String c7tDesc) {
		this.c7tDesc = c7tDesc;
	}

	public void setC7tImportance(String c7tImportance) {
		this.c7tImportance = c7tImportance;
	}

	public void setC7tStandardRed(String c7tStandardRed) {
		this.c7tStandardRed = c7tStandardRed;
	}

	public void setC7tStandardYellow(String c7tStandardYellow) {
		this.c7tStandardYellow = c7tStandardYellow;
	}

	public void setC7tStandardGreen(String c7tStandardGreen) {
		this.c7tStandardGreen = c7tStandardGreen;
	}

	public void setC7tRefUrls(String c7tRefUrls) {
		C7tRefUrls = c7tRefUrls;
	}

	public void setC7tAppStates(String c7tAppStates) {
		this.c7tAppStates = c7tAppStates;
	}

	public void setC7tProjectRoleName(String c7tProjectRoleName) {
		this.c7tProjectRoleName = c7tProjectRoleName;
	}

	public void setC7tProjectRoleId(String c7tProjectRoleId) {
		this.c7tProjectRoleId = c7tProjectRoleId;
	}

	public void setTemplateOwningUser(String templateOwningUser) {
		this.templateOwningUser = templateOwningUser;
	}

	public void setTemplateOwningGroup(String templateOwningGroup) {
		this.templateOwningGroup = templateOwningGroup;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}

	public void setObjectDesc(String objectDesc) {
		this.objectDesc = objectDesc;
	}

	public void setC7tProjectId(String c7tProjectId) {
		this.c7tProjectId = c7tProjectId;
	}

	public void setC7tProjectName(String c7tProjectName) {
		this.c7tProjectName = c7tProjectName;
	}

	public void setC7tProjectTime(Date c7tProjectTime) {
		this.c7tProjectTime = c7tProjectTime;
	}

	public void setC7tChecker(String c7tChecker) {
		this.c7tChecker = c7tChecker;
	}

	public void setC7tResult(String c7tResult) {
		this.c7tResult = c7tResult;
	}

	public void setC7tResultDesc(String c7tResultDesc) {
		this.c7tResultDesc = c7tResultDesc;
	}

	public void setC7tStatus(int c7tStatus) {
		this.c7tStatus = c7tStatus;
	}

	public void setC7tMeasures(String c7tMeasures) {
		this.c7tMeasures = c7tMeasures;
	}

	public void setC7tPlan(String c7tPlan) {
		this.c7tPlan = c7tPlan;
	}

	public void setC7tRemarks(String c7tRemarks) {
		this.c7tRemarks = c7tRemarks;
	}

	public void setOwningUser(String owningUser) {
		this.owningUser = owningUser;
	}

	public void setOwningGroup(String owningGroup) {
		this.owningGroup = owningGroup;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public void setReleaseStatusList(String releaseStatusList) {
		this.releaseStatusList = releaseStatusList;
	}

	public void setLastModUser(String lastModUser) {
		this.lastModUser = lastModUser;
	}

	public void setLastModDate(String lastModDate) {
		this.lastModDate = lastModDate;
	}


}
