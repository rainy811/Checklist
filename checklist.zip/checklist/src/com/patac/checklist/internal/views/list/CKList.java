package com.patac.checklist.internal.views.list;

import java.util.ArrayList;
import java.util.List;

import com.cus.comm.published.utils.CommMsg;
import com.google.gwt.cell.client.AbstractCell;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiFactory;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.cellview.client.CellList;
import com.google.gwt.user.cellview.client.HasKeyboardPagingPolicy.KeyboardPagingPolicy;
import com.google.gwt.user.cellview.client.HasKeyboardSelectionPolicy.KeyboardSelectionPolicy;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FileUpload;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.Widget;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SingleSelectionModel;
import com.patac.checklist.internal.views.IResizeView;
import com.patac.checklist.resources.i18n.ChecklistMessages;

public class CKList extends Composite {
	interface Binder extends UiBinder<Widget, CKList> { }
	private static Binder uiBinder = GWT.create(Binder.class);
	private final Widget m_widget;
	private IResizeView m_pv;
	
	@UiField
	CellList<CItem> mlist;
	
	@UiField
	Label mstat;
	
	private CItem cItem = new CItem();
	private List<Image> picTab2 = new ArrayList<Image>();
    private List<Image> picTab = new ArrayList<Image>();
	private List<Image> m_pix_imgs = new ArrayList<Image>();
	
	private static String cItemId = null;
	
	@UiField 
	HTMLPanel templatePanel;
	
	@UiField 
	HTMLPanel checkPanel;
	
	@UiField 
	Label descriptionTitle;
	
	@UiField 
	TextArea descriptionTxt;
	
	@UiField 
	Label redTitle;
	@UiField
	TextBox redDes;
	
	@UiField 
	Label yellowTitle;
	@UiField
	TextBox yellowDes;
	
	@UiField 
	Label greenTitle;
	@UiField
	TextBox greenDes;
	
	@UiField 
	Label imageTitle;

	@UiField
	HorizontalPanel cpn01;
	
	@UiField
	FlowPanel cpn02;
		

	@UiField 
	Label checkList;
	

	@UiField 
	TextBox checkTxt;
	
	
	@UiField
	Label status;
	
	@UiField
	ListBox statusList;
	
	@UiField 
	Label resTitle;
	
	@UiField 
	TextArea resTxt;
	
	@UiField
	Label fileTitle;
	
	@UiField
	FileUpload fileUpload;
	
	@UiField
	Button uploadButton;
	
	@UiFactory CellList<CItem> makeList(){
		CKCell c = new CKCell(ImgRes.INSTANCE.itemImg());
		mlist = new CellList<CItem>(c, CItem.KEY_PROVIDER);
		mlist.setPageSize(10);
	    final SingleSelectionModel<CItem> selectionModel = new SingleSelectionModel<CItem>(CItem.KEY_PROVIDER);
	    mlist.setSelectionModel(selectionModel);
	    selectionModel.addSelectionChangeHandler(new SelectionChangeEvent.Handler() {
			@Override
			public void onSelectionChange(SelectionChangeEvent event) {
				cItem = selectionModel.getSelectedObject();
				setTemplateInfo(cItem);
				cItemId=cItem.getItemId();
			}
	    	
	    });
	    mlist.setKeyboardPagingPolicy(KeyboardPagingPolicy.INCREASE_RANGE);
	    mlist.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.BOUND_TO_SELECTION);
		return mlist;
	}
	
	static class CKCell extends AbstractCell<CItem>{

	    private final String imageHtml;
	    
	    public CKCell (ImageResource image) {
	        this.imageHtml = AbstractImagePrototype.create(image).getHTML();
	    }
	    
		@Override
		public void render(com.google.gwt.cell.client.Cell.Context context, CItem value, SafeHtmlBuilder sb) {
			sb.appendHtmlConstant("<table style='margin: 5px 8px;table-layout:fixed;width:100%;'>");
			// Add the contact image.
			sb.appendHtmlConstant("<tr><td rowspan='3' style='vertical-align: middle;width:40px;height:44px;'>");
			sb.appendHtmlConstant(imageHtml);
			sb.appendHtmlConstant("</td>");
			
			// Add the name and address.
			sb.appendHtmlConstant("<td style='font-size:18px;'>");
			sb.appendEscaped(value.getC7tProjectName());
			sb.appendHtmlConstant("</td></tr><tr><td style='font-size:12px;'>");
			sb.appendEscaped(value.getC7tChecker());
			sb.appendHtmlConstant("</td></tr></table>");		
		}
	}
	
	public CKList(){
		m_widget = uiBinder.createAndBindUi(this);
		initWidget(m_widget);
		initUI();	
	}
	
	private void initUI(){
		CheckListDB.getInstance().query();
		CheckListDB.getInstance().getProvider().refresh();
		CheckListDB.getInstance().getProvider().addDataDisplay(mlist);
		mstat.setText(ChecklistMessages.INSTANCE.txtAllStat());
		
		setTitleValue();
		
	    Image usrImg = new Image(ImgRes.INSTANCE.getCarPic());
	    Image usrImg2 = new Image(ImgRes.INSTANCE.blancCar());
	    Image usrImg3 = new Image(ImgRes.INSTANCE.getCarPic());
	  	Image usrImg4 = new Image(ImgRes.INSTANCE.blancCar());
	    picTab.add(usrImg);
	    picTab.add(usrImg2);
	    picTab.add(usrImg3);
	    picTab.add(usrImg4);
	    Image usr2Img = new Image(ImgRes.INSTANCE.getCarPic());
	    Image usr2Img2 = new Image(ImgRes.INSTANCE.blancCar());
	    Image usr2Img3 = new Image(ImgRes.INSTANCE.getCarPic());
	    Image usr2Img4 = new Image(ImgRes.INSTANCE.blancCar());
	    picTab2.add(usr2Img);
	    picTab2.add(usr2Img2);
	    picTab2.add(usr2Img3);
	    picTab2.add(usr2Img4);
	    updateUI();
	}
	
	public void setWidgetEditable(Boolean e){
		statusList.setEnabled(e);
		resTxt.setEnabled(e);
		checkTxt.setEnabled(e);
	}
	
	public Boolean checkContenent() {
		if(checkTxt.getText().length()==0 && statusList.getSelectedIndex()==0 && resTxt.getText().length()==0) {
			return false;
		}else {
			return true;
		}
			
	}
	public String getCheckItemInfo() {
		JSONObject output =  new JSONObject();
		JSONString itemid = new JSONString(cItemId);
		output.put("itemId", itemid);
		JSONString result = new JSONString(checkTxt.getText());
		output.put("c7tResult", result);
		JSONNumber status = new JSONNumber(statusList.getSelectedIndex());
		output.put("c7tStatus", status);
		JSONString resDesc = new JSONString(resTxt.getText());
		output.put("c7tResultDesc", resDesc);
		
		String json = output.toString();
		return json;
	}
	public void setTemplateInfo(CItem cItem) {
		descriptionTxt.setText(cItem.getC7tDesc());
		redDes.setText(cItem.getC7tStandardRed());
		yellowDes.setText(cItem.getC7tStandardYellow());
		greenDes.setText(cItem.getC7tStandardGreen());
		
		checkTxt.setText(cItem.getC7tResult());
		statusList.setSelectedIndex(cItem.getC7tStatus());
		resTxt.setText(cItem.getC7tResultDesc());
	}
	
	public void setTitleValue(){
	   descriptionTitle.setText(TitleMessage.INSTANCE.descriptionTitle());
	   descriptionTxt.setWidth("60%");
	   descriptionTxt.setHeight("100px");
	   descriptionTxt.setEnabled(false);
	   
	   resTitle.setText(TitleMessage.INSTANCE.resTitle());
	   resTxt.setWidth("60%");
	   resTxt.setHeight("100px");
	  
	   
	   redDes.setEnabled(false);
	   yellowDes.setEnabled(false);
	   greenDes.setEnabled(false);
	   
	   redTitle.setText(TitleMessage.INSTANCE.redTitle());
	   yellowTitle.setText(TitleMessage.INSTANCE.yellowTitle());
	   greenTitle.setText(TitleMessage.INSTANCE.greenTitle());
	   
	   checkList.setText(TitleMessage.INSTANCE.checkList());
	   
	   imageTitle.setText(TitleMessage.INSTANCE.imageTitle());
	   status.setText(TitleMessage.INSTANCE.status());
	   
	   statusList.setHeight("30px");
	   statusList.addItem(TitleMessage.INSTANCE.choise());
	   statusList.addItem(TitleMessage.INSTANCE.red());
	   statusList.addItem(TitleMessage.INSTANCE.yellow());
	   statusList.addItem(TitleMessage.INSTANCE.green());
	   
	   fileTitle.setText(TitleMessage.INSTANCE.fileTitle());
	   uploadButton.setText(TitleMessage.INSTANCE.uploadButton());
	   uploadButton.addClickHandler(new ClickHandler() {
		      public void onClick(ClickEvent event) {
		        String filename = fileUpload.getFilename();
		        if (filename.length() == 0) {
		          Window.alert("没有上传文件");
		        }
		      }
	   });
	}
	   
	public void updateUI() {
		cpn01.clear();
		cpn02.clear();
		m_pix_imgs.clear();
		
		for(int i=0; i<picTab.size(); i++) {
			final Image pic = picTab.get(i);
			final Image img = pic;img.setWidth(48+"px");img.setHeight("auto");img.addStyleName("aw-cus-pic");
			m_pix_imgs.add(img);
			cpn02.add(picTab.get(i));
			final Image img2 = picTab2.get(i);
			if(i==0) {
				img2.setWidth("80%");
				img2.setHeight("auto");
				cpn01.add(img2);		
			}
		img.addClickHandler(new ClickHandler() {
		@Override
		public void onClick(ClickEvent event) {
			cpn01.clear();
			img2.setWidth("80%");
			img2.setHeight("auto");
			cpn01.add(img2);					
			}});
			}
	}
	
	public void refresh() {
		CommMsg.log_warn("#", "refresh");
		CheckListDB.getInstance().getProvider().refresh();
	}
	
	public void setParentView(IResizeView pv) {
		CheckListDB.addParentView(pv);
		m_pv = pv;
	}
	
	public void resize(int height, int width) {
		
	}
	
	public void setSelectedRow(int row) {
		// TODO Auto-generated method stub
			mlist.setKeyboardSelectedRow(row);
			
	}
}
