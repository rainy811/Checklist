// @<COPYRIGHT>@
// ==================================================
// Copyright 2018.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.views;

import java.util.Vector;

import com.cus.comm.published.utils.CommMsg;
import com.google.gwt.event.logical.shared.ResizeEvent;
import com.google.gwt.event.logical.shared.ResizeHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.gwtplatform.mvp.client.ViewImpl;
import com.patac.checklist.internal.event.dreEvent.DGreenFilterEvent;
import com.patac.checklist.internal.event.dreEvent.DRedFilterEvent;
import com.patac.checklist.internal.event.dreEvent.DTaskFilterEvent;
import com.patac.checklist.internal.event.dreEvent.DYellowFilterEvent;
import com.patac.checklist.internal.event.foEvent.FGreenFilterEvent;
import com.patac.checklist.internal.event.foEvent.FOCheckEvent;
import com.patac.checklist.internal.event.foEvent.FONotSubmitEvent;
import com.patac.checklist.internal.event.foEvent.FRedFilterEvent;
import com.patac.checklist.internal.event.foEvent.FSubmitCheckEvent;
import com.patac.checklist.internal.event.foEvent.FTaskFilterEvent;
import com.patac.checklist.internal.event.foEvent.FYellowFilterEvent;
import com.patac.checklist.internal.event.handlers.C7tViewModeChangeEvent;
import com.patac.checklist.internal.presenters.FListLocPrimaryWorkAreaPresenter;
import com.patac.checklist.internal.service.CSession;
import com.patac.checklist.internal.views.list.CKList;
import com.patac.checklist.internal.views.table.CTList;
import com.siemens.splm.clientfx.ui.commands.published.CommandContextChangedEvent;

/**
 * Primary work area view in FListLoc SubLocation
 */
public class FListLocPrimaryWorkAreaView
    extends ViewImpl
    implements FListLocPrimaryWorkAreaPresenter.MyView, IResizeView
{
	private EventBus ebus;
    protected Vector<HandlerRegistration> m_Handlers = new  Vector<HandlerRegistration>();
	
    private final Widget m_widget;

    /**
     * Sample text shown in primary work area
     */
    @UiField
    CKList cklist;
    
    @UiField
    CTList ctlist;
    
    @UiField
    HTMLPanel wkpage;
    /**
     * Ui binder
     */
    public interface Binder
        extends UiBinder<Widget, FListLocPrimaryWorkAreaView>
    {
        //
    }

    /**
     * Constructor
     *
     * @param binder UI binder
     */
    @Inject
    public FListLocPrimaryWorkAreaView( final Binder binder )
    {
    	 m_widget = binder.createAndBindUi( this );
         ctlist.setVisible(false);
         //GuoU
         ctlist.setParentView(this);
         ctlist.setParentView(this);
         
         CSession.setVIEW_MODE("SummaryView");
         Window.addResizeHandler(new ResizeHandler() {
 			@Override
 			public void onResize(ResizeEvent event) {
 				doResize();
 			}});
         
 		final Timer timer = new Timer() {
             public void run()
             {
             	FListLocPrimaryWorkAreaView.this.doResize();
             }
 		};	
 		timer.schedule(1000);
    }
    

    public void saveEventBus(EventBus eb, final FListLocPrimaryWorkAreaPresenter pst) {
    	ebus = eb;
        if(m_Handlers.size()==0)
        {
            m_Handlers.add(C7tViewModeChangeEvent.register( ebus, new C7tViewModeChangeEvent.Handler()
            {
    			@Override
    			public void doAction(C7tViewModeChangeEvent event) {    
    				if("SummaryView".equals(event.getEventViewMode().name())) {
    					cklist.setVisible(true);
    					cklist.setWidgetEditable(false);
    					ctlist.setVisible(false);
    					final Timer timer = new Timer() {
    			            public void run()
    			            {
    	    					hideSecodary();
    			            }
    					};
    					timer.schedule(500);
    				}else if("TableView".equals(event.getEventViewMode().name())) {
    					cklist.setVisible(false);
    					ctlist.setVisible(true);
    				}
    				CSession.setVIEW_MODE(event.getEventViewMode().name());
    				CommandContextChangedEvent.fireEventFromSource(ebus, pst.getSubLocation());
    				FListLocPrimaryWorkAreaView.this.doResize();
    			}
            } ));  
            m_Handlers.add(FTaskFilterEvent.register(ebus, new FTaskFilterEvent.Handler() {
				
				@Override
				public void doAction(FTaskFilterEvent event) {
					CommMsg.showMsg("All Personnal Tasks");
				}
			}));
            m_Handlers.add(FOCheckEvent.register(ebus, new FOCheckEvent.Handler() {
				
				@Override
				public void doAction(FOCheckEvent event) {
					CommMsg.showMsg("CheckItem");
					
				}
			}));
            m_Handlers.add(FGreenFilterEvent.register(ebus, new FGreenFilterEvent.Handler() {
				
				@Override
				public void doAction(FGreenFilterEvent event) {
					CommMsg.showMsg("Green");
				}
			}));
            m_Handlers.add(FRedFilterEvent.register(ebus, new FRedFilterEvent.Handler() {
				
				@Override
				public void doAction(FRedFilterEvent event) {
					CommMsg.showMsg("Red");
				}
			}));
            m_Handlers.add(FYellowFilterEvent.register(ebus, new FYellowFilterEvent.Handler() {
				
				@Override
				public void doAction(FYellowFilterEvent event) {
					CommMsg.showMsg("Yellow");
				}
			}));
            m_Handlers.add(FSubmitCheckEvent.register(ebus, new FSubmitCheckEvent.Handler() {
				
				@Override
				public void doAction(FSubmitCheckEvent event) {
					CommMsg.showMsg("pass");
				}
			}));
            m_Handlers.add(FONotSubmitEvent.register(ebus, new FONotSubmitEvent.Handler() {
				
				@Override
				public void doAction(FONotSubmitEvent event) {
					CommMsg.showMsg("not pass");
				}
			}));
        }
    }
	public static native void hideSecodary()
    /*-{
      $wnd._app.$(".aw-layout-secondaryWorkarea").addClass("hidden");
      $wnd._app.$(".aw-layout-primaryWorkarea").removeClass("aw-layout-primaryWorkareaLeft");
      $wnd._app.$(".aw-layout-primaryWorkarea").removeClass("aw-layout-summaryList");
}-*/;
    
    @Override
    public Widget asWidget()
    {
        return m_widget;
    }
    public void doResize() {
		int h =0, w=0 ;
		w = Window.getClientWidth() - - wkpage.getAbsoluteLeft();
		h = Window.getClientHeight() - wkpage.getAbsoluteTop();
		wkpage.setHeight(h+"px");
		cklist.resize(h, w);
		ctlist.resize(h, w);
	}

	public void refresh() {
		cklist.refresh();
	}

	public void selectRow(int row) {
		CommMsg.log_info("#", "doselect");
		cklist.setSelectedRow(row);		
	}
}
