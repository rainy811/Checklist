package com.patac.checklist.internal.views.list;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.cus.commrpc.published.CommSessionService;
import com.cus.commrpc.published.CommSessionServiceAsync;
import com.google.gwt.core.client.GWT;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.json.client.JSONValue;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.view.client.ListDataProvider;
import com.patac.checklist.internal.views.IResizeView;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IJSO;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.soa.published.ISOAResponse;
import com.siemens.splm.clientfx.tcui.session.published.FinderService;

public class CheckListDB {
	private static CheckListDB mIns = null;
	private static ListDataProvider<CItem> dataProvider = new ListDataProvider<CItem>();

	private static Vector<IResizeView> view_v = new Vector<IResizeView>();
	
	private CheckListDB(){};
	
	private static CommSessionServiceAsync commSessionService = GWT.create(CommSessionService.class);
	
	public static CheckListDB getInstance(){
		if(mIns==null)
			mIns = new CheckListDB();
		return mIns;
	}
	
	public ListDataProvider<CItem> getProvider(){
		return dataProvider;
	}
	
	
	public void query(){	
		dataProvider.getList().clear();
		final Timer timer = new Timer() {
            public void run()
            {
            	CommUtils.getUserID(new AsyncCallback<String>() {

        			@Override
        			public void onFailure(Throwable caught) {
        				
        			}

        			@Override
        			public void onSuccess(String result) {
        				commSessionService.selectCheckItem(result, new AsyncCallback<String>() {

        					@Override
        					public void onFailure(Throwable caught) {
        					}

        					@Override
        					public void onSuccess(String cItems) {
        						if(cItems==null)
        							return;
        						JSONValue root = null;
        						try {
        							root =  JSONParser.parseStrict(cItems);
        						}catch(IllegalArgumentException e) {
        							CommMsg.showMsg(e.getLocalizedMessage());
        						}
        						JSONArray rootContent = root.isArray();
        						if(rootContent==null)
        							return;
        						for(int i=0;i<rootContent.size(); i++){
        							CItem cItem = new CItem();
        							JSONValue one = rootContent.get(i);
        							if(one==null)
        								continue;
        							JSONObject obj = one.isObject();
        							
        							JSONValue itemId = obj.get("itemId");
        							JSONString idstr = itemId.isString();
        							if(idstr == null)
        								continue;
        							String valid = idstr.stringValue();
        							cItem.setTemplateID(valid);
        							
        							JSONValue c7tChecker = obj.get("c7tChecker");
        							JSONString checkerName = c7tChecker.isString();
        							if(checkerName == null)
        								continue;
        							String valCheckerName = checkerName.stringValue();
        							cItem.setC7tChecker(valCheckerName);
        							
        							JSONValue c7tProjName = obj.get("c7tProjectName");
        							JSONString projName = c7tProjName.isString();
        							if(projName == null)
        								continue;
        							String valprojName = projName.stringValue();
        							cItem.setC7tProjectName(valprojName);
        							
        							JSONValue c7tResult = obj.get("c7tResult");
        							JSONString res = c7tResult.isString();
        							if(res == null)
        								continue;
        							String valres = res.stringValue();
        							cItem.setC7tResult(valres);
        							
        							JSONValue c7tStatus = obj.get("c7tStatus");
        							JSONNumber status = c7tStatus.isNumber();
        							if(status == null)
        								continue;
        							int valstatus = status.hashCode();
        							cItem.setC7tStatus(valstatus);
        							
        							JSONValue lastModDate = obj.get("lastModDate");
        							JSONString lastmodTime = lastModDate.isString();
        							if(lastmodTime == null)
        								continue;
        							String vallastmodTime = lastmodTime.stringValue();
        							cItem.setLastModDate(vallastmodTime);
        							
        							JSONValue c7tFunctionFo = obj.get("c7tFunctionFo");
        							JSONString FunctionFo = c7tFunctionFo.isString();
        							if(FunctionFo == null)
        								continue;
        							String valFunctionFo = FunctionFo.stringValue();
        							cItem.setC7tFunctionFo(valFunctionFo);
        							
        							JSONValue owningGroup = obj.get("owningGroup");
        							JSONString owninggroup = owningGroup.isString();
        							if(owninggroup == null)
        								continue;
        							String valowninggroup = owninggroup.stringValue();
        							cItem.setOwningGroup(valowninggroup);

        							JSONValue c7tStandardRed = obj.get("c7tStandardRed");
        							JSONString standardRed = c7tStandardRed.isString();
        							if(standardRed == null)
        								continue;
        							String valstandardRed = standardRed.stringValue();
        							cItem.setC7tStandardRed(valstandardRed);

        							JSONValue c7tStandardYellow = obj.get("c7tStandardYellow");
        							JSONString standardYellow = c7tStandardYellow.isString();
        							if(standardYellow == null)
        								continue;
        							String valstandardYellow = standardYellow.stringValue();
        							cItem.setC7tStandardYellow(valstandardYellow);

        							JSONValue c7tStandardGreen = obj.get("c7tStandardGreen");
        							JSONString standardGreen = c7tStandardGreen.isString();
        							if(standardGreen == null)
        								continue;
        							String Green = standardGreen.stringValue();
        							cItem.setC7tStandardGreen(Green);
        							
        							JSONValue c7tResult1 = obj.get("c7tResult");
        							JSONString result = c7tResult1.isString();
        							if(result == null)
        								continue;
        							String resText = result.stringValue();
        							cItem.setC7tStandardGreen(resText);
        							
        							JSONValue c7tResultDesc = obj.get("c7tResultDesc");
        							JSONString resDesc = c7tResultDesc.isString();
        							if(resDesc == null)
        								continue;
        							String resdesc = resDesc.stringValue();
        							cItem.setC7tStandardGreen(resdesc);
        							
        							JSONValue c7tStatus1 = obj.get("c7tStatus");
        							JSONString stats = c7tStatus1.isString();
        							if(stats == null)
        								continue;
        							String resStat = stats.stringValue();
        							cItem.setC7tStandardGreen(resStat);
        							
        							dataProvider.getList().add(cItem);
        							
        						}
        						for(IResizeView v : view_v) {
        							if(v!=null) {
       								v.refresh();
       								v.doResize();
        								if(dataProvider.getList().size()>0) {
       									v.selectRow(0);
        								}
        							}	
        						}
        					}
                    		
                    	});
        			}

            	});
            }
		};	
		timer.schedule(2000);
	}
	
    protected void queryJobs( final AsyncCallback<List<IModelObject>> cabk )
    {
    	IJSO searchInput = FinderService.getPerformSearchInput( 0, 1000, 1000, null, null, null );
    	searchInput.setString( "providerName", "Awp0InboxProvider" ); //$NON-NLS-1$ //$NON-NLS-2$
        FinderService.putSearchCriteria( searchInput, "searchInboxContentType", "myTasks" ); //$NON-NLS-1$//$NON-NLS-2$
        if( CommUtils.getUserID() != null )
        {
            FinderService.putSearchCriteria( searchInput, "userId", CommUtils.getUserID() ); //$NON-NLS-1$
        }
        searchInput.setString( "searchFilterFieldSortType", "Priority" ); //$NON-NLS-1$ //$NON-NLS-2$

        FinderService.performSearch( searchInput, new AsyncCallback<ISOAResponse>() {
			@Override
			public void onFailure(Throwable caught) {				
			}

			@Override
			public void onSuccess(ISOAResponse result) {		    	
				final List<IModelObject> workList=result.getModelObjectList("searchResults");
				cabk.onSuccess(workList);
			}});
    }
	

	public static void addParentView(IResizeView pv) {
		CommMsg.log_warn("#set view", "#");
		view_v.add( pv );
	}
}
