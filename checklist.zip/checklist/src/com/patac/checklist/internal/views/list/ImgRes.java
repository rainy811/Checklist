// @<COPYRIGHT>@
// ==================================================
// Copyright 2014.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.views.list;

import com.google.gwt.core.client.GWT;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;

/**
 * gwt resources
 */
public interface ImgRes
    extends ClientBundle
{
    ImgRes INSTANCE = GWT.create( ImgRes.class );

    @Source( "com/patac/checklist/internal/views/list/item.png" )
    ImageResource itemImg();

    @Source( "com/patac/checklist/internal/views/list/车.jpg" )
    ImageResource getCarPic();
    
    @Source( "com/patac/checklist/internal/views/list/blancCar.jpg")
    ImageResource blancCar();
}
