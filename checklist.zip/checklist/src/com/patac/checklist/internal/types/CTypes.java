// @<COPYRIGHT>@
// ==================================================
// Copyright 2014.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.types;

import java.util.ArrayList;

import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.MaturityEnum;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.Scope;

/**
 * This interface centralizes the definition of Report's property names.
 * <P>
 * Note: These values are not effected by locale and should not include any values not part of out-of-the-box (OOTB)
 * Teamcenter (fnd0xxxx is considered OOTB).
 * <P>
 * <UL>
 * <LI>Keep the constants sorted alpha-numerically.</LI>
 * <LI>The constant name should match the value of the constant. The one exception is that you can drop the prefix (i.e.
 * 'fnd0').</LI>
 * </UL>
 */
@ApiVisibility( publishScope = Scope.Internal, maturity = MaturityEnum.Experimental )
public class CTypes
{
	private static ArrayList<String> m_CheckDefProps =  new ArrayList<String>();
	   public static String Dataset = "Dataset";//$NON-NLS-1$
	   public static String WorkspaceObject = "WorkspaceObject"; //$NON-NLS-1$
	   public static String C7t_Prj_Item = "C7t_Prj_Item"; //$NON-NLS-1$
	   public static String C7t_CheckDef = "C7t_CheckDef"; //$NON-NLS-1$
	   public static String C7t_CheckItem = "C7t_CheckItem"; //$NON-NLS-1$
	   public static String DOT_SPLITTER = "\\."; //$NON-NLS-1$
	   public static String GROUP_NAME = "group_name"; //$NON-NLS-1$
	   public static String GROUP = "group"; //$NON-NLS-1$
	   public static String OBJ_FULL_NAME = "object_full_name"; //$NON-NLS-1$
	   public static String CHECK_LIST_ADMIN = "C7T Admin"; //$NON-NLS-1$
	   
	   //=====Properties===================================================
	   static String uom_tag = "uom_tag"; //$NON-NLS-1$
	   public static String item_id = "item_id"; //$NON-NLS-1$
	   public static String object_name = "object_name"; //$NON-NLS-1$
	   public static String object_string = "object_string"; //$NON-NLS-1$
	   static String object_desc = "object_desc"; //$NON-NLS-1$
	   static String creation_date = "creation_date"; //$NON-NLS-1$
	   static String date_released = "date_released"; //$NON-NLS-1$
	   static String last_mod_date = "last_mod_date"; //$NON-NLS-1$
	   static String last_mod_user = "last_mod_user"; //$NON-NLS-1$
	   public static String owning_group = "owning_group"; //$NON-NLS-1$
	   public static String revision_list = "revision_list"; //$NON-NLS-1$ 
	   public static String is_modifiable="is_modifiable";//$NON-NLS-1$   

	   public static String rel_reference = "IMAN_reference";
	   public static String rel_rendering = "IMAN_Rendering";

	   public static String my_obj = "my_obj"; //$NON-NLS-1$
	   public static String owning_user = "owning_user"; //$NON-NLS-1$
	   public static String TRUE = "true"; //$NON-NLS-1$
	   public static String FALSE = "false"; //$NON-NLS-1$
	   
	   
	   public static String c7t_CLS01 = "c7t_CLS01"; //$NON-NLS-1$
	   public static String c7t_CLS02 = "c7t_CLS02"; //$NON-NLS-1$
	   public static String c7t_dept = "c7t_dept"; //$NON-NLS-1$
	   public static String c7t_Dept01 = "c7t_Dept01"; //$NON-NLS-1$
	   public static String c7t_Dept02 = "c7t_Dept02"; //$NON-NLS-1$
	   public static String c7t_Territory = "c7t_Territory"; //$NON-NLS-1$
	   public static String c7t_DevLvl = "c7t_level"; //$NON-NLS-1$
	   public static String c7t_app_states = "c7t_app_states"; //$NON-NLS-1$
	   public static String c7t_TypeOfCheck = "c7t_TypeOfCheck"; //$NON-NLS-1$
	   public static String c7t_CheckStd = "c7t_CheckStd"; //$NON-NLS-1$  
	   public static String c7t_RefUrls = "c7t_RefUrls"; //$NON-NLS-1$  
	   public static String c7t_publish = "c7t_publish"; //$NON-NLS-1$  
	   public static String c7t_user_id = "c7t_user_id"; //$NON-NLS-1$  

	   public static String c7t_Vehicle = "c7t_vehicle"; //$NON-NLS-1$  
	   public static String c7t_Importance = "c7t_importance"; //$NON-NLS-1$ 
	   public static String c7t_Function_id = "c7t_function_id";//$NON-NLS-1$ 
	   public static String c7t_Function_name = "c7t_function_name";//$NON-NLS-1$ 
	   public static String c7t_Function_fo = "c7t_function_fo";//$NON-NLS-1$ 
	   public static String c7t_Function_fo_id = "c7t_function_fo_id";//$NON-NLS-1$ 
	   public static String c7t_Project_role_name = "c7t_project_role_name"; //$NON-NLS-1$ 
	   public static String c7t_Project_role_id = "c7t_project_role_id"; //$NON-NLS-1$ 
	   
	   
	   public static String c7t_vse = "c7t_vse"; //$NON-NLS-1$  
	   public static String c7t_pm = "c7t_pm"; //$NON-NLS-1$  
	   public static String c7t_states = "c7t_states"; //$NON-NLS-1$  
	   public static String c7t_territories = "c7t_territories"; //$NON-NLS-1$  
	   public static String c7t_devLvls = "c7t_level"; //$NON-NLS-1$  
	   public static String c7t_vehicles = "c7t_vehicles"; //$NON-NLS-1$  
	   
	   public static String  c7t_red = "c7t_standard_red";
	   public static String  c7t_yellow = "c7t_standard_yellow ";
	   public static String  c7t_green = "c7t_standard_green";
	   
	   public static String[] getCheckDefRels(){
		   return new String[] {rel_reference, rel_rendering};
	   }

	   public static String[] getProjItemProps(){
		   return new String[] {c7t_dept, object_name, item_id, object_string, revision_list};
	   }
	   
	   public static String[] getProjRevProps(){
		   return new String[] {object_name, item_id, object_string, c7t_vse, c7t_pm, c7t_states, c7t_territories, c7t_devLvls, c7t_vehicles};
	   }

	   public static String[] getCheckDefProps(){
		   return new String[] {object_name, c7t_Function_name, c7t_Project_role_name, c7t_Vehicle,c7t_red,c7t_yellow,c7t_green, c7t_CLS01, c7t_Importance, c7t_Function_id, c7t_Function_fo, c7t_Function_fo_id, c7t_DevLvl, c7t_Dept01, c7t_Dept02, c7t_app_states, c7t_CheckStd, c7t_RefUrls, is_modifiable};
	   }

	   public static String[] getCheckItemProps(){
		   return new String[] {object_name, c7t_Function_name, c7t_Project_role_name, c7t_Vehicle, c7t_red,c7t_yellow,c7t_green,c7t_CLS01, c7t_Importance, c7t_Function_id, c7t_Function_fo, c7t_Function_fo_id, c7t_DevLvl, c7t_Dept01, c7t_Dept02, c7t_app_states, c7t_CheckStd, c7t_RefUrls, is_modifiable};
	   }
	   
	   public static ArrayList<String> getCheckDefProps2(){
		   if(m_CheckDefProps.size()<=0)
			   for(String att : getCheckDefProps()){
				   m_CheckDefProps.add(att);
			   }
		   return m_CheckDefProps;
	   }
}
