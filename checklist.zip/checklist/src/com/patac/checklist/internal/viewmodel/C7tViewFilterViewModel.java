// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.viewmodel;

import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.ui.databind.published.viewmodel.AbstractViewModel;
import com.siemens.splm.clientfx.ui.databind.published.viewmodel.IViewModelHelper;

/**
 * The ViewModel for the com.patac.checklist.
 */
public class C7tViewFilterViewModel
    extends AbstractViewModel
{
    /**
     * The current model object being used in the C7tViewFilter panel.
     */
    private IModelObject m_currentModelObject;

    /**
     * /** Sets the model object to navigation panel.
     * 
     * @param modelObject The model object selected and used for the C7tViewFilter panel.
     */
    public void setModelObject( IModelObject modelObject )
    {
        m_currentModelObject = modelObject;
    }

    /**
     * Returns the model object which is presented in the Panel.
     * 
     * @return The model object which is presented in the Panel.
     */

    public IModelObject getModelObject()
    {
        return m_currentModelObject;
    }
    
    @Override
    protected IViewModelHelper getViewModelHelper()
    {
        return null;
    }
}
