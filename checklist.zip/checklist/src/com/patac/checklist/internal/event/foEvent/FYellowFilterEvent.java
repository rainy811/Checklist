package com.patac.checklist.internal.event.foEvent;

import com.google.gwt.event.shared.EventHandler;
import com.google.gwt.event.shared.GwtEvent;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.MaturityEnum;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.Scope;

@ApiVisibility( maturity = MaturityEnum.Mature, publishScope = Scope.Internal )
public class FYellowFilterEvent  extends GwtEvent<FYellowFilterEvent.Handler>
{
	public FYellowFilterEvent(){
		super();
	}
	
    /**
     * Favorites Refresh Event Handler
     */
    public interface Handler extends EventHandler
    {
        /**
         * @param event RefreshEvent
         */
		void doAction(FYellowFilterEvent event);
    }

    /**
     * Required Type Definition for an Event
     */
    private static final Type<Handler> TYPE = new Type<>();

    /**
     * Method to register for modified model object events.
     *
     * @param bus the event bus
     * @param handler the handler to register
     * @return The handler registration that can be used to unregister the handler
     */
    public static HandlerRegistration register( EventBus bus, Handler handler )
    {
        return bus.addHandler( FYellowFilterEvent.TYPE, handler );
    }

    @Override
    protected void dispatch( Handler handler )
    {
        handler.doAction( this );
    }

    @Override
    public Type<Handler> getAssociatedType()
    {
        return FYellowFilterEvent.TYPE;
    }
}
