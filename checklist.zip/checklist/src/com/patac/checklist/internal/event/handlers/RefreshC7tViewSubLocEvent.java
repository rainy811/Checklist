// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.event.handlers;

import com.google.gwt.event.shared.EventHandler;
import com.google.gwt.event.shared.GwtEvent;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.MaturityEnum;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.Scope;

/**
 * Favorites Refresh Event
 */
@ApiVisibility( maturity = MaturityEnum.Mature, publishScope = Scope.Internal )
public class RefreshC7tViewSubLocEvent
    extends GwtEvent<RefreshC7tViewSubLocEvent.Handler>
{
    /**
     * Favorites Refresh Event Handler
     */
    public interface Handler
        extends EventHandler
    {
        /**
         * @param event RefreshEvent
         */
        void doAction( RefreshC7tViewSubLocEvent event );
    }

    /**
     * Required Type Definition for an Event
     */
    private static final Type<Handler> TYPE = new Type<>();

    /**
     * Method to register for modified model object events.
     *
     * @param bus the event bus
     * @param handler the handler to register
     * @return The handler registration that can be used to unregister the handler
     */
    public static HandlerRegistration register( EventBus bus, Handler handler )
    {
        return bus.addHandler( RefreshC7tViewSubLocEvent.TYPE, handler );
    }

    @Override
    protected void dispatch( Handler handler )
    {
        handler.doAction( this );
    }

    @Override
    public Type<Handler> getAssociatedType()
    {
        return RefreshC7tViewSubLocEvent.TYPE;
    }
}
