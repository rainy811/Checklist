// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.event.handlers;

import com.google.gwt.event.shared.EventHandler;
import com.google.gwt.event.shared.GwtEvent;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.patac.checklist.internal.service.QueryInputSet;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.MaturityEnum;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.Scope;

/**
 * Favorites Refresh Event
 */
@ApiVisibility( maturity = MaturityEnum.Mature, publishScope = Scope.Internal )
public class LoadC7tViewEvent
    extends GwtEvent<LoadC7tViewEvent.Handler>
{
	private QueryInputSet m_inupts;
    /**
     * Favorites Refresh Event Handler
     */
    public interface Handler
        extends EventHandler
    {
        /**
         * @param event RefreshEvent
         */
        void doAction( LoadC7tViewEvent event );
    }

    /**
     * Required Type Definition for an Event
     */
    private static final Type<Handler> TYPE = new Type<>();

    /**
     * Method to register for modified model object events.
     *
     * @param bus the event bus
     * @param handler the handler to register
     * @return The handler registration that can be used to unregister the handler
     */
    public static HandlerRegistration register( EventBus bus, Handler handler )
    {
        return bus.addHandler( LoadC7tViewEvent.TYPE, handler );
    }
    
    public LoadC7tViewEvent (){}
    
    public LoadC7tViewEvent (QueryInputSet qset) {
    	m_inupts = qset;
	}
    
    public QueryInputSet getInputs(){
    	return m_inupts;
    }

    @Override
    protected void dispatch( Handler handler )
    {
        handler.doAction( this );
    }

    @Override
    public Type<Handler> getAssociatedType()
    {
        return LoadC7tViewEvent.TYPE;
    }
}
