// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.event.handlers;

import com.google.gwt.event.shared.EventHandler;
import com.google.gwt.event.shared.GwtEvent;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.patac.checklist.internal.service.QueryInputSet;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.MaturityEnum;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.Scope;

/**
 * Favorites Refresh Event
 */
@ApiVisibility( maturity = MaturityEnum.Mature, publishScope = Scope.Internal )
public class LoadC7tDefineEvent
    extends GwtEvent<LoadC7tDefineEvent.Handler>
{
	private QueryInputSet m_inupts;
    /**
     * Favorites Refresh Event Handler
     */
    public interface Handler
        extends EventHandler
    {
        /**
         * @param event RefreshEvent
         */
        void doAction( LoadC7tDefineEvent event );
    }

    /**
     * Required Type Definition for an Event
     */
    private static final Type<Handler> TYPE = new Type<>();

    public LoadC7tDefineEvent(){};
    
    public LoadC7tDefineEvent(QueryInputSet qset) {
    	m_inupts = qset;
	}
    
    public QueryInputSet getInputs(){
    	return m_inupts;
    }

	/**
     * Method to register for modified model object events.
     *
     * @param bus the event bus
     * @param handler the handler to register
     * @return The handler registration that can be used to unregister the handler
     */
    public static HandlerRegistration register( EventBus bus, Handler handler )
    {
        return bus.addHandler( LoadC7tDefineEvent.TYPE, handler );
    }

    @Override
    protected void dispatch( Handler handler )
    {
        handler.doAction( this );
    }

    @Override
    public Type<Handler> getAssociatedType()
    {
        return LoadC7tDefineEvent.TYPE;
    }
}
