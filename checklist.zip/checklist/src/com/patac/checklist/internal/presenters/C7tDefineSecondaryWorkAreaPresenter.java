package com.patac.checklist.internal.presenters;

import com.cus.comm.published.presenters.NoSelectPresenterW;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListSecondaryWorkAreaPresenterW;
import com.siemens.splm.clientfx.ui.published.uihandlers.ISubLocationContentViewUiHandlers;
import com.siemens.splm.clientfx.ui.published.views.ISubLocationNonScrollableContentView;

public class C7tDefineSecondaryWorkAreaPresenter extends
		ModelObjectListSecondaryWorkAreaPresenterW {

	@Inject
	private AsyncProvider<NoSelectPresenterW> m_Presenter;
	
	@Inject
	public C7tDefineSecondaryWorkAreaPresenter(EventBus eventBus,	 ISubLocationNonScrollableContentView view) {
		super(eventBus, view);
	}

	@Override
	protected void showNoSelectionView() {		
		m_Presenter.get(new AsyncCallback<NoSelectPresenterW>(){

			@Override
			public void onFailure(Throwable caught) {
				setInSlot( ISubLocationContentViewUiHandlers.VIEW_SLOT, null );
			}

			@Override
			public void onSuccess(NoSelectPresenterW result) {
				setInSlot( ISubLocationContentViewUiHandlers.VIEW_SLOT, result);				
			}});
	}

}
