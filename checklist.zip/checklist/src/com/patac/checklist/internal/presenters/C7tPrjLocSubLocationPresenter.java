// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.presenters;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.cus.comm.published.i18n.CommMessages;
import com.cus.comm.published.utils.CommUtils;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.gwtplatform.mvp.client.annotations.NameToken;
import com.gwtplatform.mvp.client.annotations.ProxyCodeSplit;
import com.gwtplatform.mvp.client.proxy.ProxyPlace;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.event.handlers.LoadC7tPrjRevEvent;
import com.patac.checklist.internal.event.handlers.RefreshC7tPrjSubLocEvent;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.internal.ui.common.widgets.prjtree.ProjService;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.kernel.published.ISession;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListPrimaryWorkAreaPresenterW;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListSubLocationPresenter;
import com.siemens.splm.clientfx.tcui.xrt.resources.i18n.XRTMessages;
import com.siemens.splm.clientfx.ui.published.ILocation;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractSubLocationPresenter;
import com.siemens.splm.clientfx.ui.published.utils.AsyncProviderHelper;

/**
 * C7tViewLoc sub-location
 */
public class C7tPrjLocSubLocationPresenter
    extends ModelObjectListSubLocationPresenter<AbstractSubLocationPresenter.MyView, C7tPrjLocSubLocationPresenter.MyProxy>
{
    /** Priority 0 will make this sub-location first. */
    public static final int PRIORITY = 3;

    protected Vector<HandlerRegistration> m_Handlers = new  Vector<HandlerRegistration>();
    protected String m_NameFilter = null;
    protected List<IModelObject> m_objSet = new ArrayList<IModelObject>();
 

    /** CheckListMain Location Presenter. */
    @Inject
    private CheckListMainLocationPresenter m_locationPresenter;

	private C7tPrjSecondaryWorkAreaPresenter m_secondaryWorkAreaPresenter;
    
	
    @ProxyCodeSplit
    @NameToken( NameTokens.C7tProjLoc_TOKEN )
    public interface MyProxy
        extends ProxyPlace<C7tPrjLocSubLocationPresenter>
    {
        
    }

    /**
     * Constructor
     *
     * @param eventBus Event Bus
     * @param view View
     * @param proxy Proxy
     */
    @Inject
    public C7tPrjLocSubLocationPresenter( EventBus eventBus, MyView view, MyProxy proxy, ISession session,
            ModelObjectListPrimaryWorkAreaPresenterW primaryWorkAreaPresenter,
            C7tPrjSecondaryWorkAreaPresenter secondaryWorkAreaPresenter)
    {
        super( eventBus, view, proxy, primaryWorkAreaPresenter, secondaryWorkAreaPresenter );
        m_secondaryWorkAreaPresenter = secondaryWorkAreaPresenter;        
    }
    
    @Override
    public AsyncProvider<? extends ILocation> getLocation()
    {
    	return AsyncProviderHelper.convertAsyncProvider( m_locationPresenter, ILocation.class );
    }
    
    public EventBus getEventBus2(){
    	return getEventBus();
    }
    
    public ModelObjectListPrimaryWorkAreaPresenterW getPrimaryWorkAreaP(){
    	return getPrimaryWorkAreaPresenter();
    }
    
    @Override
    public void getModelObjectList( final AsyncCallback<List<IModelObject>> callback )
    {
    	//CommMsg.log_warn("#C7tDefineLocSubLocationPresenter", "#getModelObjectList="+m_objSet.size());
    	callback.onSuccess(m_objSet);    	
    }
    
    @Override
    protected void onReveal()
    {
    	final EventBus eventbus = getEventBus();
    	if(m_Handlers.isEmpty()){
	    	m_Handlers.add( RefreshC7tPrjSubLocEvent.register(eventbus, new RefreshC7tPrjSubLocEvent.Handler()
	        {
				@Override
				public void doAction(RefreshC7tPrjSubLocEvent event) {
					C7tPrjLocSubLocationPresenter.super.onReveal();
					C7tPrjLocSubLocationPresenter.this.refresh();
				}
	        } )); 
	    	
	    	m_Handlers.add( LoadC7tPrjRevEvent.register(eventbus, new LoadC7tPrjRevEvent.Handler()
	        {
				@Override
				public void doAction(LoadC7tPrjRevEvent event) {
					String prj_code = event.getPrjCode();
					if(prj_code==null){
						m_objSet.clear();
						eventbus.fireEvent(new RefreshC7tPrjSubLocEvent());
						return;
					}
					ProjService.findProj(prj_code, CommUtils.getUserGroupFull(), new AsyncCallback<List<IModelObject>>() {

						@Override
						public void onFailure(Throwable caught) {
						}

						@Override
						public void onSuccess(List<IModelObject> result) {
							m_objSet.clear();
							if(result!=null && result.size()>0){
								IModelObject defitem = result.get(0);
								IProperty<List<IModelObject>> revlist = (IProperty<List<IModelObject>>) defitem.getPropertyObject(CTypes.revision_list);
								if(revlist!=null){
									m_objSet.addAll(revlist.getValue());
								}
							}	
							eventbus.fireEvent(new RefreshC7tPrjSubLocEvent());
						}});
				}
	        } )); 
	    	   
    	}
    	
    	eventbus.fireEvent(new RefreshC7tPrjSubLocEvent());
    	super.onReveal();
    }
    
    @Override
    public String getLabel()
    {
        return ChecklistMessages.INSTANCE.C7tProjLocTitle();
    }
    
    @Override
	public void refreshWorkAreaTitle()
    {
        String workAreaTitle = m_objSet.size() == 0 ? CommMessages.INSTANCE.emptyListText()
                : XRTMessages.INSTANCE.dataCount( m_objSet.size() );

        // see if we need to prefix the count with multi-select info.
        workAreaTitle = getMultiSelectPrefix() + workAreaTitle;

        setWorkAreaTitle( workAreaTitle );
    }

    @Override
    public String getHistoryNameToken()
    {
        return NameTokens.C7tProjLoc_TOKEN;
    }

    @Override
    public String getSubLocationNameToken()
    {
        return NameTokens.C7tProjLoc_SUB_LOCATION;
    }

    @Override
    public int getPriority()
    {
        return C7tPrjLocSubLocationPresenter.PRIORITY;
    }

}
