// @<COPYRIGHT>@
// ==================================================
// Copyright 2018.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.presenters;

import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.gwtplatform.mvp.client.View;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractPrimaryWorkAreaPresenterWidget;

/**
 * Primary Work Area Presenter for FListLoc SubLocation
 */
public class FListLocPrimaryWorkAreaPresenter
    extends AbstractPrimaryWorkAreaPresenterWidget<FListLocPrimaryWorkAreaPresenter.MyView>
{
    /**
     * View interface
     */
    public interface MyView
        extends View
    {
        public void saveEventBus(EventBus eb, FListLocPrimaryWorkAreaPresenter pst);
    }

    /**
     * Constructor
     *
     * @param eventBus Event bus
     * @param view View
     */
    @Inject
    public FListLocPrimaryWorkAreaPresenter( final EventBus eventBus, final MyView view )
    {
        super( eventBus, view );
        view.saveEventBus(getEventBus(), this);
    }
}
