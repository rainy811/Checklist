// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.presenters;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommSession;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.gwtplatform.mvp.client.annotations.NameToken;
import com.gwtplatform.mvp.client.annotations.ProxyCodeSplit;
import com.gwtplatform.mvp.client.proxy.ProxyPlace;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.config.IChecklistInjector;
import com.patac.checklist.internal.event.handlers.C7tViewModeChangeEvent;
import com.patac.checklist.internal.event.handlers.LoadC7tDefineEvent;
import com.patac.checklist.internal.event.handlers.LoadC7tViewEvent;
import com.patac.checklist.internal.event.handlers.RefreshC7tDefineSubLocEvent;
import com.patac.checklist.internal.event.handlers.RefreshC7tViewSubLocEvent;
import com.patac.checklist.internal.service.CSession;
import com.patac.checklist.internal.service.CSoaService;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.published.ISession;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListPrimaryWorkAreaPresenterW;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListSubLocationPresenter;
import com.siemens.splm.clientfx.ui.published.ILocation;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractSubLocationPresenter;

/**
 * C7tViewLoc sub-location
 */
public class C7tViewLocSubLocationPresenter
    extends ModelObjectListSubLocationPresenter<AbstractSubLocationPresenter.MyView, C7tViewLocSubLocationPresenter.MyProxy>
{
    /** Priority 0 will make this sub-location first. */
    public static final int PRIORITY = 0;

    protected Vector<HandlerRegistration> m_Handlers = new  Vector<HandlerRegistration>();
    protected String m_NameFilter = null;
    protected List<IModelObject> m_objSet = new ArrayList<IModelObject>();
 

    /** CheckListMain Location Presenter. */
    @Inject
    private CheckListMainLocationPresenter m_locationPresenter;

	private C7tDefineSecondaryWorkAreaPresenter m_secondaryWorkAreaPresenter;
    /**
     * Proxy of C7tViewLocSubLocationPresenter
     */
    @ProxyCodeSplit
    @NameToken( NameTokens.C7tViewLoc_TOKEN )
    public interface MyProxy
        extends ProxyPlace<C7tViewLocSubLocationPresenter>
    {
        
    }

    /**
     * Constructor
     *
     * @param eventBus Event Bus
     * @param view View
     * @param proxy Proxy
     */
    @Inject
    public C7tViewLocSubLocationPresenter( EventBus eventBus, MyView view, MyProxy proxy, ISession session,
            ModelObjectListPrimaryWorkAreaPresenterW primaryWorkAreaPresenter,
            C7tDefineSecondaryWorkAreaPresenter secondaryWorkAreaPresenter)
    {
        super( eventBus, view, proxy, primaryWorkAreaPresenter, secondaryWorkAreaPresenter );
        m_secondaryWorkAreaPresenter = secondaryWorkAreaPresenter;
        
    }
    
//    @Override
//    public void performOnReset()
//    {
//    	super.performOnReset();
//    	if(ModelObjectListSubLocationPresenter.ViewMode.TableView!=getViewMode() && ModelObjectListSubLocationPresenter.ViewMode.TableSummaryView!=getViewMode()){
//    		CommMsg.log_info("#", "performOnReset()");
//    		setWorkAreaViewMode( ModelObjectListSubLocationPresenter.ViewMode.TableView );
//    	}
//    	CommSession.setVIEW_MODE(getViewMode().name());
//    }
    
    @Override
    public AsyncProvider<? extends ILocation> getLocation()
    {
    	return  IChecklistInjector.INSTANCE.getCheckListMainLocationPresenter();
    }
    
    public ModelObjectListPrimaryWorkAreaPresenterW getPrimaryWorkAreaP(){
    	return getPrimaryWorkAreaPresenter();
    }
    
    @Override
    public void getModelObjectList( final AsyncCallback<List<IModelObject>> callback )
    {
    	//CommMsg.log_warn("#C7tDefineLocSubLocationPresenter", "#getModelObjectList="+m_objSet.size());
    	callback.onSuccess(m_objSet);    	
    }
    
    @Override
    protected void onReveal()
    {
    	final EventBus eventbus = getEventBus();
    	if(m_Handlers.isEmpty()){
	    	m_Handlers.add( RefreshC7tViewSubLocEvent.register(eventbus, new RefreshC7tViewSubLocEvent.Handler()
	        {
				@Override
				public void doAction(RefreshC7tViewSubLocEvent event) {
					C7tViewLocSubLocationPresenter.super.onReveal();
					C7tViewLocSubLocationPresenter.this.refresh();
				}
	        } )); 
	    	
	    	m_Handlers.add( LoadC7tViewEvent.register(eventbus, new LoadC7tViewEvent.Handler()
	        {
				@Override
				public void doAction(LoadC7tViewEvent event) {
					CSoaService.findC7tItems(event.getInputs(), CTypes.getCheckItemProps(), new AsyncCallback<List<IModelObject>>(){

						@Override
						public void onFailure(Throwable caught) {
							CommMsg.showMsg(ChecklistMessages.INSTANCE.txtSearchCriteriaErr());
							m_objSet.clear();
							eventbus.fireEvent(new RefreshC7tViewSubLocEvent());
						}

						@Override
						public void onSuccess(List<IModelObject> result) {
							m_objSet.clear();
							m_objSet.addAll(result);
							eventbus.fireEvent(new RefreshC7tViewSubLocEvent());
						}
						
					});
				}
	        } )); 
	    	
//	        m_Handlers.add(C7tViewModeChangeEvent.register( getEventBus(), new C7tViewModeChangeEvent.Handler()
//	        {
//				@Override
//				public void doAction(C7tViewModeChangeEvent event) {	
//					C7tViewLocSubLocationPresenter.this.setWorkAreaViewMode(event.getEventViewMode());
//					C7tViewLocSubLocationPresenter.this.refresh();
//					CSession.setVIEW_MODE(getViewMode().name());
//				}
//	        } ));        
    	}
    	
    	eventbus.fireEvent(new LoadC7tViewEvent());
    	super.onReveal();
    }
    
    @Override
    public String getLabel()
    {
        return ChecklistMessages.INSTANCE.C7tViewLocTitle();
    }

    @Override
    public String getHistoryNameToken()
    {
        return NameTokens.C7tViewLoc_TOKEN;
    }

    @Override
    public String getSubLocationNameToken()
    {
        return NameTokens.C7tViewLoc_SUB_LOCATION;
    }

    @Override
    public int getPriority()
    {
        return C7tViewLocSubLocationPresenter.PRIORITY;
    }

}
