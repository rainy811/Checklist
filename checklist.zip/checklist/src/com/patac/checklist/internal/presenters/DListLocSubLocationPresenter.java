// @<COPYRIGHT>@
// ==================================================
// Copyright 2018.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.presenters;

import com.google.gwt.inject.client.AsyncProvider;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.gwtplatform.mvp.client.annotations.NameToken;
import com.gwtplatform.mvp.client.annotations.ProxyCodeSplit;
import com.gwtplatform.mvp.client.proxy.ProxyPlace;
import com.siemens.splm.clientfx.ui.published.ILocation;
import com.siemens.splm.clientfx.ui.published.IPrimaryWorkArea;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractSubLocationPresenter;
import com.siemens.splm.clientfx.ui.published.utils.AsyncProviderHelper;

/**
 * DListLoc sub-location
 */
public class DListLocSubLocationPresenter
    extends AbstractSubLocationPresenter<AbstractSubLocationPresenter.MyView, DListLocSubLocationPresenter.MyProxy>
{
    /** Priority 0 will make this sub-location first. */
    public static final int PRIORITY = 0;

    /** Primary work area presenter for DListLoc. */
    @Inject
    private DListLocPrimaryWorkAreaPresenter m_primaryWorkAreaPresenter;

    /** CheckListMain Location Presenter. */
    @Inject
    private CheckListMainLocationPresenter m_locationPresenter;

    /**
     * Proxy of DListLocSubLocationPresenter
     */
    @ProxyCodeSplit
    @NameToken( NameTokens.DListLoc_TOKEN )
    public interface MyProxy
        extends ProxyPlace<DListLocSubLocationPresenter>
    {
        //
    }

    /**
     * Constructor
     *
     * @param eventBus Event Bus
     * @param view View
     * @param proxy Proxy
     */
    @Inject
    public DListLocSubLocationPresenter( EventBus eventBus, MyView view, MyProxy proxy )
    {
        super( eventBus, view, proxy );
    }

    @Override
    public String getLabel()
    {
        return ChecklistMessages.INSTANCE.DListLocTitle();
    }

    @Override
    public String getHistoryNameToken()
    {
        return NameTokens.DListLoc_TOKEN;
    }

    @Override
    public String getSubLocationNameToken()
    {
        return NameTokens.DListLoc_SUB_LOCATION;
    }

    @Override
    public int getPriority()
    {
        return DListLocSubLocationPresenter.PRIORITY;
    }

    @Override
    public AsyncProvider<? extends ILocation> getLocation()
    {
        return AsyncProviderHelper.convertAsyncProvider( m_locationPresenter, ILocation.class );
    }

    @Override
    public AsyncProvider<IPrimaryWorkArea> getPrimaryWorkArea()
    {
        return AsyncProviderHelper.convertAsyncProvider( m_primaryWorkAreaPresenter, IPrimaryWorkArea.class );
    }
}
