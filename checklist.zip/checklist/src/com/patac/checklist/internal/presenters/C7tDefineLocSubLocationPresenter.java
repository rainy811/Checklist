// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.presenters;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.gwtplatform.mvp.client.annotations.NameToken;
import com.gwtplatform.mvp.client.annotations.ProxyCodeSplit;
import com.gwtplatform.mvp.client.proxy.PlaceRequest;
import com.gwtplatform.mvp.client.proxy.ProxyPlace;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.event.handlers.C7tViewModeChangeEvent;
import com.patac.checklist.internal.event.handlers.RefreshAndSelectC7tDefineSubLocEvent;
import com.patac.checklist.internal.event.handlers.ShowSessionC7tDefineEvent;
import com.patac.checklist.internal.service.CSession;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.client.favorites.published.RefreshEvent;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.published.ISession;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListPrimaryWorkAreaPresenterW;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListSubLocationPresenter;
import com.siemens.splm.clientfx.ui.databind.published.viewmodel.IViewModelCollection;
import com.siemens.splm.clientfx.ui.published.ILocation;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractSubLocationPresenter;
import com.siemens.splm.clientfx.ui.published.utils.AsyncProviderHelper;

/**
 * C7tDefineLoc sub-location
 */
public class C7tDefineLocSubLocationPresenter
    extends AbstractC7tDefineSubLocationPresenter<AbstractSubLocationPresenter.MyView, C7tDefineLocSubLocationPresenter.MyProxy>
{
    /** Priority 0 will make this sub-location first. */
    public static final int PRIORITY = 1;

    private boolean m_inited = false;
    /** Primary work area presenter for C7tDefineLoc. */
    protected Vector<HandlerRegistration> m_Handlers = new  Vector<HandlerRegistration>();
    

    /** CheckListMain Location Presenter. */
    @Inject
    private CheckListMainLocationPresenter m_locationPresenter;
    
    private ModelObjectListPrimaryWorkAreaPresenterW m_primaryWorkAreaPresenter;
    
    /**
     * Proxy of C7tDefineLocSubLocationPresenter
     */
    @ProxyCodeSplit
    @NameToken( NameTokens.C7tDefineLoc_TOKEN )
    public interface MyProxy
        extends ProxyPlace<C7tDefineLocSubLocationPresenter>
    {
        //
    }

    
    /**
     * Constructor
     *
     * @param eventBus Event Bus
     * @param view View
     * @param proxy Proxy
     */
    @Inject
    public C7tDefineLocSubLocationPresenter( EventBus eventBus, MyView view, MyProxy proxy , ISession session,
    		ModelObjectListPrimaryWorkAreaPresenterW primaryWorkAreaPresenter, C7tDefineSecondaryWorkAreaPresenter secondaryWorkAreaPresenter)
    {
    	super( eventBus, view, proxy, session, primaryWorkAreaPresenter, secondaryWorkAreaPresenter);
        if( primaryWorkAreaPresenter != null )
        {
        	m_primaryWorkAreaPresenter = primaryWorkAreaPresenter;
            primaryWorkAreaPresenter.setOverrideSelectionModel( IViewModelCollection.SelectionPolicy.SINGLE );
        }
    }
    
    @Override
    public void prepareFromRequest( PlaceRequest request )
    {

    }   

    @Override
    protected void onReveal()
    {
    	super.onReveal();
    	if(m_inited==false){
    		final EventBus ebus = getEventBus();
	        m_Handlers.add(RefreshEvent.register( ebus, new RefreshEvent.Handler()
	        {
	            @Override
	            public void refresh( RefreshEvent event )
	            {
	            	C7tDefineLocSubLocationPresenter.this.refresh();
	            }
	        } ));
	        m_Handlers.add(C7tViewModeChangeEvent.register( ebus, new C7tViewModeChangeEvent.Handler()
	        {
				@Override
				public void doAction(C7tViewModeChangeEvent event) {
					C7tDefineLocSubLocationPresenter.this.setWorkAreaViewMode(event.getEventViewMode());
					C7tDefineLocSubLocationPresenter.super.onRevealSuper();
					C7tDefineLocSubLocationPresenter.this.refresh();
					CSession.setVIEW_MODE(getViewMode().name());
				}
	        } ));
	    	m_Handlers.add( RefreshAndSelectC7tDefineSubLocEvent.register( ebus, new RefreshAndSelectC7tDefineSubLocEvent.Handler()
	        {
				@Override
				public void doAction(RefreshAndSelectC7tDefineSubLocEvent event) {
					C7tDefineLocSubLocationPresenter.this.setWorkAreaViewMode(ModelObjectListSubLocationPresenter.ViewMode.SummaryView);
					C7tDefineLocSubLocationPresenter.super.onRevealSuper();
					C7tDefineLocSubLocationPresenter.this.refresh();
					String uid = event.getSelectUid();
					if(uid!=null){
						CommUtils.loadObject(uid, new AsyncCallback<IModelObject>(){
							@Override
							public void onFailure(Throwable caught) {
								CommMsg.log_warn("#Load Object Error", caught.getLocalizedMessage());
							}

							@Override
							public void onSuccess(IModelObject obj) {								
								m_primaryWorkAreaPresenter.setSelectedModelObject(obj);
								//m_primaryWorkAreaPresenter.getEditHandler().startEdit();
//								StartEditOperation operation = new StartEditOperation(m_primaryWorkAreaPresenter.getEditHandler());
//								CommUtils.getOpManager().schedule(operation);
							}});	
					}		
				}
	        } )); 
	        m_Handlers.add(ShowSessionC7tDefineEvent.register( ebus, new ShowSessionC7tDefineEvent.Handler()
	        {
				@Override
				public void doAction(ShowSessionC7tDefineEvent event) {
					final String uid = event.getSelectUid();
					final String[] uids = CSession.getSessionItemUids();
					if(uids==null || uids.length<=0){
						m_objSet.clear();
						ebus.fireEvent(new RefreshAndSelectC7tDefineSubLocEvent(null));
						return;
					}
					CommUtils.loadObjects(uids, new AsyncCallback<Map<String, IModelObject>> (){
						@Override
						public void onFailure(Throwable caught) {
							CommMsg.log_warn("#Load Object Error", caught.getLocalizedMessage());
						}

						@Override
						public void onSuccess(Map<String, IModelObject> result) {
							List<IModelObject> list = new ArrayList<IModelObject>();
							for(String id : uids){
								IModelObject obj = result.get(id);
								if(null!=obj)
									list.add(obj);
							}
							m_objSet.clear();
							m_objSet.addAll(list);
							ebus.fireEvent(new RefreshAndSelectC7tDefineSubLocEvent(uid));
						}});
				}
	        } ));  	        
	        m_inited = true;
    	}

    }
    

    @Override
    public String getLabel()
    {
        return ChecklistMessages.INSTANCE.C7tDefineLocTitle();
    }

    @Override
    public String getHistoryNameToken()
    {
        return NameTokens.C7tDefineLoc_TOKEN;
    }

    @Override
    public String getSubLocationNameToken()
    {
        return NameTokens.C7tDefineLoc_SUB_LOCATION;
    }

    @Override
    public int getPriority()
    {
        return C7tDefineLocSubLocationPresenter.PRIORITY;
    }

    @Override
    public AsyncProvider<? extends ILocation> getLocation()
    {
        return AsyncProviderHelper.convertAsyncProvider( m_locationPresenter, ILocation.class );
    }

}
