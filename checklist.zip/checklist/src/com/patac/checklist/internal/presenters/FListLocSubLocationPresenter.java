// @<COPYRIGHT>@
// ==================================================
// Copyright 2018.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.presenters;

import com.google.gwt.inject.client.AsyncProvider;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.gwtplatform.mvp.client.annotations.NameToken;
import com.gwtplatform.mvp.client.annotations.ProxyCodeSplit;
import com.gwtplatform.mvp.client.proxy.ProxyPlace;
import com.siemens.splm.clientfx.ui.published.ILocation;
import com.siemens.splm.clientfx.ui.published.IPrimaryWorkArea;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractSubLocationPresenter;
import com.siemens.splm.clientfx.ui.published.utils.AsyncProviderHelper;

/**
 * FListLoc sub-location
 */
public class FListLocSubLocationPresenter
    extends AbstractSubLocationPresenter<AbstractSubLocationPresenter.MyView, FListLocSubLocationPresenter.MyProxy>
{
    /** Priority 0 will make this sub-location first. */
    public static final int PRIORITY = 0;

    /** Primary work area presenter for FListLoc. */
    @Inject
    private FListLocPrimaryWorkAreaPresenter m_primaryWorkAreaPresenter;

    /** CheckListMain Location Presenter. */
    @Inject
    private CheckListMainLocationPresenter m_locationPresenter;

    /**
     * Proxy of FListLocSubLocationPresenter
     */
    @ProxyCodeSplit
    @NameToken( NameTokens.FListLoc_TOKEN )
    public interface MyProxy
        extends ProxyPlace<FListLocSubLocationPresenter>
    {
        //
    }

    /**
     * Constructor
     *
     * @param eventBus Event Bus
     * @param view View
     * @param proxy Proxy
     */
    @Inject
    public FListLocSubLocationPresenter( EventBus eventBus, MyView view, MyProxy proxy )
    {
        super( eventBus, view, proxy );
    }

    @Override
    public String getLabel()
    {
        return ChecklistMessages.INSTANCE.FListLocTitle();
    }

    @Override
    public String getHistoryNameToken()
    {
        return NameTokens.FListLoc_TOKEN;
    }

    @Override
    public String getSubLocationNameToken()
    {
        return NameTokens.FListLoc_SUB_LOCATION;
    }

    @Override
    public int getPriority()
    {
        return FListLocSubLocationPresenter.PRIORITY;
    }

    @Override
    public AsyncProvider<? extends ILocation> getLocation()
    {
        return AsyncProviderHelper.convertAsyncProvider( m_locationPresenter, ILocation.class );
    }

    @Override
    public AsyncProvider<IPrimaryWorkArea> getPrimaryWorkArea()
    {
        return AsyncProviderHelper.convertAsyncProvider( m_primaryWorkAreaPresenter, IPrimaryWorkArea.class );
    }
}
