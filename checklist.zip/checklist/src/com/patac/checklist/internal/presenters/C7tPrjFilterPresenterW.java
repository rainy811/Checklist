// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.presenters;

import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.gwtplatform.mvp.client.HasUiHandlers;
import com.gwtplatform.mvp.client.View;
import com.patac.checklist.internal.uihandlers.C7tPrjFilterUiHandlers;
import com.patac.checklist.internal.uihandlers.C7tViewFilterUiHandlers;
import com.patac.checklist.internal.viewmodel.C7tPrjFilterViewModel;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.base.published.IMessageService;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.tcui.utils.published.ModelUtils;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractNavigationAreaPresenterWidget;

/**
 * Presenter widget for C7tViewFilter.
 */
public class C7tPrjFilterPresenterW
    extends AbstractNavigationAreaPresenterWidget<C7tPrjFilterPresenterW.MyView>
    implements C7tPrjFilterUiHandlers
{
    /**
     * View Model for C7tViewFilter.
     */
    @Inject
    private C7tPrjFilterViewModel m_viewModel;

    /** message service */
    @Inject
    private IMessageService m_messageService;
    
    /**
     * View interface
     */
    public interface MyView
        extends View, HasUiHandlers<C7tPrjFilterUiHandlers>
    {
        /**
         * Set object string
         * 
         * @param objectString The object string this will be presented in the title.
         */
        void setObjectString( String objectString );
    }

    /**
     * Constructor
     * 
     * @param eventBus The Event bus.
     * @param view The View for this presenter.
     */
    @Inject
    public C7tPrjFilterPresenterW( EventBus eventBus, MyView view )
    {
        super( eventBus, view );
        view.setUiHandlers( this );
    }

    @Override
    public String getTitle()
    {
        return ChecklistMessages.INSTANCE.SelectProject();
    }
    
    /**
     * This method sets the selected model object.
     * 
     * @param modelObject The selected model object.
     */
    public void setModelObject( IModelObject modelObject )
    {
        m_viewModel.setModelObject( modelObject );

        //Get the object string of the selected object.
        if( modelObject != null )
        {
            getView().setObjectString( ModelUtils.getDisplayName( modelObject ) );
        }
        else
        {
            getView().setObjectString( ChecklistMessages.INSTANCE.noSelection() );
        }
    }

    @Override
    public void completed()
    {
        //Notify the user that the operation is complete.
        m_messageService.notify( ChecklistMessages.INSTANCE.C7tViewFilterComplete() );

        //Close the panel.
        getSubLocation().setActiveToolsAndInfoCommand( null );
    }
}
