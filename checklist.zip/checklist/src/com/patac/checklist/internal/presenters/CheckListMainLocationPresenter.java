// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.presenters;

import com.cus.comm.published.utils.CommMsg;
import com.google.gwt.event.shared.GwtEvent.Type;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.google.web.bindery.event.shared.EventBus;
import com.gwtplatform.mvp.client.annotations.ContentSlot;
import com.gwtplatform.mvp.client.annotations.ProxyCodeSplit;
import com.gwtplatform.mvp.client.proxy.Proxy;
import com.gwtplatform.mvp.client.proxy.RevealContentHandler;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.ui.published.config.ISubLocationContribution;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractLocationPresenter;

import java.util.Set;

/**
 *  CheckListMain location presenter.
 */
public class CheckListMainLocationPresenter
    extends AbstractLocationPresenter<AbstractLocationPresenter.MyView, CheckListMainLocationPresenter.MyProxy>
{
    /**
     * Use this in leaf presenters, inside their {@link #revealInParent} method.
     */
    @ContentSlot
    public static final Type<RevealContentHandler<?>> TYPE_SubLocations_Content = new Type<>();

    /**
     * Proxy interface.
     */
    @ProxyCodeSplit
    public interface MyProxy
        extends Proxy<CheckListMainLocationPresenter>
    {
        //
    }

    /**
     * Constructor.
     *
     * @param eventBus Event bus
     * @param view View
     * @param proxy Proxy
     * @param subLocationContributions subLocation contributions
     */
    @Inject
    public CheckListMainLocationPresenter( EventBus eventBus, MyView view, MyProxy proxy,
            @Named( NameTokens.CheckListMain_LOCATION ) Set<ISubLocationContribution> subLocationContributions )
    {
        super( eventBus, view, proxy, subLocationContributions );
        setSubLocationContentSlot( CheckListMainLocationPresenter.TYPE_SubLocations_Content );
        setTitle( ChecklistMessages.INSTANCE.CheckListMainTitle() );
        setBrowserTitle( ChecklistMessages.INSTANCE.CheckListMainTitle() );
    }

    @Override
    protected void onReveal()
    {
        super.onReveal();
        setSearchVisible(false);
        setSimpleModel(true);
    }
    
    @Override
    public Type<RevealContentHandler<?>> getSubLocationContentSlot()
    {
        return CheckListMainLocationPresenter.TYPE_SubLocations_Content;
    }

    @Override
    public String getLocationNameToken()
    {
        return NameTokens.CheckListMain_LOCATION;
    }
}
