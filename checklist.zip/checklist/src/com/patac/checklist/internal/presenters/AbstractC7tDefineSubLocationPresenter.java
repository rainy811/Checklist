package com.patac.checklist.internal.presenters;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.cus.comm.published.i18n.CommMessages;
import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.web.bindery.event.shared.EventBus;
import com.google.web.bindery.event.shared.HandlerRegistration;
import com.gwtplatform.mvp.client.proxy.PlaceManager;
import com.gwtplatform.mvp.client.proxy.ProxyPlace;
import com.patac.checklist.internal.config.IChecklistInjector;
import com.patac.checklist.internal.event.handlers.LoadC7tDefineEvent;
import com.patac.checklist.internal.event.handlers.RefreshC7tDefineSubLocEvent;
import com.patac.checklist.internal.service.CSoaService;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.published.IPropertyName;
import com.siemens.splm.clientfx.kernel.published.ISession;
import com.siemens.splm.clientfx.kernel.published.ITypeName;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListPrimaryWorkAreaPresenterW;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListSubLocationPresenter;
import com.siemens.splm.clientfx.tcui.xrt.resources.i18n.XRTMessages;
import com.siemens.splm.clientfx.ui.published.ILocation;
import com.siemens.splm.clientfx.ui.published.ISubLocationService;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractSubLocationPresenter.MyView;

public abstract class AbstractC7tDefineSubLocationPresenter <V extends MyView, Proxy_ extends ProxyPlace<?>>
extends ModelObjectListSubLocationPresenter<V, Proxy_> {	
    protected Vector<HandlerRegistration> m_Handlers = new  Vector<HandlerRegistration>();
    
    protected String m_NameFilter = null;
    protected List<IModelObject> m_objSet = new ArrayList<IModelObject>();
  
	private C7tDefineSecondaryWorkAreaPresenter m_secondaryWorkAreaPresenter;


    /**
     * Constructor
     *
     * @param eventBus Event bus
     * @param view View
     * @param proxy Proxy
     * @param session Session
     * @param primaryWorkAreaPresenter Primary work area presenter
     * @param secondaryWorkAreaPresenter Secondary work area presenter
     * @param favoritesServices favorite services
     * @param historySvc history service
     */
    public AbstractC7tDefineSubLocationPresenter( EventBus eventBus, MyView view, Proxy_ proxy, ISession session,
            ModelObjectListPrimaryWorkAreaPresenterW primaryWorkAreaPresenter,
            C7tDefineSecondaryWorkAreaPresenter secondaryWorkAreaPresenter)
    {
        super( eventBus, view, proxy, primaryWorkAreaPresenter, secondaryWorkAreaPresenter );
        m_secondaryWorkAreaPresenter = secondaryWorkAreaPresenter;
    }

    @Override
    public AsyncProvider<? extends ILocation> getLocation()
    {
    	return  IChecklistInjector.INSTANCE.getCheckListMainLocationPresenter();
    }
    
    public ModelObjectListPrimaryWorkAreaPresenterW getPrimaryWorkAreaP(){
    	return getPrimaryWorkAreaPresenter();
    }

    @Override
    public void getModelObjectList( final AsyncCallback<List<IModelObject>> callback )
    {
    	//CommMsg.log_warn("#C7tDefineLocSubLocationPresenter", "#getModelObjectList="+m_objSet.size());
    	callback.onSuccess(m_objSet);    	
    }
    
    protected void onRevealSuper()
    {
    	super.onReveal();
    }
    
    @Override
    protected void onReveal()
    {
    	final EventBus eventbus = getEventBus();
    	if(m_Handlers.isEmpty()){
	    	m_Handlers.add( RefreshC7tDefineSubLocEvent.register(eventbus, new RefreshC7tDefineSubLocEvent.Handler()
	        {
				@Override
				public void doAction(RefreshC7tDefineSubLocEvent event) {
					AbstractC7tDefineSubLocationPresenter.super.onReveal();
					AbstractC7tDefineSubLocationPresenter.this.refresh();
				}
	        } )); 
	    	
	    	m_Handlers.add( LoadC7tDefineEvent.register(eventbus, new LoadC7tDefineEvent.Handler()
	        {
				@Override
				public void doAction(LoadC7tDefineEvent event) {
					CSoaService.findC7tDefine(event.getInputs(), CTypes.getCheckDefProps(), new AsyncCallback<List<IModelObject>>(){

						@Override
						public void onFailure(Throwable caught) {
							CommMsg.showMsg(ChecklistMessages.INSTANCE.txtSearchCriteriaErr());
							m_objSet.clear();
							eventbus.fireEvent(new RefreshC7tDefineSubLocEvent());
						}

						@Override
						public void onSuccess(List<IModelObject> result) {
							if(result==null){
								CommMsg.log_info("#Found", "#size=0");
								m_objSet.clear();
							}
							else{
								m_objSet.clear();
								m_objSet.addAll(result);								
							}
							eventbus.fireEvent(new RefreshC7tDefineSubLocEvent());
						}
						
					});
				}
	        } )); 
    	}
    	
    	eventbus.fireEvent(new LoadC7tDefineEvent());
    	super.onReveal();
    }
    
    @Override
	public void refreshWorkAreaTitle()
    {
        String workAreaTitle = m_objSet.size() == 0 ? CommMessages.INSTANCE.emptyListText()
                : XRTMessages.INSTANCE.dataCount( m_objSet.size() );

        // see if we need to prefix the count with multi-select info.
        workAreaTitle = getMultiSelectPrefix() + workAreaTitle;

        setWorkAreaTitle( workAreaTitle );
    }

    @Override
    public boolean isDragSupported()
    {
        return true;
    }
    
    protected List<String> getTableViewPropertiesTypeNames()
    {
        if( m_propPolicy != null )
        {
            return m_propPolicy.getPropertyTypes();
        }

        List<String> typeNames = new ArrayList<>();
        typeNames.add( ITypeName.WorkspaceObject );
        for(String attr : CTypes.getCheckDefProps2()){
        	typeNames.add( CTypes.C7t_CheckDef );
        }
        //typeNames.add( ITypeName.ItemRevision );
        typeNames.add( ITypeName.WorkspaceObject );
        typeNames.add( ITypeName.WorkspaceObject );
        typeNames.add( ITypeName.WorkspaceObject );

        return typeNames;

    }

    /**
     * List of properties to show in the table view. This list has the property names for those properties.
     *
     * @return the property name list
     */
    protected List<String> getTableViewPropertiesPropertyNames()
    {
        if( m_propPolicy != null )
        {
            return m_propPolicy.getPropertyNames();
        }
        List<String> propertyNames = new ArrayList<>();
        propertyNames.add( IPropertyName.OBJECT_STRING );
        propertyNames.addAll(CTypes.getCheckDefProps2());
        propertyNames.add( IPropertyName.LAST_MOD_DATE );
        propertyNames.add( IPropertyName.CREATION_DATE );
        propertyNames.add( IPropertyName.OWNING_USER );

        return propertyNames;
    }
    
}
