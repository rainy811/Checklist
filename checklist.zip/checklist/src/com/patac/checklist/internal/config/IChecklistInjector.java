// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.config;

import com.patac.checklist.internal.presenters.C7tPrjLocSubLocationPresenter;
import com.patac.checklist.internal.presenters.C7tViewLocSubLocationPresenter;
import com.patac.checklist.internal.presenters.C7tDefineLocSubLocationPresenter;
import com.google.gwt.inject.client.AsyncProvider;
import com.patac.checklist.internal.presenters.CheckListMainLocationPresenter;
import com.patac.checklist.internal.presenters.DListLocSubLocationPresenter;
import com.patac.checklist.internal.presenters.FListLocSubLocationPresenter;
import com.google.gwt.core.client.GWT;
import com.google.gwt.inject.client.GinModules;
import com.siemens.splm.clientfx.base.extensions.published.IModuleInjector;
import com.patac.checklist.internal.config.ChecklistModule;

/**
 * access functions to injected types.  This is limited to the module level access as 
 * we are in the internal namespace.
 */
@GinModules( ChecklistModule.class )
public interface IChecklistInjector
    extends IModuleInjector
{
    /** Injector instance */
    IChecklistInjector INSTANCE = GWT.create( IChecklistInjector.class );

    /**
     * Return CheckListMain Location presenter
     * @return CheckListMain location presenter
     */
    AsyncProvider<CheckListMainLocationPresenter> getCheckListMainLocationPresenter();

    /**
     * Return C7tDefineLoc presenter
     * @return C7tDefineLoc presenter
     */
    AsyncProvider<C7tDefineLocSubLocationPresenter> getC7tDefineLocSubLocationPresenter();

    /**
     * Return C7tViewLoc presenter
     * @return C7tViewLoc presenter
     */
    AsyncProvider<C7tViewLocSubLocationPresenter> getC7tViewLocSubLocationPresenter();
    
    AsyncProvider<C7tPrjLocSubLocationPresenter> getC7tPrjLocSubLocationPresenter();
    /**
     * Return DListLoc presenter
     * @return DListLoc presenter
     */
    AsyncProvider<DListLocSubLocationPresenter> getDListLocSubLocationPresenter();

    /**
     * Return FListLoc presenter
     * @return FListLoc presenter
     */
    AsyncProvider<FListLocSubLocationPresenter> getFListLocSubLocationPresenter();
}
