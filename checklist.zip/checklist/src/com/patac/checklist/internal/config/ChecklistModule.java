// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.config;

import com.cus.comm.published.presenters.NoSelectPresenterW;
import com.cus.comm.published.utils.CommService;
import com.cus.comm.published.utils.ICommService;
import com.cus.comm.published.view.NoSelectionView;
import com.cus.comm.tcui.attachments.AddAttachmentsPresenter;
import com.cus.comm.tcui.attachments.AddAttachmentsView;
import com.cus.comm.tcui.attachments.AttachmentsPresenterW;
import com.cus.comm.tcui.attachments.AttachmentsView;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.google.inject.TypeLiteral;
import com.gwtplatform.mvp.client.gin.AbstractPresenterModule;
import com.patac.checklist.internal.DebugIdConstants;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.commands.crecheckdef.CreCheckDefCommandDisplay;
import com.patac.checklist.internal.commands.crecheckdef.CreCheckDefCommandHandler;
import com.patac.checklist.internal.commands.crecheckdef.CreCheckDefPresenterW;
import com.patac.checklist.internal.commands.crecheckdef.CreCheckDefView;
import com.patac.checklist.internal.commands.dListLocButton.DGreenCheckCommandDisplay;
import com.patac.checklist.internal.commands.dListLocButton.DGreenCommandHandler;
import com.patac.checklist.internal.commands.dListLocButton.DRedCheckCommandDisplay;
import com.patac.checklist.internal.commands.dListLocButton.DRedCheckCommandHandler;
import com.patac.checklist.internal.commands.dListLocButton.DSaveCommandDisplay;
import com.patac.checklist.internal.commands.dListLocButton.DSaveCommandHandler;
import com.patac.checklist.internal.commands.dListLocButton.DSubmitCommandDisplay;
import com.patac.checklist.internal.commands.dListLocButton.DSubmitCommandHandler;
import com.patac.checklist.internal.commands.dListLocButton.DTaskListCommandDisplay;
import com.patac.checklist.internal.commands.dListLocButton.DTaskListCommandHandler;
import com.patac.checklist.internal.commands.dListLocButton.DYellowCheckCommandDisplay;
import com.patac.checklist.internal.commands.dListLocButton.DYellowCheckCommandHandler;
import com.patac.checklist.internal.commands.fListLocButton.FGreenCheckCommandDisplay;
import com.patac.checklist.internal.commands.fListLocButton.FGreenCommandHandler;
import com.patac.checklist.internal.commands.fListLocButton.FRedCheckCommandDisplay;
import com.patac.checklist.internal.commands.fListLocButton.FRedCheckCommandHandler;
import com.patac.checklist.internal.commands.fListLocButton.FTaskListCommandDisplay;
import com.patac.checklist.internal.commands.fListLocButton.FTaskListCommandHandler;
import com.patac.checklist.internal.commands.fListLocButton.FYellowCheckCommandDisplay;
import com.patac.checklist.internal.commands.fListLocButton.FYellowCheckCommandHandler;
import com.patac.checklist.internal.commands.fListLocButton.FCheckButtonDisplay;
import com.patac.checklist.internal.commands.fListLocButton.FCheckButtonHandler;
import com.patac.checklist.internal.commands.filtercheckdef.C7tDefineFilterCommandDisplay;
import com.patac.checklist.internal.commands.filtercheckdef.C7tDefineFilterCommandHandler;
import com.patac.checklist.internal.commands.filtercheckdef.C7tDefineFilterView;
import com.patac.checklist.internal.commands.filtercheckview.C7tViewFilterCommandDisplay;
import com.patac.checklist.internal.commands.filtercheckview.C7tViewFilterCommandHandler;
import com.patac.checklist.internal.commands.filtercheckview.C7tViewFilterView;
import com.patac.checklist.internal.commands.filtercheckview.ShowMyItemCommandDisplay;
import com.patac.checklist.internal.commands.filtercheckview.ShowMyItemCommandHandler;
import com.patac.checklist.internal.commands.filterprj.C7tPrjFilterCommandDisplay;
import com.patac.checklist.internal.commands.filterprj.C7tPrjFilterCommandHandler;
import com.patac.checklist.internal.commands.filterprj.C7tPrjFilterView;
import com.patac.checklist.internal.commands.latestcheckdef.ShowLatestItemCommandDisplay;
import com.patac.checklist.internal.commands.latestcheckdef.ShowLatestItemCommandHandler;
import com.patac.checklist.internal.commands.release.ReleaseCommandDisplay;
import com.patac.checklist.internal.commands.release.ReleaseCommandHandler;
import com.patac.checklist.internal.commands.release.UnReleaseCommandDisplay;
import com.patac.checklist.internal.commands.release.UnReleaseCommandHandler;
import com.patac.checklist.internal.commands.viewmode.ViewModeTableCommandDisplay;
import com.patac.checklist.internal.commands.viewmode.ViewModeTableCommandHandler;
import com.patac.checklist.internal.commands.viewmode.ViewModeTableSumCommandDisplay;
import com.patac.checklist.internal.commands.viewmode.ViewModeTableSumCommandHandler;
import com.patac.checklist.internal.commands.viewmode.ViewModeTokens;
import com.patac.checklist.internal.presenters.C7tDefineFilterPresenterW;
import com.patac.checklist.internal.presenters.C7tDefineLocSubLocationPresenter;
import com.patac.checklist.internal.presenters.C7tDefineSecondaryWorkAreaPresenter;
import com.patac.checklist.internal.presenters.C7tPrjFilterPresenterW;
import com.patac.checklist.internal.presenters.C7tPrjLocSubLocationPresenter;
import com.patac.checklist.internal.presenters.C7tViewFilterPresenterW;
import com.patac.checklist.internal.presenters.C7tViewLocSubLocationPresenter;
import com.patac.checklist.internal.presenters.CheckListMainLocationPresenter;
import com.patac.checklist.internal.presenters.DListLocPrimaryWorkAreaPresenter;
import com.patac.checklist.internal.presenters.DListLocSubLocationPresenter;
import com.patac.checklist.internal.presenters.FListLocPrimaryWorkAreaPresenter;
import com.patac.checklist.internal.presenters.FListLocSubLocationPresenter;
import com.patac.checklist.internal.typeicons.ChecklistModuleRegistry;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.vehicle.PropVehiclePresenterW;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.vehicle.PropVehicleView;
import com.patac.checklist.internal.views.DListLocPrimaryWorkAreaView;
import com.patac.checklist.internal.views.FListLocPrimaryWorkAreaView;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.clsprops.PropLovsPresenterW;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.clsprops.PropLovsView;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.devlevel.PropDevLvlPresenterW;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.devlevel.PropDevLvlView;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.importance.PropImportancePresenterW;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.importance.PropImportanceView;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.picview.PropPicView;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.picview.PropPicviewPresenterW;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.projectRole.PropProjectRolePresenterW;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.projectRole.PropProjectRoleView;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.statepick.PropStatePickPresenterW;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.statepick.PropStatePickView;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.territory.PropTerriPresenterW;
import com.patac.checklist.internal.ui.common.widgets.cuspanel.territory.PropTerriView;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.tcui.typeicons.published.TypeIconExtensionPointHelper;
import com.siemens.splm.clientfx.tcui.xrt.published.commands.TcUIXRTCommands;
import com.siemens.splm.clientfx.ui.commands.published.CommandId;
import com.siemens.splm.clientfx.ui.commands.published.CommandsExtensionPointHelper;
import com.siemens.splm.clientfx.ui.published.config.DefaultSubLocationContribution;
import com.siemens.splm.clientfx.ui.published.config.SubLocationExtensionPointHelper;
import com.siemens.splm.clientfx.xrt.published.XRTHtmlPanelExtensionPointHelper;

/**
 * Module Checklist.
 */
public class ChecklistModule
    extends AbstractPresenterModule
{
    @Override
    protected void configure()
    {
    	//CommServiceExtensionPointHelper.contributeFavoritesService( binder(), CommService.class );
    	bind(ICommService.class).to(CommService.class);
    	TypeIconExtensionPointHelper.contributeTypeIconModuleRegistry( binder(),ChecklistModuleRegistry.class );
    	bindPresenterWidget( NoSelectPresenterW.class, NoSelectPresenterW.MyView.class, NoSelectionView.class );
    	bindPresenterWidget( AttachmentsPresenterW.class, AttachmentsPresenterW.MyView.class, AttachmentsView.class );
        bindPresenterWidget( AddAttachmentsPresenter.class, AddAttachmentsPresenter.MyView.class, AddAttachmentsView.class );
        
        CommandsExtensionPointHelper.registerCommandHandler( binder(), ViewModeTokens.TABLE_MODE, ViewModeTokens.TABLE_MODE, ViewModeTableCommandHandler.class, ViewModeTableCommandDisplay.class );
        CommandsExtensionPointHelper.registerCommandHandler( binder(), ViewModeTokens.TABLE_SUM_MODE, ViewModeTokens.TABLE_SUM_MODE, ViewModeTableSumCommandHandler.class, ViewModeTableSumCommandDisplay.class );

    	//main loc
        bindPresenter( CheckListMainLocationPresenter.class, CheckListMainLocationPresenter.MyProxy.class );
        SubLocationExtensionPointHelper.declareSubLocationExtensionPoint( binder(), NameTokens.CheckListMain_LOCATION );
/*        
        //sub loc
        bindPresenter( C7tViewLocSubLocationPresenter.class, C7tViewLocSubLocationPresenter.MyProxy.class );
        SubLocationExtensionPointHelper.contributeSubLocation( binder(),  NameTokens.CheckListMain_LOCATION, C7tViewLocSubLocationContribution.class);
*/
        //sub loc
        bindPresenter( C7tDefineLocSubLocationPresenter.class, C7tDefineLocSubLocationPresenter.MyProxy.class );        
        bind( C7tDefineSecondaryWorkAreaPresenter.class );
        SubLocationExtensionPointHelper.contributeSubLocation( binder(),  NameTokens.CheckListMain_LOCATION, C7tDefineSubLocationContribution.class);
        
        //sub loc
//        bindPresenter( C7tPrjLocSubLocationPresenter.class, C7tPrjLocSubLocationPresenter.MyProxy.class );
//        SubLocationExtensionPointHelper.contributeSubLocation( binder(),  NameTokens.CheckListMain_LOCATION, C7tProjLocSubLocationContribution.class);
        
        //sub loc
        bindPresenter( DListLocSubLocationPresenter.class, DListLocSubLocationPresenter.MyProxy.class );
        SubLocationExtensionPointHelper.contributeSubLocation( binder(),  NameTokens.CheckListMain_LOCATION, C7tDListLocSubLocationContribution.class);
        bindSingletonPresenterWidget( DListLocPrimaryWorkAreaPresenter.class,DListLocPrimaryWorkAreaPresenter.MyView.class, DListLocPrimaryWorkAreaView.class );
        
        //sub loc
        bindPresenter( FListLocSubLocationPresenter.class, FListLocSubLocationPresenter.MyProxy.class );
        SubLocationExtensionPointHelper.contributeSubLocation( binder(),  NameTokens.CheckListMain_LOCATION, C7tFListLocSubLocationContribution.class);
        bindSingletonPresenterWidget( FListLocPrimaryWorkAreaPresenter.class,FListLocPrimaryWorkAreaPresenter.MyView.class, FListLocPrimaryWorkAreaView.class );
        
        CommandsExtensionPointHelper.contributeCommandToArea( binder(),
                NameTokens.C7tViewLoc_SUB_LOCATION,
                com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS,
                TcUIXRTCommands.ModelObjectListDisplayTogglesCommandIdProvider.class, 100 );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(),
                NameTokens.C7tDefineLoc_SUB_LOCATION,
                com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS,
                TcUIXRTCommands.ModelObjectListDisplayTogglesCommandIdProvider.class, 101 );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(),
                NameTokens.C7tProjLoc_SUB_LOCATION,
                com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS,
                TcUIXRTCommands.ModelObjectListDisplayTogglesCommandIdProvider.class, 102 );
        
        // Add configuration here.
        bindSingletonPresenterWidget( C7tDefineFilterPresenterW.class, C7tDefineFilterPresenterW.MyView.class, C7tDefineFilterView.class );
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_C7tDefineFilter, NameTokens.CMD_C7tDefineFilter, C7tDefineFilterCommandHandler.class, C7tDefineFilterCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tDefineFilterCommandIdProvider.class, 1000 );//$NON-NLS-1$
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.FOOTER_COMMANDS, ChecklistModule.C7tDefineFilterCommandIdProvider.class, 18500 );//$NON-NLS-1$
       
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_LatestC7tDefine, NameTokens.CMD_LatestC7tDefine, ShowLatestItemCommandHandler.class, ShowLatestItemCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tDefineLatestCommandIdProvider.class, 1050 );//$NON-NLS-1$
        
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_MyC7tDefine, NameTokens.CMD_MyC7tDefine, ShowMyItemCommandHandler.class, ShowMyItemCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tDefineMyCommandIdProvider.class, 1100 );//$NON-NLS-1$
        
        // save and submit button
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_SaveButton, NameTokens.CMD_SaveButton, DSaveCommandHandler.class, DSaveCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.DListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.C7tDSaveCommandIdProvider.class, 10000 );//$NON-NLS-1$
        
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_SubmitButton, NameTokens.CMD_SubmitButton, DSubmitCommandHandler.class, DSubmitCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.DListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.C7tDSubmitCommandIdProvider.class, 10000 );//$NON-NLS-1$
        
        //publish button
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_publishButton, NameTokens.CMD_publishButton, FCheckButtonHandler.class, FCheckButtonDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.FListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.PublishButtonCommandIdProvider.class, 10000 );//$NON-NLS-1$
        
        
        /*-----------------Releace and Unrelease-----------------*/
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_C7tDefineRelease, NameTokens.CMD_C7tDefineRelease, ReleaseCommandHandler.class, ReleaseCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.C7tDefineReleaseCommandIdProvider.class, 1000 );//$NON-NLS-1$
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_C7tDefineUnRelease, NameTokens.CMD_C7tDefineUnRelease, UnReleaseCommandHandler.class, UnReleaseCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.C7tDefineUnReleaseCommandIdProvider.class, 1000 );//$NON-NLS-1$
        
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), com.siemens.splm.clientfx.tcui.xrt.published.NameTokens.showObjectSubLocation, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.C7tDefineReleaseCommandIdProvider.class, 1000 );//$NON-NLS-1$
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), com.siemens.splm.clientfx.tcui.xrt.published.NameTokens.showObjectSubLocation, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.C7tDefineUnReleaseCommandIdProvider.class, 1000 );//$NON-NLS-1$ 
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), com.siemens.splm.clientfx.tcui.xrt.published.NameTokens.objectNavigationSubLocation, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.C7tDefineReleaseCommandIdProvider.class, 1000 );//$NON-NLS-1$
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), com.siemens.splm.clientfx.tcui.xrt.published.NameTokens.objectNavigationSubLocation, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.ONE_STEP_COMMANDS, ChecklistModule.C7tDefineUnReleaseCommandIdProvider.class, 1000 );//$NON-NLS-1$ 
   
        //C7tSetTableModeCommandIdProvider
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_VIEW_MODET, NameTokens.CMD_VIEW_MODET, ViewModeTableCommandHandler.class, ViewModeTableCommandDisplay.class );
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_VIEW_MODELS, NameTokens.CMD_VIEW_MODELS, ViewModeTableCommandHandler.class, ViewModeTableCommandDisplay.class );
        
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS, ChecklistModule.C7tSetTableModeCommandIdProvider.class, 150 );//$NON-NLS-1$
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS, ChecklistModule.C7tSetTableSumModeCommandIdProvider.class, 150 );//$NON-NLS-1$
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.DListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS, ChecklistModule.C7tSetTableModeCommandIdProvider.class, 150 );//$NON-NLS-1$
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.DListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS, ChecklistModule.C7tSetTableSumModeCommandIdProvider.class, 150 );//$NON-NLS-1$
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.FListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS, ChecklistModule.C7tSetTableModeCommandIdProvider.class, 150 );//$NON-NLS-1$
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.FListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.DISPLAY_COMMANDS, ChecklistModule.C7tSetTableSumModeCommandIdProvider.class, 150 );//$NON-NLS-1$

        
        
        /*-----------------Left Button in DListLoc_SUB_LOCATION--------------------------*/
        /*-----------------Task List ---------------------------*/
        CommandsExtensionPointHelper.registerCommandHandler(binder(), NameTokens.CMD_C7tDTaskList, NameTokens.CMD_C7tDTaskList,DTaskListCommandHandler.class, DTaskListCommandDisplay.class);
        CommandsExtensionPointHelper.contributeCommandToArea(binder(), NameTokens.DListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tDTaskListCommandIdprovider.class, 1010);

        /*-----------------Red Check---------------------------*/
        CommandsExtensionPointHelper.registerCommandHandler(binder(), NameTokens.CMD_C7tDRedCheck, NameTokens.CMD_C7tDRedCheck,DRedCheckCommandHandler.class, DRedCheckCommandDisplay.class);
        CommandsExtensionPointHelper.contributeCommandToArea(binder(), NameTokens.DListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tDRedCommandIdprovider.class, 1020);
        /*-----------------Yellow Check---------------------------*/
        CommandsExtensionPointHelper.registerCommandHandler(binder(), NameTokens.CMD_C7tDYellowCheck, NameTokens.CMD_C7tDYellowCheck,DYellowCheckCommandHandler.class, DYellowCheckCommandDisplay.class);
        CommandsExtensionPointHelper.contributeCommandToArea(binder(), NameTokens.DListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tDYellowCommandIdprovider.class, 1030);
        
        /*-----------------Green Check---------------------------*/
        CommandsExtensionPointHelper.registerCommandHandler(binder(), NameTokens.CMD_C7tDGreenCheck, NameTokens.CMD_C7tDGreenCheck,DGreenCommandHandler.class, DGreenCheckCommandDisplay.class);
        CommandsExtensionPointHelper.contributeCommandToArea(binder(), NameTokens.DListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tDGreenCommandIdprovider.class, 1040);
       
        /*-----------------Left Button in FListLoc_SUB_LOCATION--------------------------*/
        /*-----------------Task List ---------------------------*/
        CommandsExtensionPointHelper.registerCommandHandler(binder(), NameTokens.CMD_C7tFTaskList, NameTokens.CMD_C7tFTaskList,FTaskListCommandHandler.class, FTaskListCommandDisplay.class);
        CommandsExtensionPointHelper.contributeCommandToArea(binder(), NameTokens.FListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tFTaskListCommandIdprovider.class, 1010);

        /*-----------------Red Check---------------------------*/
        CommandsExtensionPointHelper.registerCommandHandler(binder(), NameTokens.CMD_C7tFRedCheck, NameTokens.CMD_C7tFRedCheck,FRedCheckCommandHandler.class, FRedCheckCommandDisplay.class);
        CommandsExtensionPointHelper.contributeCommandToArea(binder(), NameTokens.FListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tFRedCommandIdprovider.class, 1020);
        /*-----------------Yellow Check---------------------------*/
        CommandsExtensionPointHelper.registerCommandHandler(binder(), NameTokens.CMD_C7tFYellowCheck, NameTokens.CMD_C7tFYellowCheck,FYellowCheckCommandHandler.class, FYellowCheckCommandDisplay.class);
        CommandsExtensionPointHelper.contributeCommandToArea(binder(), NameTokens.FListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tFYellowCommandIdprovider.class, 1030);
        
        /*-----------------Green Check---------------------------*/
        CommandsExtensionPointHelper.registerCommandHandler(binder(), NameTokens.CMD_C7tFGreenCheck, NameTokens.CMD_C7tFGreenCheck,FGreenCommandHandler.class, FGreenCheckCommandDisplay.class);
        CommandsExtensionPointHelper.contributeCommandToArea(binder(), NameTokens.FListLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tFGreenCommandIdprovider.class, 1040);
        
        // Add configuration here.
        bindSingletonPresenterWidget( C7tViewFilterPresenterW.class, C7tViewFilterPresenterW.MyView.class, C7tViewFilterView.class );
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_C7tViewFilter, NameTokens.CMD_C7tViewFilter, C7tViewFilterCommandHandler.class, C7tViewFilterCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tViewLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tViewFilterCommandIdProvider.class, 1000 );//$NON-NLS-1$    
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tViewLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.FOOTER_COMMANDS, ChecklistModule.C7tViewFilterCommandIdProvider.class, 18500 );//$NON-NLS-1$    

        bindSingletonPresenterWidget( C7tPrjFilterPresenterW.class, C7tPrjFilterPresenterW.MyView.class, C7tPrjFilterView.class );
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_C7tProjFilter, NameTokens.CMD_C7tProjFilter, C7tPrjFilterCommandHandler.class, C7tPrjFilterCommandDisplay.class );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tProjLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.NAVIGATION_COMMANDS, ChecklistModule.C7tProjFilterCommandIdProvider.class, 1010 );//$NON-NLS-1$    
        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tProjLoc_SUB_LOCATION, 
        		com.siemens.splm.clientfx.ui.published.NameTokens.FOOTER_COMMANDS, ChecklistModule.C7tProjFilterCommandIdProvider.class, 18510 );//$NON-NLS-1$    

        
        // Add configuration here.
        bindSingletonPresenterWidget( CreCheckDefPresenterW.class, CreCheckDefPresenterW.MyView.class, CreCheckDefView.class );
        CommandsExtensionPointHelper.registerCommandHandler( binder(), NameTokens.CMD_CreCheckDef,NameTokens.CMD_CreCheckDef, CreCheckDefCommandHandler.class, CreCheckDefCommandDisplay.class );
//        CommandsExtensionPointHelper.contributeCommandToArea( binder(), NameTokens.C7tDefineLoc_SUB_LOCATION,
//        		com.siemens.splm.clientfx.ui.published.NameTokens.TOOLS_AND_INFO_COMMANDS,ChecklistModule.CreCheckDefCommandIdProvider.class, 1100 );
        CommandsExtensionPointHelper.contributeCommandToArea( binder(),
                com.siemens.splm.clientfx.ui.published.NameTokens.GLOBAL_COMMANDS,
                com.siemens.splm.clientfx.ui.published.NameTokens.TOOLS_AND_INFO_COMMANDS,ChecklistModule.CreCheckDefCommandIdProvider.class, 1100 );
        
        bindPanels();
    }
    
    private void bindPanels() {

    	XRTHtmlPanelExtensionPointHelper.bindXRTHtmlPanel( binder(), NameTokens.XRT_C7t_PIC_PANEL,
                new TypeLiteral<AsyncProvider<PropPicviewPresenterW>>()
                {
                    //
                } );
    	bindPresenterWidget(PropPicviewPresenterW.class, PropPicviewPresenterW.MyView.class, PropPicView.class); 
    	
    	XRTHtmlPanelExtensionPointHelper.bindXRTHtmlPanel( binder(), NameTokens.XRT_C7t_LOV_PANEL,
                new TypeLiteral<AsyncProvider<PropLovsPresenterW>>()
                {
                    //
                } );
    	bindPresenterWidget(PropLovsPresenterW.class, PropLovsPresenterW.MyView.class, PropLovsView.class);  		

    	XRTHtmlPanelExtensionPointHelper.bindXRTHtmlPanel( binder(), NameTokens.XRT_C7t_TERRI_PANEL,
                new TypeLiteral<AsyncProvider<PropTerriPresenterW>>()
                {
                    //
                } );
    	bindPresenterWidget(PropTerriPresenterW.class, PropTerriPresenterW.MyView.class, PropTerriView.class);  	
 
    	/*--------------------------------------------------------------------------------*/
    	XRTHtmlPanelExtensionPointHelper.bindXRTHtmlPanel( binder(), NameTokens.XRT_C7t_DEVLVL_PANEL,
                new TypeLiteral<AsyncProvider<PropDevLvlPresenterW>>()
                {
                    //
                } );
    	bindPresenterWidget(PropDevLvlPresenterW.class, PropDevLvlPresenterW.MyView.class, PropDevLvlView.class);  
    	
    	XRTHtmlPanelExtensionPointHelper.bindXRTHtmlPanel( binder(), NameTokens.XRT_C7t_VEHICLE_PANEL,
                new TypeLiteral<AsyncProvider<PropVehiclePresenterW>>()
                {
                    //
                } );
    	bindPresenterWidget(PropVehiclePresenterW.class, PropVehiclePresenterW.MyView.class, PropVehicleView.class);  
    	
    	XRTHtmlPanelExtensionPointHelper.bindXRTHtmlPanel( binder(), NameTokens.XRT_C7t_IMPORTANCE_PANEL,
                new TypeLiteral<AsyncProvider<PropImportancePresenterW>>()
                {
                    //
                } );
    	bindPresenterWidget(PropImportancePresenterW.class, PropImportancePresenterW.MyView.class, PropImportanceView.class); 
    	
    	XRTHtmlPanelExtensionPointHelper.bindXRTHtmlPanel( binder(), NameTokens.XRT_C7t_PROJECTROLE_PANEL,
                new TypeLiteral<AsyncProvider<PropProjectRolePresenterW>>()
                {
                    //
                } );
    	bindPresenterWidget(PropProjectRolePresenterW.class, PropProjectRolePresenterW.MyView.class, PropProjectRoleView.class);
    	/*--------------------------------------------------------------------------------*/
    	
    	XRTHtmlPanelExtensionPointHelper.bindXRTHtmlPanel( binder(), NameTokens.XRT_C7t_STATEPICK_PANEL,
                new TypeLiteral<AsyncProvider<PropStatePickPresenterW>>()
                {
                    //
                } );
    	bindPresenterWidget(PropStatePickPresenterW.class, PropStatePickPresenterW.MyView.class, PropStatePickView.class);  	
    }
    
	public static class  C7tDefineSubLocationContribution extends DefaultSubLocationContribution{
    	@Inject
		public C7tDefineSubLocationContribution(	AsyncProvider<C7tDefineLocSubLocationPresenter> subLocation) {
    		super( C7tDefineLocSubLocationPresenter.PRIORITY, ChecklistMessages.INSTANCE.C7tDefineLocTitle(),
                    NameTokens.C7tDefineLoc_TOKEN, subLocation,  DebugIdConstants.SUB_LOCATION_COMMAND );
		}
    }
    
    public static class  C7tViewLocSubLocationContribution extends DefaultSubLocationContribution{
    	@Inject
		public C7tViewLocSubLocationContribution(	AsyncProvider<C7tViewLocSubLocationPresenter> subLocation) {
    		super( C7tViewLocSubLocationPresenter.PRIORITY, ChecklistMessages.INSTANCE.C7tViewLocTitle(),
                    NameTokens.C7tViewLoc_TOKEN, subLocation,  DebugIdConstants.SUB_LOCATION_COMMAND );
		}
    }
    

    public static class  C7tDListLocSubLocationContribution extends DefaultSubLocationContribution{
    	@Inject
		public C7tDListLocSubLocationContribution(	AsyncProvider<C7tPrjLocSubLocationPresenter> subLocation) {
    		super( DListLocSubLocationPresenter.PRIORITY, ChecklistMessages.INSTANCE.DListLocTitle(),
                    NameTokens.DListLoc_TOKEN, subLocation,  DebugIdConstants.SUB_LOCATION_COMMAND );
		}
    }    

    public static class  C7tFListLocSubLocationContribution extends DefaultSubLocationContribution{
    	@Inject
		public C7tFListLocSubLocationContribution(	AsyncProvider<C7tPrjLocSubLocationPresenter> subLocation) {
    		super( FListLocSubLocationPresenter.PRIORITY, ChecklistMessages.INSTANCE.FListLocTitle(),
                    NameTokens.FListLoc_TOKEN, subLocation,  DebugIdConstants.SUB_LOCATION_COMMAND );
		}
    }       
    
    
    public static class  C7tProjLocSubLocationContribution extends DefaultSubLocationContribution{
    	@Inject
		public C7tProjLocSubLocationContribution(	AsyncProvider<C7tPrjLocSubLocationPresenter> subLocation) {
    		super( C7tPrjLocSubLocationPresenter.PRIORITY, ChecklistMessages.INSTANCE.C7tProjLocTitle(),
                    NameTokens.C7tProjLoc_TOKEN, subLocation,  DebugIdConstants.SUB_LOCATION_COMMAND );
		}
    }
    public static class C7tSetTableModeCommandIdProvider
    	implements Provider<CommandId>
	  {
	      @Override
	      public CommandId get()
	      {
	          return new CommandId( ViewModeTokens.TABLE_MODE );
	      }
	  }

    public static class C7tSetTableSumModeCommandIdProvider
	implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( ViewModeTokens.TABLE_SUM_MODE );
      }
  }
    
    /**
     * CommandID provider for C7tDefineFilter Command
     */
    public static class C7tDefineFilterCommandIdProvider
      implements Provider<CommandId>
    {
        @Override
        public CommandId get()
        {
            return new CommandId( NameTokens.CMD_C7tDefineFilter );
        }
    }
    
    public static class C7tDefineLatestCommandIdProvider
      implements Provider<CommandId>
    {
        @Override
        public CommandId get()
        {
            return new CommandId( NameTokens.CMD_LatestC7tDefine );
        }
    }
    public static class C7tDefineMyCommandIdProvider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_MyC7tDefine );
      }
  }
    public static class PublishButtonCommandIdProvider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_publishButton );
      }
  }
  
    /**
     *  Left Buttons
     */
    public static class C7tDTaskListCommandIdprovider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_C7tDTaskList);
      }
  }
    
    public static class C7tDRedCommandIdprovider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_C7tDRedCheck);
      }
  }
    
    public static class C7tDYellowCommandIdprovider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_C7tDYellowCheck);
      }
  }
    
    public static class C7tDGreenCommandIdprovider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_C7tDGreenCheck);
      }
  }
    
    /**
     *  Left Buttons
     */
    public static class C7tFTaskListCommandIdprovider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_C7tFTaskList);
      }
  }
    
    public static class C7tFRedCommandIdprovider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_C7tFRedCheck);
      }
  }
    
    public static class C7tFYellowCommandIdprovider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_C7tFYellowCheck);
      }
  }
    
    public static class C7tFGreenCommandIdprovider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_C7tFGreenCheck);
      }
  }
    /**
     * CommandID provider for C7tDefineFilter Command
     */
    public static class C7tDefineReleaseCommandIdProvider
      implements Provider<CommandId>
    {
        @Override
        public CommandId get()
        {
            return new CommandId( NameTokens.CMD_C7tDefineRelease );
        }
    }
    
    public static class C7tDefineUnReleaseCommandIdProvider
      implements Provider<CommandId>
    {
        @Override
        public CommandId get()
        {
            return new CommandId( NameTokens.CMD_C7tDefineUnRelease);
        }
    }
    /**
     * CommandID provider for C7tDefineFilter Command
     */
    public static class C7tDSubmitCommandIdProvider
      implements Provider<CommandId>
    {
        @Override
        public CommandId get()
        {
            return new CommandId( NameTokens.CMD_SubmitButton );
        }
    }
    
    public static class C7tDSaveCommandIdProvider
    implements Provider<CommandId>
  {
      @Override
      public CommandId get()
      {
          return new CommandId( NameTokens.CMD_SaveButton );
      }
  }
    
    /**
     * CommandID provider for C7tViewFilter Command
     */
    public static class C7tViewFilterCommandIdProvider
      implements Provider<CommandId>
    {
        @Override
        public CommandId get()
        {
            return new CommandId( NameTokens.CMD_C7tViewFilter );
        }
    }
    
    public static class C7tProjFilterCommandIdProvider
      implements Provider<CommandId>
    {
        @Override
        public CommandId get()
        {
            return new CommandId( NameTokens.CMD_C7tProjFilter );
        }
    }
    /**
     * CommandID provider for CreCheckDef Command
     */
    public static class CreCheckDefCommandIdProvider
        implements Provider<CommandId>
    {
        @Override
        public CommandId get()
        {
            return new CommandId( NameTokens.CMD_CreCheckDef );
        }
    }

}
