// @<COPYRIGHT>@
// ==================================================
// Copyright 2014.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.config;

import com.cus.comm.published.utils.ICommService;
import com.google.gwt.inject.client.binder.GinBinder;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility;
import com.siemens.splm.clientfx.base.extensions.published.ExtensionsGinHelper;

/**
 * Helper class to declare and contribute FavoritesService extension point
 */
@ApiVisibility( maturity = ApiVisibility.MaturityEnum.Experimental, publishScope = ApiVisibility.Scope.Internal )
public class CommServiceExtensionPointHelper
{
    /**
     * Declare FavoritesService extension point
     * 
     * @param binder Binder
     */
    public static void declareFavoritesServiceExtensionPoint( GinBinder binder )
    {
        ExtensionsGinHelper.declareExtensionSet( binder, ICommService.class );
    }

    /**
     * Contribute FavoritesService extension
     * 
     * @param binder Binder
     * @param favoritesService FavoritesService class
     */
    public static void contributeFavoritesService( GinBinder binder, Class<? extends ICommService> favoritesService )
    {
        ExtensionsGinHelper.contributeToExtensionSet( binder, ICommService.class, favoritesService );
    }
}
