// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.release;

import com.siemens.splm.clientfx.ui.published.commands.AbstractNavigationCommandHandler;
import com.siemens.splm.clientfx.ui.published.INavigationAreaContent;

import java.util.ArrayList;
import java.util.List;

import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommUtils;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.siemens.splm.clientfx.base.published.AsyncCallbackWithContextPair;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandHandler;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;
import com.patac.checklist.internal.event.handlers.ShowSessionC7tDefineEvent;
import com.patac.checklist.internal.presenters.C7tDefineFilterPresenterW;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.internal.NameTokens;

/**
 * Command handler for C7tDefineFilter 
 */
public class ReleaseCommandHandler
    extends AbstractCommandHandler
{    
    /**
     * Provider for the C7tDefineFilter presenter instance
     */
    @Inject
    private AsyncProvider<C7tDefineFilterPresenterW> m_C7tDefineFilterPresenterProvider;
    
    /** The presenter for the UI */
    protected C7tDefineFilterPresenterW m_presenter;
    
    /**
     * Constructor
     * 
     * @param commandDisplay Display to use for this handler
     */
    @Inject
    public ReleaseCommandHandler( @Named( NameTokens.CMD_C7tDefineRelease ) ICommandDisplay commandDisplay )
    {
        super( NameTokens.CMD_C7tDefineRelease, commandDisplay );
    }
    
    @Override
    public void commandContextChanged()
    {
        //Call super implementation.
        super.commandContextChanged();
		final IModelObject obj = getSelectedModelObject();
		if(obj==null ) {
			setIsVisible( false );
			return;
		}
		setIsVisible( false );
		CommUtils.loadProps(obj, CTypes.getCheckDefProps(), new AsyncCallback<Void>() {
			@Override
			public void onFailure(Throwable caught) {
				
			}

			@Override
			public void onSuccess(Void result) {
				if(CommUtils.isObjModifiableForMe(obj)) {
					IProperty<?> pub = obj.getPropertyObject( CTypes.c7t_publish );
					if(pub!=null) {
						Boolean val = (Boolean) pub.getValue();
						if(val==true)
							setIsVisible( false );
						if(val==false)
							setIsVisible( true );				
					}			
					else
						setIsVisible( false );
				}
				else
					setIsVisible( false );
			}});
    }

	@Override
	protected void doExecute() {
		IModelObject obj = getSelectedModelObject();
		CommUtils.saveStringProp(obj, CTypes.c7t_publish, "1");
		Window.alert("Released.");
	}



}
