// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.crecheckdef;

import com.gwtplatform.mvp.client.UiHandlers;

/**
 * UiHandlers - view to presenter interaction contract.
 */
public interface ICreCheckDefUiHandler
    extends UiHandlers
{
    /**
     * Viewer slot
     */
    Object VIEWER_SLOT = new Object();

    /**
     * create change object
     *
     * @param submitToWorkflow controls if the create object will be submitted to a workflow
     */
    void createBpObject( boolean submitToWorkflow );

    /**
     * Gets and shows the objects to derive
     */
    void getAndShowObjectstoDerive();

}
