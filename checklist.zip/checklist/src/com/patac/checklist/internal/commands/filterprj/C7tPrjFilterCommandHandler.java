// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.filterprj;

import com.siemens.splm.clientfx.ui.published.commands.AbstractNavigationCommandHandler;
import com.siemens.splm.clientfx.ui.published.INavigationAreaContent;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.siemens.splm.clientfx.base.published.AsyncCallbackWithContextPair;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;
import com.patac.checklist.internal.presenters.C7tPrjFilterPresenterW;
import com.patac.checklist.internal.NameTokens;

/**
 * Command handler for C7tViewFilter 
 */
public class C7tPrjFilterCommandHandler
    extends AbstractNavigationCommandHandler
{    
    /**
     * Provider for the C7tViewFilter presenter instance
     */
    @Inject
    private AsyncProvider<C7tPrjFilterPresenterW> m_C7tViewFilterPresenterProvider;
    
    /** The presenter for the UI */
    protected C7tPrjFilterPresenterW m_presenter;
    
    /**
     * Constructor
     * 
     * @param commandDisplay Display to use for this handler
     */
    @Inject
    public C7tPrjFilterCommandHandler( @Named( NameTokens.CMD_C7tProjFilter ) ICommandDisplay commandDisplay )
    {
        super( NameTokens.CMD_C7tProjFilter, commandDisplay );
    }
    
    @Override
    public void commandContextChanged()
    {
        //Call super implementation.
        super.commandContextChanged();

        // Update the model object shown in the object info presenter
        if( isActive() && m_presenter != null )
        {
            m_presenter.setModelObject( getSelectedModelObject() );
        }

        //Code which toggles enabling/disabling of the command
        //may be added here.
        //
        //For this particular example, we will always leave the 
        //command enabled and visible.
        setIsVisible( true );
    }

    @Override
    public void getNavigationAreaContent( AsyncCallback<INavigationAreaContent> callback )
    {
        //Implement the invocation/presentation of the panel.
        m_C7tViewFilterPresenterProvider.get( new AsyncCallbackWithContextPair<C7tPrjFilterCommandHandler, AsyncCallback<INavigationAreaContent>, C7tPrjFilterPresenterW>( this, callback )
        {
            @Override
            public void onFailure( C7tPrjFilterCommandHandler handler, AsyncCallback<INavigationAreaContent> callback2, Throwable caught )
            {
               callback2.onFailure( caught );
            }

            @Override
            public void onSuccess( C7tPrjFilterCommandHandler handler, AsyncCallback<INavigationAreaContent> callback2, C7tPrjFilterPresenterW presenter )
            {
                //Store the handler so we can set new selections without closing the Panel.
                handler.m_presenter = presenter;
                //Set values on the presenter, as required.
                presenter.setModelObject( getSelectedModelObject() );
                callback2.onSuccess( presenter );
            }
        } );
    }

}
