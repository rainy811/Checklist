// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.release;

import com.google.gwt.resources.client.ImageResource;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandDisplay;
import com.patac.checklist.internal.Resources;
import com.patac.checklist.resources.i18n.ChecklistMessages;

/**
 * Display for the nav panel command
 */
public class UnReleaseCommandDisplay
    extends AbstractCommandDisplay
{
    /**
     * Constructor
     */
    public UnReleaseCommandDisplay()
    {
        super( ChecklistMessages.INSTANCE.UnReleaseItmeTitle() , "com.patac.checklist.Checklist"); //$NON-NLS-1$
    }

    @Override
    public ImageResource getIconResource()
    {
        return Resources.INSTANCE.getUnReleaseImg();
    }
}
