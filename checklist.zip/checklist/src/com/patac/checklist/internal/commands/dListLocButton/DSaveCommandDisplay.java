package com.patac.checklist.internal.commands.dListLocButton;

import com.google.gwt.resources.client.ImageResource;
import com.patac.checklist.internal.Resources;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandDisplay;

public class DSaveCommandDisplay 
extends AbstractCommandDisplay
{

	@SuppressWarnings("deprecation")
	public DSaveCommandDisplay() {
		super(ChecklistMessages.INSTANCE.save(), "com.patac.checklist.Checklist");
	}

	@Override
	public ImageResource getIconResource() {
		return Resources.INSTANCE.save();
	}
}
