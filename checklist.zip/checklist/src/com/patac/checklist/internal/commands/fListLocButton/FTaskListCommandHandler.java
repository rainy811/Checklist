package com.patac.checklist.internal.commands.fListLocButton;

import com.cus.comm.published.utils.ICommService;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.event.foEvent.FTaskFilterEvent;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandHandler;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;

public class FTaskListCommandHandler 
extends AbstractCommandHandler{

	@Inject
	private ICommService m_commsvr;
	
	    @Inject
    public FTaskListCommandHandler( @Named( NameTokens.CMD_C7tFTaskList ) ICommandDisplay commandDisplay )
    {
        super( NameTokens.CMD_C7tFTaskList, commandDisplay );
    }
    
    @Override
    public void commandContextChanged()
    {
    	setIsVisible(true);
    }
	@Override
	protected void doExecute() {
		m_commsvr.getEventBus().fireEvent(new FTaskFilterEvent());		
	}
    
    
}
