// @<COPYRIGHT>@
// ==================================================
// Copyright 2014.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.viewmode;

import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.patac.checklist.internal.event.handlers.C7tViewModeChangeEvent;
import com.patac.checklist.internal.service.CSession;
import com.patac.checklist.internal.views.DListLocPrimaryWorkAreaView;
import com.siemens.splm.clientfx.tcui.xrt.published.presenters.ModelObjectListSubLocationPresenter;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandHandler;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;

/**
 * Command Handler for showing change filters
 */
public class ViewModeTableCommandHandler
    extends AbstractCommandHandler
{
	
    /**
     * Constructor
     *
     * @param commandDisplay Display to use for this handler
     */
    @Inject
    public ViewModeTableCommandHandler( @Named( ViewModeTokens.TABLE_MODE ) ICommandDisplay commandDisplay )
    {
        super( ViewModeTokens.TABLE_MODE, commandDisplay );
    }

    @Override
    public void commandContextChanged()
    {
    	String modename = CSession.getVIEW_MODE();
//    	if(ModelObjectListSubLocationPresenter.ViewMode.TableView.name().equals(modename)){
    		setIsVisible( true );
//    	}
//    	else{
    		setIsVisible( true );
//    	}
    }
    
	@Override
	protected void doExecute() {
		getEventBus().fireEvent(new C7tViewModeChangeEvent(ModelObjectListSubLocationPresenter.ViewMode.TableView));		
	}



}
