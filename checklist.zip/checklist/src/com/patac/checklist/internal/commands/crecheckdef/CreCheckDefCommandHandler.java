// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.crecheckdef;

import java.util.List;

import com.siemens.splm.clientfx.tcui.xrt.published.commands.OpenInEditModeOperation;
import com.siemens.splm.clientfx.ui.published.commands.AbstractToolsAndInfoCommandHandler;
import com.siemens.splm.clientfx.ui.published.commands.IURLActionCommandHandler;
import com.siemens.splm.clientfx.ui.published.IToolsAndInfoAreaContent;
import com.cus.comm.published.utils.CommMsg;
import com.cus.comm.published.utils.CommString;
import com.cus.comm.published.utils.CommUtils;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.siemens.splm.clientfx.base.published.AsyncCallbackWithContext;
import com.siemens.splm.clientfx.base.published.AsyncCallbackWithContextPair;
import com.siemens.splm.clientfx.base.published.MessageUtil;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.resources.i18n.ChecklistMessages;

/**
 * Command handler for CreCheckDef 
 */
public class CreCheckDefCommandHandler
    extends AbstractToolsAndInfoCommandHandler
{    
    private String m_types;
    /**
     * Provider for the CreCheckDef presenter instance
     */
    @Inject
    private AsyncProvider<CreCheckDefPresenterW> m_CreCheckDefPresenterProvider;
    
    /** The presenter for the UI */
    protected CreCheckDefPresenterW m_presenter;
    
    /**
     * Constructor
     * 
     * @param commandDisplay Display to use for this handler
     */
    @Inject
    public CreCheckDefCommandHandler( @Named( NameTokens.CMD_CreCheckDef ) ICommandDisplay commandDisplay )
    {
        super( NameTokens.CMD_CreCheckDef, commandDisplay );
    }
    
    @Override
    public void commandContextChanged()
    {
        //Call super implementation.
        super.commandContextChanged();

        // Update the model object shown in the object info presenter
        if( isActive() && m_presenter != null )
        {
            //m_presenter.setModelObject( getSelectedModelObject() );
        }
        
        String token = getSubLocation().getSubLocationNameToken();
        if(NameTokens.C7tDefineLoc_SUB_LOCATION.equals(token)==false && NameTokens.C7tShowOBJ_TOKEN.equals(token)==false)
        {
        	setIsVisible( false);
        	return ;
        }

        String role = CommUtils.getUserRole();
        if(CommString.ROLE_FO.equals(role))
        	setIsVisible( true );
        else
        	setIsVisible( false);
    }

    
    private boolean commandExecutedFromURL()
    {
        /*
         * CreateChange command knows that the command argument would be specific to types. So, if types field is filled
         * up, the command is being executed from URL.
         */
        if( m_types != null && !m_types.isEmpty() )
        {
            return true;
        }
        return false;
    }
    
    @Override
    public void getToolsAndInfoAreaContent( AsyncCallback<IToolsAndInfoAreaContent> callback )
    {
        //Implement the invocation/presentation of the panel.
        m_CreCheckDefPresenterProvider.get( new AsyncCallbackWithContextPair<CreCheckDefCommandHandler, AsyncCallback<IToolsAndInfoAreaContent>, CreCheckDefPresenterW>( this, callback )
        {
            @Override
            public void onFailure( CreCheckDefCommandHandler handler, AsyncCallback<IToolsAndInfoAreaContent> callback2, Throwable caught )
            {
                callback2.onFailure( caught );
            }

            @Override
            public void onSuccess( CreCheckDefCommandHandler handler, 
            		AsyncCallback<IToolsAndInfoAreaContent> contentCall, CreCheckDefPresenterW presenter )
            {
                if( commandExecutedFromURL() )
                {
                    //possible that user may pass multiple type, but we need to ignore all and consider first one.
                    final List<String> typeList = java.util.Arrays.asList( m_types.split( IURLActionCommandHandler.COMMANDARGS_DELIMITER ) );
                    if( typeList != null && typeList.size() > 0 )
                    {
                    	presenter.setBaseTypeNames( typeList.get( 0 ) );
                    }
                }
                else
                {
                	presenter.setBaseTypeNames( CTypes.C7t_CheckDef );
                }
                presenter.addCallback( new AsyncCallbackWithContext<IModelObject, Boolean>( null )
                {
                    @Override
                    public void onFailure( IModelObject object, Throwable caught )
                    {
                        MessageUtil.reportException( caught, ChecklistMessages.INSTANCE.CreCheckDefTitle() );
                    }

                    @Override
                    public void onSuccess( final IModelObject modelObject, Boolean isSubmitted )
                    {
                    	//open created
                    }
                } );
                contentCall.onSuccess( presenter );
            }

        } );

    }

}
