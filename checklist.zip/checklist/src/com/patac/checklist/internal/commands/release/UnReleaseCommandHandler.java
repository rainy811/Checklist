// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.release;

import com.siemens.splm.clientfx.ui.published.commands.AbstractNavigationCommandHandler;
import com.siemens.splm.clientfx.ui.published.INavigationAreaContent;
import com.cus.comm.published.utils.CommUtils;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.siemens.splm.clientfx.base.published.AsyncCallbackWithContextPair;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandHandler;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;
import com.patac.checklist.internal.event.handlers.ShowSessionC7tDefineEvent;
import com.patac.checklist.internal.presenters.C7tDefineFilterPresenterW;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.internal.NameTokens;

/**
 * Command handler for C7tDefineFilter 
 */
public class UnReleaseCommandHandler
    extends AbstractCommandHandler
{    
    /**
     * Provider for the C7tDefineFilter presenter instance
     */
    @Inject
    private AsyncProvider<C7tDefineFilterPresenterW> m_C7tDefineFilterPresenterProvider;
    
    /** The presenter for the UI */
    protected C7tDefineFilterPresenterW m_presenter;
    
    /**
     * Constructor
     * 
     * @param commandDisplay Display to use for this handler
     */
    @Inject
    public UnReleaseCommandHandler( @Named( NameTokens.CMD_C7tDefineUnRelease ) ICommandDisplay commandDisplay )
    {
        super( NameTokens.CMD_C7tDefineUnRelease, commandDisplay );
    }
    
    @Override
    public void commandContextChanged()
    {
        //Call super implementation.
        super.commandContextChanged();
		final IModelObject obj = getSelectedModelObject();
		if(obj==null) {
			setIsVisible( false );
			return;
		}
		setIsVisible( false );
		CommUtils.loadProps(obj, CTypes.getCheckDefProps(), new AsyncCallback<Void>() {
			@Override
			public void onFailure(Throwable caught) {				
			}

			@Override
			public void onSuccess(Void result) {
				if(CommUtils.isObjModifiableForMe(obj)) {
					IProperty<?> pub = obj.getPropertyObject( CTypes.c7t_publish );
					if(pub!=null) {
						Boolean val = (Boolean) pub.getValue();
						if(val==true)
							setIsVisible( true );
						if(val==false)
							setIsVisible( false );					
					}			
					else
						setIsVisible( false );
				}
				else
					setIsVisible( false );
			}});
		setIsVisible( false );
    }

	@Override
	protected void doExecute() {
		IModelObject obj = getSelectedModelObject();
		CommUtils.saveStringProp(obj, CTypes.c7t_publish, "0");
		Window.alert("Un Released.");
	}



}
