// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.viewmode;

import com.google.gwt.resources.client.ImageResource;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandDisplay;


/**
 * Display for the nav panel command
 */
public class ViewModeTableCommandDisplay
    extends AbstractCommandDisplay
{
    /**
     * Constructor
     */
    public ViewModeTableCommandDisplay()
    {
        super( ViewModeMessages.INSTANCE.setTableMode() , "com.patac.checklist.Checklist"); //$NON-NLS-1$
    }

    @Override
    public ImageResource getIconResource()
    {
        return Resources.INSTANCE.getTableImage();
    }
}
