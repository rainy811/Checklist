// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.filtercheckdef;

import com.siemens.splm.clientfx.ui.published.commands.AbstractNavigationCommandHandler;
import com.siemens.splm.clientfx.ui.published.INavigationAreaContent;
import com.cus.comm.published.utils.CommMsg;
import com.google.gwt.inject.client.AsyncProvider;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.siemens.splm.clientfx.base.published.AsyncCallbackWithContextPair;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;
import com.patac.checklist.internal.presenters.C7tDefineFilterPresenterW;
import com.patac.checklist.internal.NameTokens;

/**
 * Command handler for C7tDefineFilter 
 */
public class C7tDefineFilterCommandHandler
    extends AbstractNavigationCommandHandler
{    
    /**
     * Provider for the C7tDefineFilter presenter instance
     */
    @Inject
    private AsyncProvider<C7tDefineFilterPresenterW> m_C7tDefineFilterPresenterProvider;
    
    /** The presenter for the UI */
    protected C7tDefineFilterPresenterW m_presenter;
    
    /**
     * Constructor
     * 
     * @param commandDisplay Display to use for this handler
     */
    @Inject
    public C7tDefineFilterCommandHandler( @Named( NameTokens.CMD_C7tDefineFilter ) ICommandDisplay commandDisplay )
    {
        super( NameTokens.CMD_C7tDefineFilter, commandDisplay );
    }
    
    @Override
    public void commandContextChanged()
    {
        //Call super implementation.
        super.commandContextChanged();

        // Update the model object shown in the object info presenter
        if( isActive() && m_presenter != null )
        {
            m_presenter.setModelObject( getSelectedModelObject() );
        }

        //Code which toggles enabling/disabling of the command
        //may be added here.
        //
        //For this particular example, we will always leave the 
        //command enabled and visible.
        setIsVisible( true );
    }

    @Override
    public void getNavigationAreaContent( AsyncCallback<INavigationAreaContent> callback )
    {
        //Implement the invocation/presentation of the panel.
        m_C7tDefineFilterPresenterProvider.get( new AsyncCallbackWithContextPair<C7tDefineFilterCommandHandler, AsyncCallback<INavigationAreaContent>, C7tDefineFilterPresenterW>( this, callback )
        {
            @Override
            public void onFailure( C7tDefineFilterCommandHandler handler, AsyncCallback<INavigationAreaContent> callback2, Throwable caught )
            {
               callback2.onFailure( caught );
            }

            @Override
            public void onSuccess( C7tDefineFilterCommandHandler handler, AsyncCallback<INavigationAreaContent> callback2, C7tDefineFilterPresenterW presenter )
            {
                //Store the handler so we can set new selections without closing the Panel.
                handler.m_presenter = presenter;
                //Set values on the presenter, as required.
                presenter.setModelObject( getSelectedModelObject() );
                callback2.onSuccess( presenter );
            }
        } );
    }

}
