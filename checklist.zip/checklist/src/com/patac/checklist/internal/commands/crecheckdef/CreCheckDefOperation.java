// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.crecheckdef;

import java.util.List;
import java.util.Map;

import com.cus.comm.published.utils.CommUtils;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.web.bindery.event.shared.EventBus;
import com.gwtplatform.mvp.client.proxy.PlaceManager;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.event.handlers.ShowSessionC7tDefineEvent;
import com.patac.checklist.internal.service.CSession;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.base.operations.published.IOperation;
import com.siemens.splm.clientfx.base.published.IMessageService;
import com.siemens.splm.clientfx.base.published.config.IFxBaseGinjector;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IJSO;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IJsArray;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.JSOFactory;
import com.siemens.splm.clientfx.kernel.published.ITypeName;
import com.siemens.splm.clientfx.kernel.soa.published.ISOAResponse;
import com.siemens.splm.clientfx.tcui.create.published.CreateObjectOperation;
import com.siemens.splm.clientfx.tcui.utils.published.DataManagementService;
import com.siemens.splm.clientfx.tcui.utils.published.ModelUtils;
import com.siemens.splm.clientfx.xrt.published.databind.viewmodel.IXRTViewModel;

/**
 * Operation to create a change object and optionally submit to workflow.
 */
public class CreCheckDefOperation
    extends CreateObjectOperation
{
    /**
     * Created object revision
     */
    private IModelObject m_createdObjectRev;

    /**
     * objects to be related as attachments
     */
    private Map<String, List<IModelObject>> m_attachments;

    /**
     * indicates if a workflow process will be initiated
     */
    private boolean m_submitToWorkflow;
    
    private EventBus m_Eventbus;
    
    private PlaceManager m_placeManager;

    /**
     * Constructor
     *
     * @param typeName Type to create
     * @param xrtViewModel XRT view model that contains the create input
     * @param attachments attached related objects
     * @param submitToWorkflow indicates if the newly created object will be submitted to a workflow
     */
    public CreCheckDefOperation( EventBus eventBus, PlaceManager pm, String typeName, IXRTViewModel xrtViewModel,
            Map<String, List<IModelObject>> attachments, boolean submitToWorkflow )
    {
        super( typeName, xrtViewModel );

        m_placeManager = pm;
        m_Eventbus = eventBus;
        m_attachments = attachments;
        m_submitToWorkflow = submitToWorkflow;
    }

    @Override
    public void execute()
    {
        IJSO input = CreateObjectOperation.getCreateInput( NameTokens.CreCheckDefOp, m_typeName, 
                m_xrtViewModel, m_attachments, m_submitToWorkflow, null );
        IJsArray inputs = JSOFactory.createArray();
        inputs.push( input );
        DataManagementService.createRelateAndSubmitObjects( inputs, new AsyncCallback<ISOAResponse>()
        {
            @Override
            public void onFailure( Throwable caught )
            {
                setCurrentState( IOperation.OperationState.FAILED, caught );
            }

            @Override
            public void onSuccess( ISOAResponse response )
            {
                m_createdObject = response.getModelObject( "output[0].objects[0]" ); //$NON-NLS-1$
                m_createdObjectRev = response.getModelObject( "output[0].objects[1]" ); //$NON-NLS-1$

                IJsArray output = response.getArray( "output" ); //$NON-NLS-1$
                for( int ii = 0; ii < output.length(); ii++ )
                {
                    IModelObject[] objects = output.get( ii ).getModelObjects( "objects" ); //$NON-NLS-1$
                    for( IModelObject obj : objects )
                    {
                        if( obj.getTypeObject().isInstanceOf( ITypeName.ItemRevision ) )
                        {
                            m_createdObjectRev = obj;
                            break;
                        }
                    }
                }

                // Set operation complete
                setCurrentState( IOperation.OperationState.COMPLETED );       
                
                //Display Notification message
                IMessageService msgService = IFxBaseGinjector.INSTANCE.getMessageService();
                String objectDisplayName = ModelUtils.getDisplayName( m_createdObjectRev );
                msgService.notify( ChecklistMessages.INSTANCE.objCreated( objectDisplayName ) );
                
                //PlaceRequest request = m_placeManager.getCurrentPlaceRequest();

                CommUtils.saveStringProp(m_createdObject, CTypes.c7t_user_id, CommUtils.getUserString());
                String gpname = CommUtils.getUserGroupFull();
                String[] gps = gpname.split(CTypes.DOT_SPLITTER);
                if(gps.length>=2){
                	CommUtils.saveStringProp(m_createdObject, CTypes.c7t_Dept01, gps[1]);
                	CommUtils.saveStringProp(m_createdObject, CTypes.c7t_Dept02, gps[0]);
                }
                
                CSession.addSessionItemUid(m_createdObject.getUid());
                m_Eventbus.fireEvent(new ShowSessionC7tDefineEvent(m_createdObject.getUid()));
            }
        } );
    }

    @Override
    public String getDisplayName()
    {
        return ChecklistMessages.INSTANCE.CreCheckDefTitle();
    }

    /**
     * Return the created object revision
     *
     * @return created object revision
     */
    public IModelObject getCreatedObjectRevision()
    {
        return m_createdObjectRev;
    }
}
