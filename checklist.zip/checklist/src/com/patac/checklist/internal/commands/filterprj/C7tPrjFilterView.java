// @<COPYRIGHT>@
// ==================================================
// Copyright 2017.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.filterprj;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.cus.comm.published.utils.ICommService;
import com.cus.comm.resources.CommMessages;
import com.cus.comm.svr.QueryInputSet;
import com.cus.comm.widgets.dlg.cuspanel.TitledProperty;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.gwtplatform.mvp.client.ViewWithUiHandlers;
import com.patac.checklist.internal.event.handlers.LoadC7tViewEvent;
import com.patac.checklist.internal.types.CTypes;
import com.patac.checklist.internal.ui.common.widgets.prjtree.ProjCellTreeView;
import com.patac.checklist.internal.uihandlers.C7tPrjFilterUiHandlers;

/**
 * View for C7tDefineFilter.
 */
public class C7tPrjFilterView
    extends ViewWithUiHandlers<C7tPrjFilterUiHandlers>
    implements com.patac.checklist.internal.presenters.C7tPrjFilterPresenterW.MyView
{
	@Inject
	private ICommService m_commsvr;
    /**
     * Widget
     */
    private final Widget m_widget;

    @UiField
    ProjCellTreeView treeView;    

    
    private TitledProperty cbMyObj;
    
    private Map<String , TitledProperty> m_attr_map = new HashMap<String , TitledProperty>();
    
    /**
     * Ui binder
     */
    public interface Binder
        extends UiBinder<Widget, C7tPrjFilterView>
    {
        //
    }

    /**
     * Constructor
     * 
     * @param binder Ui binder
     */
    @Inject
    public C7tPrjFilterView( final Binder binder )
    {
        m_widget = binder.createAndBindUi( this );        
    }

    private void getInputs(QueryInputSet qset) {
    	String bmy = cbMyObj.getPropertyValue();
		if(CommMessages.INSTANCE.textYes().equals(bmy)){
			bmy = CTypes.TRUE;
			qset.push(CTypes.my_obj, bmy);
		}else if(CommMessages.INSTANCE.textNo().equals(bmy)){
			bmy = CTypes.FALSE;
			qset.push(CTypes.my_obj, bmy);
		}
       	qset.push(CTypes.my_obj, bmy);
		for(Entry<String, TitledProperty> kvs : m_attr_map.entrySet()){			
			String name = kvs.getKey();
			String val="";
			if(CTypes.c7t_publish.equals(name)){
				val = kvs.getValue().getPropertyValue();
				if(CommMessages.INSTANCE.textYes().equals(val)){
					val = CTypes.TRUE;
					qset.push(name, val);
				}else if(CommMessages.INSTANCE.textNo().equals(val)){
					val = CTypes.FALSE;
					qset.push(name, val);
				}
			}else{
				val = kvs.getValue().getPropertyValue();
				if(val!=null){
					if("".equals(val.trim())==false){
						qset.push(name, val);
					}
				}
			}
		}
	}
    
    @Override
    public Widget asWidget()
    {
        return m_widget;
    }

    @Override
    public void setObjectString( String objectString )
    {
        //Update the text in the UI.

    }
}
