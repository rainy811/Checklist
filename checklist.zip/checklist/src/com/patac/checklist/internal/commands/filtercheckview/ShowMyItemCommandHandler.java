package com.patac.checklist.internal.commands.filtercheckview;

import com.cus.comm.published.utils.ICommService;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.event.handlers.LoadC7tDefineEvent;
import com.patac.checklist.internal.service.QueryInputSet;
import com.patac.checklist.internal.types.CTypes;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandHandler;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;

public class ShowMyItemCommandHandler extends AbstractCommandHandler{
	@Inject
	private ICommService m_commsvr;
	
	
	 @Inject
	    public ShowMyItemCommandHandler( @Named( NameTokens.CMD_MyC7tDefine) ICommandDisplay commandDisplay )
	    {
	        super( NameTokens.CMD_MyC7tDefine, commandDisplay );
	    }
	    
	    @Override
	    public void commandContextChanged()
	    {
	    	setIsVisible(true);
	    }
		@Override
		protected void doExecute() {
			QueryInputSet qset = new QueryInputSet();
			qset.push(CTypes.my_obj, CTypes.TRUE);
	        m_commsvr.getEventBus().fireEvent(new LoadC7tDefineEvent(qset));
	        
		}
}


