package com.patac.checklist.internal.commands.dListLocButton;

import com.cus.comm.published.utils.ICommService;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.event.dreEvent.DYellowFilterEvent;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandHandler;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;

public class DYellowCheckCommandHandler extends AbstractCommandHandler{
	
	@Inject
	private ICommService m_commsvr;
	
    @Inject
    public DYellowCheckCommandHandler( @Named( NameTokens.CMD_C7tDYellowCheck ) ICommandDisplay commandDisplay )
    {
        super( NameTokens.CMD_C7tDYellowCheck, commandDisplay );
    }
    
    @Override
    public void commandContextChanged()
    {
    	setIsVisible(true);
    }
	@Override
	protected void doExecute() {
		m_commsvr.getEventBus().fireEvent(new DYellowFilterEvent());
	}
}
