package com.patac.checklist.internal.commands.viewmode;

public interface ViewModeTokens {
	String TABLE_MODE = "com.cus.viewmode.tablemode";
	String TABLE_SUM_MODE = "com.cus.viewmode.tablesummode";
}
