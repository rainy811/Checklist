// @<COPYRIGHT>@
// ==================================================
// Copyright 2013.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.crecheckdef;

import com.google.gwt.dom.client.DivElement;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.uibinder.client.UiBinder;
import com.google.gwt.uibinder.client.UiField;
import com.google.gwt.uibinder.client.UiHandler;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.gwtplatform.mvp.client.ViewWithUiHandlers;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.tcui.utils.published.ModelUtils;
import com.siemens.splm.clientfx.ui.commands.published.CommandBarPresenterWidget;
import com.siemens.splm.clientfx.ui.commands.published.ICommandHandler;
import com.siemens.splm.clientfx.ui.published.ISubLocationService;
import com.siemens.splm.clientfx.ui.selection.published.ISelectionStatusSummaryVM;
import com.siemens.splm.clientfx.ui.widgets.published.css.IUIWidgetsCss;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 * Create change view class to show change contents while creation
 */
public class CreCheckDefView
    extends ViewWithUiHandlers<ICreCheckDefUiHandler>
    implements CreCheckDefPresenterW.MyView
{
    /**
     * Widget
     */
    private Widget m_widget;

    /**
     * Create Change Panel
     */
    @UiField
    HTMLPanel createVaBpPanel;

    /**
     * Title Label
     */
    @UiField
    Label newChangeTitleLabel;

    /**
     * Main panel
     */
    @UiField
    HTMLPanel createInputPanel;

    /**
     * save button
     */
    @UiField
    Button saveBtn;

    /**
     * submit button
     */
    @UiField
    Button submitBtn;

    /**
     * Map of relation and corresponding HTML Panel
     */
    private HashMap<String, HTMLPanel> htmlPanelMap = new HashMap<>();

    /**
     * The real name for relation
     */
    private String m_realRelationName;

    /**
     * Map of relation name and all objects with that relation
     */
    public HashMap<String, List<IModelObject>> relNameObjectCompleteMap = new HashMap<>();

    /**
     * Factory to create command bar widgets
     */
    @Inject
    private CommandBarPresenterWidget.IFactory m_commandBarWidgetFactory;

    /**
     * Sublocation service
     */
    @Inject
    private ISubLocationService m_subLocationSvc;

    /**
     * Provider for selection status summary
     */
    @Inject
    private Provider<ISelectionStatusSummaryVM> m_provider;

    /**
     * Ui binder
     */
    public interface IBinder
        extends UiBinder<Widget, CreCheckDefView>
    {
        //
    }

    /**
     * Constructor
     *
     * @param binder Ui binder
     */
    @Inject
    public CreCheckDefView( IBinder binder )
    {
        m_widget = binder.createAndBindUi( this );
    }

    @Override
    public Widget asWidget()
    {
        return m_widget;
    }

    @Override
    public void setInSlot( Object slot, Widget content )
    {
        if( slot == CreCheckDefPresenterW.PROPERTIES_VIEWER_SLOT )
        {
            createInputPanel.clear();
            if( content != null )
            {
                createInputPanel.add( content );
            }
        }

        else if( slot == CreCheckDefPresenterW.PROPAGATE_RELATION_VIEWER_SLOT )
        {
            setObjInSlot( slot, content );
        }

    }

    /**
     * Method to add objects on the panel
     *
     * @param slot the slot where content should be placed
     * @param content the content to be placed
     */
    public void setObjInSlot( Object slot, Widget content )
    {

        String htmlString = ""; //$NON-NLS-1$
        HTMLPanel panelItemList = new HTMLPanel( htmlString );
        if( content != null )
        {
            String currentRelName = getCurrentRelationName();
            if( !currentRelName.isEmpty() )
            {
                htmlPanelMap.put( currentRelName, panelItemList );
            }
            panelItemList.add( content );
        }
    }

    /**
     * @param event Click event
     */
    @UiHandler( "saveBtn" )
    void onSaveButtonClick( ClickEvent event )
    {
        getUiHandlers().createBpObject( false );
    }

    /**
     * @param event Click event
     */
    @UiHandler( "submitBtn" )
    void onSubmitButtonClick( ClickEvent event )
    {
        getUiHandlers().createBpObject( true );
    }

    @Override
    public void setTitle( String title )
    {
        if( title != null )
        {
            newChangeTitleLabel.setVisible( true );
            newChangeTitleLabel.setText( title );
        }
        else
        {
            newChangeTitleLabel.setText( "" ); //$NON-NLS-1$
            newChangeTitleLabel.setVisible( false );
        }
    }

    @Override
    public void reset()
    {
        setTitle( null );
    }

    @Override
    public void setSaveButtonsVisible( boolean visible )
    {
        saveBtn.setVisible( visible );
        submitBtn.setVisible( visible );
    }


    @Override
    public void executeActionOnClick()
    {

    }

    @Override
    public void createAndAddLinks( IProperty<List<IModelObject>> propertyProbObject, boolean copyOptionsPreSelection,
            IModelObject selectedObject, String relation )
    {
        VerticalPanel panel = new VerticalPanel();
        final String relationRealName = propertyProbObject.getPropertyDescription().getName();
        Anchor relationsLink = new Anchor( ModelUtils.getPropertyDisplayName( selectedObject, relation ) );
        relationsLink.setStyleName( "aw-layout-panelSectionTitle link-style-5" ); //$NON-NLS-1$
        panel.add( relationsLink );

        setCurrentRelationName( relationRealName );
        htmlPanelMap.put( relationRealName, null );

        relationsLink.addClickHandler( new ClickHandler()
        {
            @Override
            public void onClick( ClickEvent event )
            {
                showHideHTMLPanel( relationRealName );
            }

        } );
    }

    /**
     * Method that shows or hides the panel when the relation links are clicked.
     *
     * @param relationRealName Real name of relation
     */
    private void showHideHTMLPanel( String relationRealName )
    {
        if( htmlPanelMap.containsKey( relationRealName ) )
        {
            HTMLPanel clickedPanel = htmlPanelMap.get( relationRealName );
            clickedPanel.setVisible( true );

            if( clickedPanel.getStyleName().contains( IUIWidgetsCss.HIDDEN ) )
            {
                clickedPanel.setStyleName( IUIWidgetsCss.HIDDEN, false );
            }
            else
            {
                clickedPanel.setStyleName( IUIWidgetsCss.HIDDEN, true );
            }
        }
    }

    /**
     * Setter for m_realRelationName
     *
     * @param relationRealName the current relation that is being clicked on
     */
    private void setCurrentRelationName( String relationRealName )
    {
        m_realRelationName = relationRealName;
    }

    /**
     * Getter for m_realRelationName
     *
     * @return m_realRelationName the current relation that is being clicked on
     */
    private String getCurrentRelationName()
    {
        return m_realRelationName;
    }

    @Override
    public void getWidgetAndSetInSlot( Collection<ICommandHandler> result )
    {
        CommandBarPresenterWidget cmdBar = m_commandBarWidgetFactory.create( result,
                m_subLocationSvc.getCurrentSubLocation(), true, true, false, false );
        Widget widg1 = cmdBar.getWidget();
        //  push this to the view.
        setInSlot( CreCheckDefPresenterW.SELECTION_VIEWER_SLOT, widg1 );
    }

}
