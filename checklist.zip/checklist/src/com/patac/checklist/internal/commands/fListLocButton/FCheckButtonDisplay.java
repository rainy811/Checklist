package com.patac.checklist.internal.commands.fListLocButton;

import com.google.gwt.resources.client.ImageResource;
import com.patac.checklist.internal.Resources;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandDisplay;

public class FCheckButtonDisplay  extends AbstractCommandDisplay{
	@SuppressWarnings("deprecation")
	public FCheckButtonDisplay() {
		 super( ChecklistMessages.INSTANCE.publish() , "com.patac.checklist.Checklist"); //$NON-NLS-1$
	}

   @Override
   public ImageResource getIconResource()
   {
       return Resources.INSTANCE.check();
   }
}
