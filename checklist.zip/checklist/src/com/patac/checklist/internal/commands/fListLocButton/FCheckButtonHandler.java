package com.patac.checklist.internal.commands.fListLocButton;

import com.cus.comm.published.utils.ICommService;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.inject.Inject;
import com.google.inject.name.Named;
import com.patac.checklist.internal.NameTokens;
import com.patac.checklist.internal.event.foEvent.FOCheckEvent;
import com.patac.checklist.internal.event.foEvent.FONotSubmitEvent;
import com.patac.checklist.internal.event.foEvent.FSubmitCheckEvent;
import com.siemens.splm.clientfx.ui.commands.published.AbstractCommandHandler;
import com.siemens.splm.clientfx.ui.commands.published.ICommandDisplay;

public class FCheckButtonHandler extends AbstractCommandHandler{

	@Inject
	private ICommService m_commsvr;
	
	
	@Inject
    public FCheckButtonHandler( @Named( NameTokens.CMD_publishButton ) ICommandDisplay commandDisplay )
    {
        super( NameTokens.CMD_publishButton, commandDisplay );
    }
    
    @Override
    public void commandContextChanged()
    {
    	setIsVisible(true);
    }
	@Override
	protected void doExecute() {
		m_commsvr.getEventBus().fireEvent(new FOCheckEvent());
		VerticalPanel  dialogVPanel = new VerticalPanel();
		// Create the popup dialog box
		final DialogBox dialogBox = new DialogBox(true);
		dialogBox.setAnimationEnabled(true);
		
		Label title = new Label("Comments");
		TextBox contents =new TextBox();
		Button checkPass = new Button("Pass");
		Button checkFail = new Button("Fail");
		
		
		HorizontalPanel twoButton = new HorizontalPanel();
		
		dialogVPanel.add(title);
		dialogVPanel.add(contents);
		twoButton.add(checkPass);
		
		twoButton.add(checkFail);
		dialogVPanel.add(twoButton);
		
		dialogBox.add(dialogVPanel);
		dialogBox.center();
		
		checkPass.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				m_commsvr.getEventBus().fireEvent(new FSubmitCheckEvent());
			}
			
		});
		checkFail.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				m_commsvr.getEventBus().fireEvent(new FONotSubmitEvent());
			}
			
		});
		
		
	}
}
