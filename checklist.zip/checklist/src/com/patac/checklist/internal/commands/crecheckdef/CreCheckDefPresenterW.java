// @<COPYRIGHT>@
// ==================================================
// Copyright 2014.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

package com.patac.checklist.internal.commands.crecheckdef;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.cus.comm.tcui.attachments.AttachmentsPresenterW;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.inject.Inject;
import com.google.inject.Provider;
import com.google.web.bindery.event.shared.EventBus;
import com.gwtplatform.mvp.client.HasUiHandlers;
import com.gwtplatform.mvp.client.View;
import com.gwtplatform.mvp.client.proxy.PlaceManager;
import com.patac.checklist.resources.i18n.ChecklistMessages;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.MaturityEnum;
import com.siemens.splm.clientfx.base.annotations.published.ApiVisibility.Scope;
import com.siemens.splm.clientfx.base.operations.published.IOperation;
import com.siemens.splm.clientfx.base.operations.published.IOperationsInjector;
import com.siemens.splm.clientfx.base.operations.published.OperationChangeAdapter;
import com.siemens.splm.clientfx.base.published.AsyncCallbackWithContext;
import com.siemens.splm.clientfx.base.published.IPropertyChangeListener;
import com.siemens.splm.clientfx.base.published.MessageUtil;
import com.siemens.splm.clientfx.base.published.PropertyChangeEvent;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelObject;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IModelType;
import com.siemens.splm.clientfx.kernel.clientmodel.published.IProperty;
import com.siemens.splm.clientfx.kernel.published.ISession;
import com.siemens.splm.clientfx.tcui.create.published.presenters.CreateInputPresenterW;
import com.siemens.splm.clientfx.tcui.utils.published.ModelUtils;
import com.siemens.splm.clientfx.tcui.widgets.published.presenters.ModelObjectListPresenterWidget;
import com.siemens.splm.clientfx.tcui.widgets.published.uihandlers.ICellViewInteraction;
import com.siemens.splm.clientfx.tcui.widgets.published.utils.IModelTypeInfo;
import com.siemens.splm.clientfx.tcui.widgets.published.utils.ModelTypeInfo;
import com.siemens.splm.clientfx.ui.commands.published.ICommandContributionRegistry;
import com.siemens.splm.clientfx.ui.commands.published.ICommandHandler;
import com.siemens.splm.clientfx.ui.published.ISubLocation;
import com.siemens.splm.clientfx.ui.published.ISubLocationService;
import com.siemens.splm.clientfx.ui.published.presenters.AbstractToolsAndInfoAreaPresenterWidget;
import com.siemens.splm.clientfx.ui.selection.published.IConsumeSelectionStatusSummary;
import com.siemens.splm.clientfx.ui.selection.published.ISelectionStatusSummaryVM;
import com.siemens.splm.clientfx.ui.selection.published.ISetSelectionModel;
import com.siemens.splm.clientfx.ui.selection.published.UiOrderedMultiSelectionModelWithNotifications;
import com.siemens.splm.clientfx.ui.widgets.published.ICellContainer;
import com.siemens.splm.clientfx.ui.widgets.published.ICellContainerLifeCycle;
import com.siemens.splm.clientfx.ui.widgets.published.ISelectionTypeControl;
import com.siemens.splm.clientfx.xrt.published.databind.viewmodel.IXRTViewModel;

/**
 * Create change presenter to create change objects
 */
@ApiVisibility( maturity = MaturityEnum.Experimental, publishScope = Scope.Internal )
public class CreCheckDefPresenterW
    extends AbstractToolsAndInfoAreaPresenterWidget<CreCheckDefPresenterW.MyView>
    implements ICreCheckDefUiHandler
{
    @Inject
    private PlaceManager m_placeManager;
    @Inject
    private ISession m_session;
    
    /**
     * Properties Viewer slot
     */
    public static final Object PROPERTIES_VIEWER_SLOT = new Object();

    /**
     * Attachments Viewer slot
     */
    public static final Object ATTACHMENTS_VIEWER_SLOT = new Object();

    /**
     * Propagate Relations slot
     */
    public static final Object PROPAGATE_RELATION_VIEWER_SLOT = new Object();

    /**
     * Selection VM slot
     */
    public static final Object SELECTION_VIEWER_SLOT = new Object();

    /**
     * create object presenter
     */
    private CreateInputPresenterW m_createInputPresenter;

    /**
     * attachments presenter
     */
    private AttachmentsPresenterW m_attachmentsPresenter;

    /**
     * object type name
     */
    private String m_objectTypeName;

    /**
     * The selected objects
     */
    private List<IModelObject> m_selectedObjects;

    /**
     * Whether this is a derived change
     */
    private boolean m_derivedChange = false;

    /**
     * Flag for whether this is displaying a single type
     */
    private boolean m_displayingSingleType = false;

    /**
     * List of relations to propagate in a derive change operation
     */
    private List<String> m_relationNamesToPropagate;

    /**
     * Flag for setting preselection true or false
     */
    private boolean m_copyOptionsPreSelection = false;

    /**
     * UIOrdered multi selection model
     */
    private UiOrderedMultiSelectionModelWithNotifications<IModelObject> m_selectionModel;

    /**
     * Monitor to hold the optional reference to notifier
     */
    private ICellContainerLifeCycle m_listCellMonitor;

    /**
     * List view presenter factory
     */
    @Inject
    private ModelObjectListPresenterWidget.Factory m_listViewPresenterFactory;

    /**
     * Command widget registry
     */
    @Inject
    private ICommandContributionRegistry m_commandWidgetRegistry;

    /**
     * Provider for selection status summary
     */
    @Inject
    private Provider<ISelectionStatusSummaryVM> m_provider;

    /**
     * Updated Map of relation name and selection model
     */
    public HashMap<String, UiOrderedMultiSelectionModelWithNotifications<IModelObject>> m_modelRelNameMap = new HashMap<>();

    /**
     * Call backs after object is created
     */
    private final List<AsyncCallbackWithContext<IModelObject, Boolean>> m_callbacks = new ArrayList<>();

    /** Sublocation service */
    @Inject
    private ISubLocationService m_subLocationSvc;

    /**
     * Constructor
     *
     * @param eventBus Event bus
     * @param view view
     * @param createInputPresenter create input presenter
     * @param attachmentsPresenter attachments presenter
     * @param changeObjectTypesPresenter types presenter
     */
    @Inject
    public CreCheckDefPresenterW( EventBus eventBus, MyView view, CreateInputPresenterW createInputPresenter,
            AttachmentsPresenterW attachmentsPresenter)
    {
        super( eventBus, view );
        getView().setUiHandlers( this );
        m_createInputPresenter = createInputPresenter;
        m_attachmentsPresenter = attachmentsPresenter;
        m_attachmentsPresenter.setCreateChangePresenter( this );
    }

    /**
     * View interface.
     */
    public interface MyView
        extends View, HasUiHandlers<ICreCheckDefUiHandler>
    {
        /**
         * Set title
         *
         * @param title Title
         */
        void setTitle( String title );

        /**
         * reset the view UI
         */
        void reset();

        /**
         * Creates and adds the relation links
         *
         * @param propertyProbObject The property object containing ImodelObject details.
         * @param copyOptionsPreSelection flag to specify if objects should be preselected
         * @param selectedObject The current selected object
         * @param relation The relation link to add
         */
        void createAndAddLinks( IProperty<List<IModelObject>> propertyProbObject, boolean copyOptionsPreSelection,
                IModelObject selectedObject, String relation );

        void setSaveButtonsVisible( boolean visible );
        
        void executeActionOnClick();

        /**
         * @param result Collection of ICommandHandlers
         */
        void getWidgetAndSetInSlot( Collection<ICommandHandler> result );

    }

    @Override
    public String getTitle()
    {
       return ChecklistMessages.INSTANCE.CreCheckDefTitle();
    }

    @Override
    public void createBpObject( final boolean submitToWorkflow )
    {
        final IXRTViewModel xrtViewModel = m_createInputPresenter.getViewModel();

        xrtViewModel.validate( new AsyncCallback<Boolean>()
        {
            @Override
            public void onFailure( Throwable caught )
            {
                MessageUtil.reportException( caught, ChecklistMessages.INSTANCE.createObjectOperationFailed() );
            }

            @Override
            public void onSuccess( Boolean result )
            {
                if( result.booleanValue() )
                {
                    Map<String, List<IModelObject>> attachmentsMap = m_attachmentsPresenter.getAttachmentsWithRelations();
                    attachmentsMap.clear();
                    attachmentsMap = getAttachmentsMap();
                    final CreCheckDefOperation issueOperation = new CreCheckDefOperation( getEventBus(), m_placeManager,  m_objectTypeName,
                            xrtViewModel, attachmentsMap, submitToWorkflow );
                    IOperationsInjector.INSTANCE.getOperationManager().schedule( issueOperation );
                    addChangeListener( issueOperation, submitToWorkflow );

                }
            }

            private Map<String, List<IModelObject>> getAttachmentsMap()
            {
                Map<String, List<IModelObject>> derivedChangeAttachmentMap = new HashMap<>();

                for( String relationName : m_modelRelNameMap.keySet() )
                {
                    UiOrderedMultiSelectionModelWithNotifications<IModelObject> selectionModelNew = m_modelRelNameMap.get( relationName );
                    derivedChangeAttachmentMap.put( relationName, selectionModelNew.getSelectedList() );

                }

                return derivedChangeAttachmentMap;
            }
        } );
    }

    /**
     * Add callback after object is created
     *
     * @param callback Callback
     */
    public void addCallback( AsyncCallbackWithContext<IModelObject, Boolean> callback )
    {
        m_callbacks.add( callback );
    }

    
    /**
     * Set base type name
     *
     * @param typeName the name of the workspace object type to create
     */
    public void setBaseTypeNames( final String typeName )
    {
        if( m_session.getClientMetaModel().containsType( typeName ) )
        {
            setCreateType( typeName );
        }
        else
        {
            ArrayList<String> typesToLoad = new ArrayList<>();
            typesToLoad.add( typeName );
            m_session.getClientMetaModel().ensureModelTypesLoaded( typesToLoad, new AsyncCallback<Void>()
            {
                @Override
                public void onFailure( Throwable caught )
                {
                    
                }

                @Override
                public void onSuccess( Void result )
                {
                    setCreateType( typeName );
                }
            } );
        }
    }
    
    /**
     * Show CreateInputPresenterW when object type is selected
     *
     * @param modelTypeInfo selected type
     */
    public void onObjectTypeSelected( final IModelTypeInfo modelTypeInfo )
    {
        if( modelTypeInfo != null )
        {
            m_objectTypeName = modelTypeInfo.getName();

            m_createInputPresenter.setTypeName( m_objectTypeName, new IPropertyChangeListener()
            {
                @Override
                public void propertyChange( PropertyChangeEvent event )
                {
                    /**
                     * After XRT page is loaded, set title
                     */
                    getView().setTitle( modelTypeInfo.getDisplayName() );

                }
            } );

            List<String> typeNames = new ArrayList<>();
            typeNames.add( modelTypeInfo.getName() );
            setInSlot( CreCheckDefPresenterW.PROPERTIES_VIEWER_SLOT, m_createInputPresenter );
            addSupportingInfoForContext();
        }
    }


    /**
     * Set the selected objects
     *
     * @param selectedObjects List of selected obects
     */
    public void setCurrentSelection( List<IModelObject> selectedObjects )
    {
        m_selectedObjects = selectedObjects;
    }

    /**
     * Get the selected Workspace object.
     *
     * @return workspace object. null if an single workspace object is not selected
     */
    public List<IModelObject> getCurrentSelection()
    {
        return m_selectedObjects;
    }

    /**
     * Add selection as context reference items
     */
    public void addSupportingInfoForContext()
    {
        m_attachmentsPresenter.addSupportingInfo( getCurrentSelection() );
    }


    @Override
    protected void onReveal()
    {
        super.onReveal();
    }

    /**
     * @param value this presenter is displaying only one type
     */
    public void setDisplayingSingleType( boolean value )
    {
        m_displayingSingleType = true;
    }

    /**
     * @return boolean whether this presenter in displaying only one type
     */
    public boolean isDisplayingSingleType()
    {
        return m_displayingSingleType;
    }

    /**
     * Add the change listener to the operation
     *
     * @param changeOperation the change operation
     * @param submitToWorkflow submit to workflow flag
     */
    private void addChangeListener( CreCheckDefOperation changeOperation, boolean submitToWorkflow )
    {
        final boolean submitToWorkflowValue = submitToWorkflow;

        changeOperation.addChangeListener( new OperationChangeAdapter()
        {

            @Override
            public void failed( IOperation operation )
            {
                MessageUtil.reportException( operation.getCaughtException(),
                		ChecklistMessages.INSTANCE.createObjectOperationFailed() );

                if( m_callbacks != null )
                {
                    for( AsyncCallbackWithContext<IModelObject, Boolean> callback : m_callbacks )
                    {
                        callback.onFailure( operation.getCaughtException() );
                    }
                }
            }

            @Override
            public void completed( IOperation operation )
            {
                // Get the current sub location
                ISubLocation subLocation = m_subLocationSvc.getCurrentSubLocation();

                if( subLocation != null )
                {
                    // The command is done, so tell the sub location to remove the active tool
                    subLocation.setActiveToolsAndInfoCommand( null );
                }

                CreCheckDefOperation op = (CreCheckDefOperation) operation;
                IModelObject changeObject = op.getCreatedObjectRevision();
                if( m_callbacks != null )
                {
                    for( AsyncCallbackWithContext<IModelObject, Boolean> callback : m_callbacks )
                    {
                        callback.onSuccess( changeObject, Boolean.valueOf( submitToWorkflowValue ) );
                    }
                }
            }
        } );

    }


    /**
     * Method to set relations to propagate
     *
     * @param relationNamesProp relationNamesProp
     */
    public void setRelationsToPropagate( IProperty<List<String>> relationNamesProp )
    {
        if( relationNamesProp != null )
        {
            Object[] relationNamesArray = relationNamesProp.getValue().toArray();
            m_relationNamesToPropagate = relationNamesProp.getValue();

            if( m_relationNamesToPropagate != null )
            {
                m_relationNamesToPropagate.clear();
            }

            for( Object relationName : relationNamesArray )
            {
                m_relationNamesToPropagate.add( relationName.toString() );
            }
        }
    }

    /**
     * Method to set if all objects should be preselected for copy in derive change
     *
     * @param propertyObject propertyObject
     */
    public void setCopyOptionsPreSelection( IProperty<Boolean> propertyObject )
    {
        if( propertyObject.getValue().booleanValue() )
        {
            m_copyOptionsPreSelection = true;
        }

    }

    /**
     * @return a string [] of properties that need to be loaded
     */
    public String[] getPropertiesToLoad()
    {
        String[] propToLoad = null;
        if( m_relationNamesToPropagate != null )
        {
            int count = 0;
            propToLoad = new String[m_relationNamesToPropagate.size()];
            for( String relNames : m_relationNamesToPropagate )
            {
                propToLoad[count] = relNames;
                count++;
            }
        }
        return propToLoad;
    }

    /**
     * @param relationRealName the relation real name
     * @param listViewPresenterWidget listViewPresenterWidget
     * @param selectionModel the selectionModel
     */
    public void populateParentPanel( String relationRealName, ModelObjectListPresenterWidget listViewPresenterWidget,
            UiOrderedMultiSelectionModelWithNotifications<IModelObject> selectionModel )
    {

        m_modelRelNameMap.put( relationRealName, selectionModel );
        setInSlot( CreCheckDefPresenterW.PROPAGATE_RELATION_VIEWER_SLOT, listViewPresenterWidget );
    }

    @Override
    public void getAndShowObjectstoDerive()
    {
        final String[] propertiestoLoad = getPropertiesToLoad();
        ModelUtils.ensurePropertiesLoaded( m_selectedObjects.get( 0 ), propertiestoLoad, new AsyncCallback<Void>()
        {
            @Override
            public void onFailure( Throwable caught )
            {
                Logger.getLogger( CreCheckDefPresenterW.class.getName() ).log( Level.SEVERE,
                        "Failed in loading relation properties for selected change.", caught ); //$NON-NLS-1$
            }

            @Override
            public void onSuccess( Void result )
            {
                showAttachedObjectsToDerive( propertiestoLoad, m_selectedObjects.get( 0 ), m_copyOptionsPreSelection );
            }

        } );
    }

    /**
     * @param propertiestoLoad relation names as properties that need to be loaded.
     * @param selectedObject the selected change object
     * @param copyOptionsPreSelection flag to specify if objects should be preselected
     */
    public void showAttachedObjectsToDerive( String[] propertiestoLoad, IModelObject selectedObject,
            boolean copyOptionsPreSelection )
    {
        for( final String relation : propertiestoLoad )
        {

            final IProperty<List<IModelObject>> propertyProbObject = (IProperty<List<IModelObject>>) selectedObject.getPropertyObject( relation );
            if( propertyProbObject != null )
            {
                if( propertyProbObject.getValue() != null && !propertyProbObject.getValue().isEmpty() )
                {
                    getView().createAndAddLinks( propertyProbObject, copyOptionsPreSelection, selectedObject, relation );

                    final String relationRealName = propertyProbObject.getPropertyDescription().getName();
                    populateParentPanelView( propertyProbObject.getValue(), relationRealName );

                }
            }

        }
    }

    /**
     * Sets the objects as preselected
     *
     * @param objs List of IModelObjects
     * @param selectionModel the selectionModel
     */
    public void setAllSelected( List<IModelObject> objs,
            UiOrderedMultiSelectionModelWithNotifications<IModelObject> selectionModel )
    {

        for( IModelObject singleObj : objs )
        {
            selectionModel.setSelected( singleObj, true );

        }

    }

    /**
     * @param objs List of IModelObjects
     * @param relationRealName the relation real name
     */
    public void populateParentPanelView( final List<IModelObject> objs, String relationRealName )
    {

        final ISelectionStatusSummaryVM selectionVM = m_provider.get();
        getObjectSetCommandHandlersNew( selectionVM );

        m_selectionModel = new UiOrderedMultiSelectionModelWithNotifications<>();

        ModelObjectListPresenterWidget listViewPresenterWidget = m_listViewPresenterFactory.create( m_selectionModel );

        listViewPresenterWidget.setParentCellNotification( new ICellViewInteraction()
        {
            @Override
            public void cellContainerReady( ICellContainer cellContainer )
            {
                if( m_listCellMonitor != null )
                {
                    m_listCellMonitor.cellContainerReady( cellContainer );
                }
                ISelectionTypeControl selectionctrl = cellContainer.getSelectionControl();
                ISetSelectionModel<?> selectionModel = cellContainer.getSelectionModel();

                selectionVM.setSelectionModel( selectionModel );
                selectionVM.setSelectionControl( selectionctrl );
                selectionctrl.setMultiSelectMode( true );
                selectionVM.setDataSet( objs );

            }

        } );

        listViewPresenterWidget.setModelObjects( objs );
        selectionVM.setDataSet( objs );

        populateParentPanel( relationRealName, listViewPresenterWidget, m_selectionModel );

        if( m_copyOptionsPreSelection )
        {
            setAllSelected( objs, m_selectionModel );
        }
    }

    /**
     * @param summaryVm the selection vm
     */
    public void getObjectSetCommandHandlersNew( final ISelectionStatusSummaryVM summaryVm )
    {

        AsyncCallback<Collection<ICommandHandler>> commandHandlers = new AsyncCallback<Collection<ICommandHandler>>()
        {
            @Override
            public void onFailure( Throwable caught )
            {
                MessageUtil.reportException( caught );
            }

            @Override
            public void onSuccess( Collection<ICommandHandler> result )
            {
                if( result != null && result.size() > 0 )
                {
                    for( ICommandHandler hdlr : result )
                    {
                        if( hdlr instanceof IConsumeSelectionStatusSummary )
                        {
                            ( (IConsumeSelectionStatusSummary) hdlr ).setStatusSummaryVM( summaryVm );
                            summaryVm.selectAllLoaded();
                        }
                    }
                    getView().getWidgetAndSetInSlot( result );
                }

            }
        };

        m_commandWidgetRegistry.getCommands( com.siemens.splm.clientfx.ui.published.NameTokens.XRT_OBJECTSET_AREA_ID,
                com.siemens.splm.clientfx.ui.published.NameTokens.SELECTION_SUMMARY_XRT_UI, true, commandHandlers );
    }

    /**
     * @param iModelObject primary selected object
     * @param propertiestoLoad properties that need to be loaded
     * @return Map
     */
    private Map<String, List<IModelObject>> getAttachmentsMapFromCurrentECR( String[] propertiestoLoad,
            IModelObject iModelObject )
    {
        Map<String, List<IModelObject>> derivedChangeAttachmentMap = new HashMap<>();

        for( final String relation : propertiestoLoad )
        {

            final IProperty<List<IModelObject>> propertyProbObject = (IProperty<List<IModelObject>>) iModelObject.getPropertyObject( relation );

            if( propertyProbObject != null )
            {
                if( propertyProbObject.getValue() != null && !propertyProbObject.getValue().isEmpty() )
                {

                    derivedChangeAttachmentMap.put( relation, propertyProbObject.getValue() );

                }
            }
        }

        return derivedChangeAttachmentMap;
    }
    
    /**
     * Selects the workspace object type that will be used in the create panel
     *
     * @param typeName the name of the type to create
     */
    private void setCreateType( String typeName )
    {
        IModelType modelType = m_session.getClientMetaModel().getType( typeName );
        ModelTypeInfo typeInfo = new ModelTypeInfo( modelType.getName(), modelType.getDisplayValue() );
        // would be nice to verify that model type is related to Item, but doesn't appear to be easy way to get type hierarchy here
        onObjectTypeSelected( typeInfo );
    }
}
