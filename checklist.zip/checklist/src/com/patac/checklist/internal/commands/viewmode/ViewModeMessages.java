package com.patac.checklist.internal.commands.viewmode;

import com.google.gwt.core.client.GWT;
import com.google.gwt.i18n.client.Messages;

public interface ViewModeMessages 
extends Messages{
	ViewModeMessages INSTANCE = GWT.create(ViewModeMessages.class);
	
    String setTableMode();
    
    String setTableSumMode();
    
}
